<?php
require_once('connection.php');
include'get_id_mitra.php';
	if($con){
		$response = array();
		$nama_tertanggung = $_POST['nama_tertanggung'];
		$sts_tertanggung = $_POST['sts_tertanggung'];
		$jml_tanggungan = $_POST['jml_tanggungan'];
		$jml_anak = $_POST['jml_anak'];
		$alamat = $_POST['alamat'];
		$desa= $_POST['desa'];
		$kecamatan= $_POST['kecamatan'];
		$rt= $_POST['rt'];
		$rw= $_POST['rw'];
		$kodepos= $_POST['kodepos'];
		$jenis_mitra = $_POST['jenis_mitra'];
		$Id_mitra = $_POST['Id_mitra'];
		if($jenis_mitra == "baru"){
			if($nama_tertanggung !="" && $sts_tertanggung !="" && $jml_tanggungan !="" && $jml_anak !="" &&  $alamat !="" && $desa !="" && $kecamatan !="" && $rt !="" && $rw !="" && $kodepos !=""){
			$insert = "INSERT INTO `ahli_waris`(`id_mitra`, `nama_tertanggung`, `sts_tertanggung`, `jml_tanggungan`, `jml_anak`, `alamat`, `desa`, `kecamatan`, `rt`, `rw`, `kodepos`) VALUES ('$id_mitra','$nama_tertanggung','$sts_tertanggung','$jml_tanggungan ','$jml_anak','$alamat','$desa','$kecamatan','$rt','$rw','$kodepos')";
			$result2 = mysqli_query($con,$insert);
				if($result2){
					array_push($response, array(
						'status' => 'OK'
					));
				}else{
					array_push($response,array(
						'status' => 'GAGAL'
					));		
				}
			}else{
				array_push($response,array(
					'status' => 'FAILED'
				));		
			}
		}else{
			$update = "UPDATE `ahli_waris` SET `nama_tertanggung`='$nama_tertanggung',`sts_tertanggung`='$sts_tertanggung',`jml_tanggungan`='$jml_tanggungan',`jml_anak`='$jml_anak',`alamat`='$alamat',`desa`='$desa',`kecamatan`='$kecamatan',`rt`='$rt',`rw`='$rw',`kodepos`='$kodepos' WHERE id_mitra = '$Id_mitra'";
			$result2 = mysqli_query($con,$update);
				if($result2){
					array_push($response, array(
						'status' => 'OK'
					));
				}else{
					array_push($response,array(
						'status' => 'GAGAL'
					));		
				}
		}
	}else{
		array_push($response,array(
		'status' => 'FAILED'
		));		
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);
?>
