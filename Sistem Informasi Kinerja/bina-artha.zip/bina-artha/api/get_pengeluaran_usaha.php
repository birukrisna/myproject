<?php
require_once('connection.php');
	if($con){
		$id_mitra = $_POST['id_mitra'];
		//$id_mitra = "0213000001";
		$read = "SELECT * FROM `pengeluaran_usaha` WHERE `id_mitra` = '$id_mitra'";
		$result = mysqli_query($con,$read);
		$response = array();
		while($row = mysqli_fetch_array($result)){
			array_push($response,array(
			'bahan_baku' => $row[1],
			'listrik' => $row[2],
			'tenaga_kerja' => $row[3],
			'transportasi' => $row[4],
			'angsuran' => $row[5],
			'ketbahan_baku' => $row[6],
			'ketlistrik' => $row[7],
			'kettenaga_kerja' => $row[8],
			'kettransportasi' => $row[9],
			'ketangsuran' => $row[10],
			'total_pengeluran' => $row[11],
			'pendapatan_bersih' => $row[12]
		));
		}
	}else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);

?>