<?php
require_once('connection.php');
include'get_id_mitra.php';
	if($con){
		$response = array();
		$bahan_baku = $_POST['bahan_baku'];
		$listrik = $_POST['listrik'];
		$tenaga_kerja = $_POST['tenaga_kerja'];
		$transportasi = $_POST['transportasi'];
		$angsuran = $_POST['angsuran'];
		$ketbahan_baku = $_POST['ketbahan_baku'];
		$ketlistrik = $_POST['ketlistrik'];
		$kettenaga_kerja = $_POST['kettenaga_kerja'];
		$kettransportasi = $_POST['kettransportasi'];
		$ketangsuran = $_POST['ketangsuran'];
		$total_pengeluaran = $_POST['total_pengeluaran'];
		$penghasilan_bersih_usaha = $_POST['penghasilan_bersih_usaha'];
		$jenis_mitra = $_POST['jenis_mitra'];
		$Id_mitra = $_POST['Id_mitra'];
		if($jenis_mitra == "baru"){
			$insert = "INSERT INTO `pengeluaran_usaha`(`id_mitra`, `bahan_baku`, `listrik`, `tenaga_kerja`, `transportasi`, `angsuran`,`ket_bahanbaku`, `ket_listrik`, `ket_tenaga_kerja`, `ket_transportasi`, `ket_angsuran`, `total_pengeluaran`, `penghasilan_bersih_usaha`) VALUES ('$id_mitra','$bahan_baku','$listrik','$tenaga_kerja','$transportasi','$angsuran','$ketbahan_baku','$ketlistrik','$kettenaga_kerja','$kettransportasi','$ketangsuran','$total_pengeluaran','$penghasilan_bersih_usaha')";
			$result2 = mysqli_query($con,$insert);
			if($result2){
				array_push($response, array(
					'status' => 'OK'
				));
			}else{
				array_push($response,array(
					'status' => 'GAGAL'
				));		
			}
		}else{
			$update = "UPDATE `pengeluaran_usaha` SET `bahan_baku`='$bahan_baku',`listrik`='$listrik',`tenaga_kerja`='$tenaga_kerja',`transportasi`='$transportasi',`angsuran`='$angsuran',`ket_bahanbaku`='$ketbahan_baku',`ket_listrik`='$ketlistrik',`ket_tenaga_kerja`='$kettenaga_kerja',`ket_transportasi`='$kettransportasi',`ket_angsuran`='$ketangsuran',`total_pengeluaran`='$total_pengeluaran',`penghasilan_bersih_usaha`='$penghasilan_bersih_usaha' WHERE id_mitra ='$Id_mitra'";
			$result2 = mysqli_query($con,$update);
			if($result2){
				array_push($response, array(
					'status' => 'OK'
				));
			}else{
				array_push($response,array(
					'status' => 'GAGAL'
				));		
			}
		}
	}else{
		array_push($response,array(
			'status' => 'FAILED'
		));		
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);
?>