<?php
require_once('connection.php');
	if($con){
		$id_mitra = $_POST['id_mitra'];
		//$id_mitra = "0213000001";
		$read = "SELECT * FROM `ahli_waris` WHERE `id_mitra` = '$id_mitra'";
		//$read = "SELECT karyawan.nik,karyawan.nama,user.password,user.tipe FROM user INNER JOIN karyawan ON karyawan.nik = user.nik";
		$result = mysqli_query($con,$read);
		$response = array();

		while($row = mysqli_fetch_array($result)){
			array_push($response,array(
			'nama_tertanggung' => $row[1],
			'sts_tertanggung' => $row[2],
			'jml_tanggungan' => $row[3],
			'jml_anak' => $row[4]
			
		));
		}
	}else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);

?>