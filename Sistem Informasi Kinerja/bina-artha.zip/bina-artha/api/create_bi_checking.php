<?php
require_once('connection.php');
	if($con){
		$response = array();
		$id_mitra = $_POST['id_mitra'];
		$kondisi = $_POST['kondisi'];
		$kolektabilitas = $_POST['kolektabilitas'];
		/*$id_mitra = "1";
		$kondisi = "baru";
		$kolektabilitas = "1";*/
		if($kondisi =="update"){
			$update ="UPDATE `bi_checking` SET `kolektabilistas`='$kolektabilitas' WHERE id_mitra = '$id_mitra'";
			$result2 = mysqli_query($con,$update);
			if($result2){
				array_push($response, array(
					'status' => 'OK'
				));
			}else{
				array_push($response,array(
					'status' => 'GAGAL'
				));		
			}	
		}else if($kondisi == "baru"){
			$insert = "INSERT INTO `bi_checking`(`id_mitra`, `kolektabilistas`) VALUES ('$id_mitra','$kolektabilitas')";
			$result2 = mysqli_query($con,$insert);
			if($result2){
				array_push($response, array(
					'status' => 'OK'
				));
			}else{
				array_push($response,array(
					'status' => 'GAGAl'
				));		
			}		
		}else{
			array_push($response,array(
				'status' => 'FAILED'
			));	
		}
	}else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);
?>	