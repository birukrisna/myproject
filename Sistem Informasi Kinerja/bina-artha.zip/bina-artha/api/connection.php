<?php
	include'config.php';
	$con = mysqli_connect(SERVER,UID,PASSWORD,DB_NAME);
?>