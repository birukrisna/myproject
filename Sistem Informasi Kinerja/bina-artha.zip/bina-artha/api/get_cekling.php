<?php
require_once('connection.php');
	if($con){
		$id_mitra = $_POST['id_mitra'];
		//$id_mitra = "0213000001";
		$read = "SELECT * FROM `cekling` WHERE `id_mitra` = '$id_mitra'";
		$result = mysqli_query($con,$read);
		$response = array();
		$row = mysqli_num_rows($result);
		if($row > 0){
			while($col = mysqli_fetch_array($result)){
				array_push($response,array(
					'narasumber1' => $col[1],
					'hasil1' => $col[2],
					'narasumber2' => $col[3],
					'hasil2' => $col[4],
					'narasumber3' => $col[5],
					'hasil3' => $col[6]
		));
		}
		}else{
			array_push($response,array(
				'status' => 'GAGAL'
			));
		}
		
	}else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);

?>