<?php
require_once('connection.php');
	if($con){
		$id_mitra = $_POST['id_mitra'];
		//$id_mitra = "0213000001";
		$read = "SELECT * FROM `mitra` WHERE `id_mitra` = '$id_mitra'";
		//$read = "SELECT karyawan.nik,karyawan.nama,user.password,user.tipe FROM user INNER JOIN karyawan ON karyawan.nik = user.nik";
		$result = mysqli_query($con,$read);
		$response = array();

		while($row = mysqli_fetch_array($result)){
			array_push($response,array(
			'id_mitra' => $row[0],
			'nama_lengkap' => $row[1],
			'nama_panggilan' => $row[2],
			'ibu_kandung' => $row[3],
			'alamat' => $row[4],
			'desa' => $row[5],
			'kecamatan' => $row[6],
			'rt' => $row[7],
			'rw' => $row[8],
			'kodepos' => $row[9],
			'pendidikan_terakhir' => $row[10],
			'nomer_telepon' => $row[11],
			'status_rumah' => $row[12],
			'lama_tinggal' => $row[13],
			'rumah_lat' => $row[14],
			'rumah_long' => $row[15]
		));
		}
	}else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);

?>