<?php
require_once('connection.php');
	if($con){
		$response = array();
		$id_mitra = $_POST['id_mitra'];
		$nama_kumpulan = $_POST['nama_kumpulan'];
		//$id_mitra = "0213000001";
		//$nama_kumpulan = "SADU 01";
		$select = "SELECT `id_kumpulan`, `nama_kumpulan` FROM `kumpulan` WHERE nama_kumpulan = '$nama_kumpulan'";
		$result = mysqli_query($con,$select);
		$rows = mysqli_num_rows($result);
		if($rows > 0){
			while($col = mysqli_fetch_array($result)){
				$id_kumpulan = $col[0];
			}
		}else{
			$getjlm_baris = "SELECT COUNT(*) FROM kumpulan";
			$result2 = mysqli_query($con,$getjlm_baris);
				while($row = mysqli_fetch_array($result2)){
					(int)$jml_baris = $row[0] +1;
						$jml_huruf = strlen($jml_baris);
					if($jml_huruf ==1){
						$angka0 = "000";
						$id_kumpulan = $angka0.$jml_baris;
					}else if($jml_huruf==2){
						$angka0 = "00";
						$id_kumpulan = $angka0.$jml_baris;
					}else if($jml_huruf==3){
						$angka0 = "0";
						$id_kumpulan = $angka0.$jml_baris;
					}else if($jml_huruf==4){
						$id_kumpulan = $angka0.$jml_baris;
					}
				}
			$insertk = "INSERT INTO `kumpulan`(`id_kumpulan`, `nama_kumpulan`) VALUES ('$id_kumpulan','$nama_kumpulan')";
			$result3 = mysqli_query($con,$insertk);
		}
		$update ="UPDATE `ukm`  SET `id_kumpulan`='$id_kumpulan' WHERE `ukm`.`id_mitra` = '$id_mitra'";
		$result4 = mysqli_query($con,$update);
		if($result4){
			array_push($response, array(
				'status' => 'OK'
			));
		}else{
			array_push($response,array(
				'status' => 'GAGAL'
			));		
		}	
	}else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);
?>	