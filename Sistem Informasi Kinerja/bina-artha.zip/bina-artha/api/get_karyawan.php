<?php
require_once('connection.php');
	if($con){
		$username = $_POST['username'];
		//$username = "5510";
		$getNik = "SELECT nik FROM `user` WHERE username = $username";
		$response = array();
		$result = mysqli_query($con,$getNik);
		while($row = mysqli_fetch_array($result)){
				$query = "SELECT karyawan.nik,karyawan.nama,karyawan.cabang FROM user INNER JOIN karyawan ON user.nik = karyawan.nik WHERE user.nik = $row[0]";
				$result2 = mysqli_query($con,$query);
				while($row2 = mysqli_fetch_array($result2)){
				array_push($response,array(
					'nik' => $row2[0],
					'nama' => $row2[1],
					'cabang' => $row2[2]
				));
				}
			}
		/*
		$query = "SELECT karyawan.nama,karyawan.cabang FROM user INNER JOIN karyawan ON user.nik = karyawan.nik WHERE user.nik = $nik";
		$getData = "SELECT * FROM `user` WHERE nik = '$nik'";
		if($nik !=""){
			$result = mysqli_query($con,$query);
			$response = array();
			while($row = mysqli_fetch_array($result)){
				array_push($response,array(
					'nama' => $row[0],
					'cabang' => $row[1]
				));
			}
		}else{
			array_push($response,array(
				'status' => 'FAILED'
			));
		}
	}else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	*/
	}
	else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);
?>