<?php
require_once('connection.php');
include'get_id_mitra.php';
	if($con){
		$nama_lengkap = $_POST['nama_lengkap'];
		$nama_panggilan= $_POST['nama_panggilan'];
		$ibu_kandung= $_POST['ibu_kandung'];
		$alamat= $_POST['alamat'];
		$desa= $_POST['desa'];
		$kecamatan= $_POST['kecamatan'];
		$rt= $_POST['rt'];
		$rw= $_POST['rw'];
		$kodepos= $_POST['kodepos'];
		$pendidikan_terakhir= $_POST['pendidikan_terakhir'];
		$nomer_telepon = $_POST['nomer_telepon'];
		$lama_tinggal= $_POST['lama_tinggal'];
		$status_rumah = $_POST['status_rumah'];
		$rumah_lat= $_POST['rumah_lat'];
		$rumah_long= $_POST['rumah_long'];
		$jenis_mitra = $_POST['jenis_mitra'];
		$Id_mitra = $_POST['Id_mitra'];
		$response = array();
		if($jenis_mitra == "baru"){
			if($nama_lengkap !="" &&$nama_panggilan !="" && $ibu_kandung !="" && $alamat !="" && $desa !="" &&
			$kecamatan !="" && $rt !="" && $rw !="" && $kodepos !="" && $pendidikan_terakhir !="" &&
			$nomer_telepon !="" && $status_rumah !="" && $lama_tinggal !="" && $rumah_lat !="" && $rumah_long !=""){
			$insert = "INSERT INTO `mitra`(`id_mitra`, `nama_lengkap`, `nama_panggilan`, `ibu_kandung`, `alamat`, `desa`, `kecamatan`, `rt`, `rw`, `kodepos`, `pendidikan_terakhir`, `nomer_telepon`,`status_rumah`, `lama_tinggal`,`rumah_lat`,`rumah_long`) VALUES ('$id_mitra','$nama_lengkap','$nama_panggilan','$ibu_kandung','$alamat','$desa','$kecamatan','$rt','$rw','$kodepos','$pendidikan_terakhir','$nomer_telepon','$status_rumah','$lama_tinggal','$rumah_lat','$rumah_long')";
			$result2 = mysqli_query($con,$insert);
			if($result2){
				array_push($response, array(
					'status' => 'OK'
				));
			}else{
				array_push($response,array(
					'status' => 'GAGAL'
				));		
			}
			}
			else{
				array_push($response,array(
					'status' => 'GAGAL'
				));		
			}		
		}else{
			$update = "UPDATE `mitra` SET `nama_lengkap`= '$nama_lengkap',`nama_panggilan`='$nama_panggilan',`ibu_kandung`='$ibu_kandung',`alamat`='$alamat',`desa`='$desa',`kecamatan`='$kecamatan',`rt`='$rt',`rw`='$rw',`kodepos`='$kodepos',`pendidikan_terakhir`='$pendidikan_terakhir',`nomer_telepon`=$nomer_telepon,`status_rumah`='$status_rumah',`lama_tinggal`='$lama_tinggal',`rumah_lat`='$rumah_lat',`rumah_long`='$rumah_long' WHERE id_mitra = '$Id_mitra'";
				$result2 = mysqli_query($con,$update);
				if($result2){
				array_push($response, array(
					'status' => 'OK'
				));
			}else{
				array_push($response,array(
				'status' => 'GAGAL'
				));		
			}
		}	
	}else{
			array_push($response,array(
			'status' => 'FAILED'
		));		
		}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);
?>