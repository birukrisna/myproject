<?php
require_once('connection.php');
include'get_id_mitra_ukm.php';
	if($con){
		$response = array();
		$Id_mitra = $_POST['Id_mitra'];
		$nik = $_POST['nik'];
		$jenis_mitra = $_POST['jenis_mitra'];
		$tgl_survei = $_POST['tgl_survei'];
		$putaran_pinjaman = $_POST['putaran_pinjaman'];
		$bsr_pinjaman_dbr = $_POST['bsr_pinjaman_dbr'];
		$bsr_pinjaman=0;
		if($jenis_mitra=="baru"){
			$insert = "INSERT INTO `ukm`(`nik`, `id_mitra`, `tgl_survei`, `putaran_pinjaman`, `bsr_pinjaman_dbr`) VALUES ('$nik','$id_mitra','$tgl_survei','$putaran_pinjaman','$bsr_pinjaman_dbr')";
			$result2 = mysqli_query($con,$insert);
			if($result2){
				array_push($response, array(
					'status' => 'OK'
				));
			}else{
				array_push($response,array(
					'status' => 'GAGAL'
				));		
			}			
		}else if($jenis_mitra == "lama"){
			$update = "UPDATE `ukm` SET `nik`='$nik',`tgl_survei`='$tgl_survei',`putaran_pinjaman`='$putaran_pinjaman',`bsr_pinjaman_dbr`='$bsr_pinjaman_dbr',`bsr_pinjaman`='$bsr_pinjaman' WHERE id_mitra = '$Id_mitra'";
			$result3 = mysqli_query($con,$update);
			if($result3){
				array_push($response, array(
					'status' => 'OK'
				));
			}else{
				array_push($response,array(
					'status' => 'GAGAL'
				));		
			}
		}else{
			array_push($response,array(
				'status' => 'GAGAL'
			));
		}
	}else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);
?>