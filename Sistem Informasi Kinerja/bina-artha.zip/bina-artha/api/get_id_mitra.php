<?php
require_once('connection.php');
	if($con){
		$id_cabang = '0213';
		$getjlm_baris = "SELECT COUNT(*) FROM ukm";
		$result = mysqli_query($con,$getjlm_baris);
		while($row = mysqli_fetch_array($result)){
			(int)$jml_baris = $row[0] ;
			$jml_huruf = strlen($jml_baris);
			if($jml_huruf ==1){
				$angka0 = "00000";
				$id_urutan = $angka0.$jml_baris;
			}else if($jml_huruf==2){
				$angka0 = "0000";
				$id_urutan = $angka0.$jml_baris;
			}else if($jml_huruf==3){
				$angka0 = "000";
				$id_urutan = $angka0.$jml_baris;
			}else if($jml_huruf==4){
				$angka0 = "00";
				$id_urutan = $angka0.$jml_baris;
			}else if($jml_huruf==5){
				$angka0 = "0";
				$id_urutan = $angka0.$jml_baris;
			}else if($jml_huruf==6){
				$id_urutan = $jml_baris;
			}
		}
		$response = array();
		$id_mitra = $id_cabang.$id_urutan;
	}else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
?>