<?php
require_once('connection.php');
include'get_id_mitra.php';
	if($con){
		$response = array();
		$banyak_lembaga = $_POST['banyak_lembaga'];
		$nama_lembaga1 = $_POST['nama_lembaga1'];
		$jangka_waktu1 = $_POST['jangka_waktu1'];
		$tahun_kredit1 = $_POST['tahun_kredit1'];
		$besar_pinjaman1 = $_POST['besar_pinjaman1'];
		$angsuran1 = $_POST['angsuran1'];
		$sisa_angsuran1 = $_POST['sisa_angsuran1'];
		$sisa_pinjaman1 = $_POST['sisa_pinjaman1'];
		$frekuensi_angsuran1 = $_POST['frekuensi_angsuran1'];
		$nama_lembaga2 = $_POST['nama_lembaga2'];
		$jangka_waktu2 = $_POST['jangka_waktu2'];
		$tahun_kredit2 = $_POST['tahun_kredit2'];
		$besar_pinjaman2 = $_POST['besar_pinjaman2'];
		$angsuran2 = $_POST['angsuran2'];
		$sisa_angsuran2 = $_POST['sisa_angsuran2'];
		$sisa_pinjaman2 = $_POST['sisa_pinjaman2'];
		$frekuensi_angsuran2 = $_POST['frekuensi_angsuran2'];
		$nama_lembaga3 = $_POST['nama_lembaga3'];
		$jangka_waktu3 = $_POST['jangka_waktu3'];
		$tahun_kredit3 = $_POST['tahun_kredit3'];
		$besar_pinjaman3 = $_POST['besar_pinjaman3'];
		$angsuran3 = $_POST['angsuran3'];
		$sisa_angsuran3 = $_POST['sisa_angsuran3'];
		$sisa_pinjaman3 = $_POST['sisa_pinjaman3'];
		$frekuensi_angsuran3 = $_POST['frekuensi_angsuran3'];
		$jenis_mitra = $_POST['jenis_mitra'];
		$Id_mitra = $_POST['Id_mitra'];
		if($jenis_mitra == "lama"){
			$delete = "DELETE FROM `riwayat_pinjaman` WHERE id_mitra = '$Id_mitra'";
			$id_mitra = $Id_mitra;
			$result3 = mysqli_query($con,$delete);
			if($result3){
				array_push($response, array(
					'status' => 'OK'
				));
			}else{
				array_push($response,array(
					'status' => 'GAGAL'
				));		
			}
		}
		if($banyak_lembaga =="1") {
			if($nama_lembaga1 !="" && $jangka_waktu1 !="" && $tahun_kredit1 !="" && $besar_pinjaman1 !="" && $angsuran1 !="" && $sisa_pinjaman1 !="" && $frekuensi_angsuran1 !=""){
				$insert1 ="INSERT INTO `riwayat_pinjaman`(`id_mitra`, `nama_lembaga`, `jangka_waktu`, `tahun_kredit`, `besar_pinjaman`, `angsuran`,`sisa_angsuran`, `sisa_pinjaman`, `frekuensi_angsuran`) VALUES ('$id_mitra','$nama_lembaga1','$jangka_waktu1','$tahun_kredit1','$besar_pinjaman1','$angsuran1','$sisa_angsuran1','$sisa_pinjaman1','$frekuensi_angsuran1')";
				$result2 = mysqli_query($con,$insert1);
				if($result2){
					array_push($response, array(
						'status' => 'OK'
					));
				}else{
					array_push($response,array(
						'status' => 'GAGAL'
					));		
				}
			}else{
				array_push($response,array(
					'status' => 'FAILED'
				));	
			}
		}else if($banyak_lembaga =="2"){
			if($nama_lembaga1 !="" && $jangka_waktu1 !="" && $tahun_kredit1 !="" && $besar_pinjaman1 !="" && $angsuran1 !="" && $sisa_pinjaman1 !="" && $frekuensi_angsuran1 !="" && $nama_lembaga2 !="" && $jangka_waktu2 !="" && $tahun_kredit2 !="" && $besar_pinjaman2 !="" && $angsuran2 !="" && $sisa_pinjaman2 !="" && $frekuensi_angsuran2 !=""){
				$insert1 ="INSERT INTO `riwayat_pinjaman`(`id_mitra`, `nama_lembaga`, `jangka_waktu`, `tahun_kredit`, `besar_pinjaman`, `angsuran`,'sisa_angsuran',`sisa_pinjaman`, `frekuensi_angsuran`) VALUES ('$id_mitra','$nama_lembaga1','$jangka_waktu1','$tahun_kredit1','$besar_pinjaman1','$angsuran1','$sisa_angsuran1','$sisa_pinjaman1','$frekuensi_angsuran1'),('$id_mitra','$nama_lembaga2','$jangka_waktu2','$tahun_kredit2','$besar_pinjaman2','$angsuran2','$sisa_angsuran2','$sisa_pinjaman2','$frekuensi_angsuran2')";
				$result2 = mysqli_query($con,$insert1);
				if($result2){
					array_push($response, array(
						'status' => 'OK'
					));
				}else{
					array_push($response,array(
						'status' => 'GAGAL'
					));		
				}
			}else{
				array_push($response,array(
					'status' => 'FAILED'
				));	
			}
		}else if($banyak_lembaga =="3"){
			if($nama_lembaga1 !="" && $jangka_waktu1 !="" && $tahun_kredit1 !="" && $besar_pinjaman1 !="" && $angsuran1 !="" && $sisa_pinjaman1 !="" && $frekuensi_angsuran1 !="" && $nama_lembaga2 !="" && $jangka_waktu2 !="" && $tahun_kredit2 !="" && $besar_pinjaman2 !="" && $angsuran2 !="" && $sisa_pinjaman2 !="" && $frekuensi_angsuran2 !="" && $nama_lembaga3 !="" && $jangka_waktu3 !="" && $tahun_kredit3 !="" && $besar_pinjaman3 !="" && $angsuran3 !="" && $sisa_pinjaman3 !="" && $frekuensi_angsuran3 !=""){
				$insert1 ="INSERT INTO `riwayat_pinjaman`(`id_mitra`, `nama_lembaga`, `jangka_waktu`, `tahun_kredit`, `besar_pinjaman`, `angsuran`,'sisa_angsuran', `sisa_pinjaman`, `frekuensi_angsuran`) VALUES ('$id_mitra','$nama_lembaga1','$jangka_waktu1','$tahun_kredit1','$besar_pinjaman1','$angsuran1','$sisa_angsuran1','$sisa_pinjaman1','$frekuensi_angsuran1'),('$id_mitra','$nama_lembaga2','$jangka_waktu2','$tahun_kredit2','$besar_pinjaman2','$angsuran2','$sisa_angsuran2','$sisa_pinjaman2','$frekuensi_angsuran2'), ('$id_mitra','$nama_lembaga3','$jangka_waktu3','$tahun_kredit3','$besar_pinjaman3','$angsuran3','$sisa_angsuran3','$sisa_pinjaman3','$frekuensi_angsuran3')";
				$result2 = mysqli_query($con,$insert1);
				if($result2){
					array_push($response, array(
						'status' => 'OK'
					));
				}else{
					array_push($response,array(
						'status' => 'GAGAL'
					));		
				}
			}else{
				array_push($response,array(
					'status' => 'FAILED'
				));		
			}
		}else{
				array_push($response,array(
					'status' => 'Tidak Punya'
				));	
			}
	}else{
		array_push($response,array(
			'status' => 'FAILED'
		));		
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);
?>
