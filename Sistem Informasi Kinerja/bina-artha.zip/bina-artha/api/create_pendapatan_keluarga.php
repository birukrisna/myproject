<?php
require_once('connection.php');
include'get_id_mitra.php';
	if($con){
		$response = array();
		$banyak_keluarga = $_POST['banyak_keluarga'];
		$nama_pemberi1 = $_POST['nama_pemberi1'];
		$hbgan_dng_mitra1 = $_POST['hbgan_dng_mitra1'];
		$pekerjaan1 = $_POST['pekerjaan1'];
		$pendapatan1 = $_POST['pendapatan1'];
		$nama_pemberi2 = $_POST['nama_pemberi2'];
		$hbgan_dng_mitra2 = $_POST['hbgan_dng_mitra2'];
		$pekerjaan2 = $_POST['pekerjaan2'];
		$pendapatan2 = $_POST['pendapatan2'];
		$nama_pemberi3 = $_POST['nama_pemberi3'];
		$hbgan_dng_mitra3 = $_POST['hbgan_dng_mitra3'];
		$pekerjaan3 = $_POST['pekerjaan3'];
		$pendapatan3 = $_POST['pendapatan3'];
		$nama_pemberi4 = $_POST['nama_pemberi4'];
		$hbgan_dng_mitra4 = $_POST['hbgan_dng_mitra4'];
		$pekerjaan4 = $_POST['pekerjaan4'];
		$pendapatan4 = $_POST['pendapatan4'];
		$total_pendapatan = $_POST['total_pendapatan'];
		$jenis_mitra = $_POST['jenis_mitra'];
		$Id_mitra = $_POST['Id_mitra'];
		if($jenis_mitra == "lama"){
			$delete = "DELETE FROM `pendapatan_keluarga` WHERE id_mitra ='$Id_mitra'";
			$result3 = mysqli_query($con,$delete);
			$id_mitra = $Id_mitra;
			if($result3){
				array_push($response, array(
					'status' => 'OK'
				));
			}else{
				array_push($response,array(
					'status' => 'GAGAL'
				));		
			}
		}
		if($banyak_keluarga == "1"){
			if($nama_pemberi1 != "" && $hbgan_dng_mitra1 != "" && $pekerjaan1 != "" && $pendapatan1 != "" && $total_pendapatan != ""){
				$insert1 = "INSERT INTO `pendapatan_keluarga`(`id_mitra`, `nama_pemberi`, `hbgan_dng_mitra`, `pekerjaan`, `pendapatan`, `total_pendapatan`) VALUES ('$id_mitra','$nama_pemberi1','$hbgan_dng_mitra1','$pekerjaan1',$pendapatan1,$total_pendapatan)";
				$result2 = mysqli_query($con,$insert1);
				if($result2){
					array_push($response, array(
						'status' => 'OK'
					));
				}else{
					array_push($response,array(
						'status' => 'GAGAL'
					));		
				}
			}else{
				array_push($response,array(
					'status' => 'FAILED'
				));	
			}
		}else if ($banyak_keluarga == "2"){
			if($nama_pemberi1 != "" && $hbgan_dng_mitra1 != "" && $pekerjaan1 != "" && $pendapatan1 != "" && $nama_pemberi2 != "" && $hbgan_dng_mitra2 != "" && $pekerjaan2 != "" && $pendapatan2 != "" && $total_pendapatan != ""){
				$insert1 = "INSERT INTO `pendapatan_keluarga`(`id_mitra`, `nama_pemberi`, `hbgan_dng_mitra`, `pekerjaan`, `pendapatan`, `total_pendapatan`) VALUES ('$id_mitra','$nama_pemberi1','$hbgan_dng_mitra1','$pekerjaan1',$pendapatan1,$total_pendapatan),('$id_mitra','$nama_pemberi2','$hbgan_dng_mitra2','$pekerjaan2',$pendapatan2,$total_pendapatan)";
				$result2 = mysqli_query($con,$insert1);
				if($result2){
					array_push($response, array(
						'status' => 'OK'
					));
				}else{
					array_push($response,array(
						'status' => 'GAGAL'
					));		
				}
			}else{
				array_push($response,array(
					'status' => 'FAILED'
				));	
			}
		}else if($banyak_keluarga == "3"){
			if($nama_pemberi1 != "" && $hbgan_dng_mitra1 != "" && $pekerjaan1 != "" && $pendapatan1 != "" && $nama_pemberi2 != "" && $hbgan_dng_mitra2 != "" && $pekerjaan2 != "" && $pendapatan2 != "" && $nama_pemberi3 != "" && $hbgan_dng_mitra3 != "" && $pekerjaan3 != "" && $pendapatan3 != "" && $total_pendapatan != ""){
				$insert1 = "INSERT INTO `pendapatan_keluarga`(`id_mitra`, `nama_pemberi`, `hbgan_dng_mitra`, `pekerjaan`, `pendapatan`, `total_pendapatan`) VALUES ('$id_mitra','$nama_pemberi1','$hbgan_dng_mitra1','$pekerjaan1',$pendapatan1,$total_pendapatan),('$id_mitra','$nama_pemberi2','$hbgan_dng_mitra2','$pekerjaan2',$pendapatan2,$total_pendapatan),'$id_mitra','$nama_pemberi3','$hbgan_dng_mitra3','$pekerjaan3',$pendapatan3,$total_pendapatan)";
				$result2 = mysqli_query($con,$insert1);
				if($result2){
					array_push($response, array(
						'status' => 'OK'
					));
				}else{
					array_push($response,array(
						'status' => 'GAGAL'
					));		
				}
			}else{
				array_push($response,array(
					'status' => 'FAILED'
				));	
			}
		}else {
			if($nama_pemberi1 != "" && $hbgan_dng_mitra1 != "" && $pekerjaan1 != "" && $pendapatan1 != "" && $nama_pemberi2 != "" && $hbgan_dng_mitra2 != "" && $pekerjaan2 != "" && $pendapatan2 != "" && $nama_pemberi3 != "" && $hbgan_dng_mitra3 != "" && $pekerjaan4 != "" && $pendapatan3 != "" && $nama_pemberi4 != "" && $hbgan_dng_mitra4 != "" && $pekerjaan4 != "" && $pendapatan4 != "" && $total_pendapatan != ""){
				$insert1 = "INSERT INTO `pendapatan_keluarga`(`id_mitra`, `nama_pemberi`, `hbgan_dng_mitra`, `pekerjaan`, `pendapatan`, `total_pendapatan`) VALUES ('$id_mitra','$nama_pemberi1','$hbgan_dng_mitra1','$pekerjaan1',$pendapatan1,$total_pendapatan),('$id_mitra','$nama_pemberi2','$hbgan_dng_mitra2','$pekerjaan2',$pendapatan2,$total_pendapatan),'$id_mitra','$nama_pemberi3','$hbgan_dng_mitra3','$pekerjaan3',$pendapatan3,$total_pendapatan),'$id_mitra','$nama_pemberi4','$hbgan_dng_mitra4','$pekerjaan4',$pendapatan4,$total_pendapatan)";
				$result2 = mysqli_query($con,$insert1);
				if($result2){
					array_push($response, array(
						'status' => 'OK'
					));
				}else{
					array_push($response,array(
						'status' => 'GAGAL'
					));		
				}
			}else{
				array_push($response,array(
					'status' => 'FAILED'
				));	
			}
		}
	}else{
		array_push($response,array(
			'status' => 'FAILED'
		));		
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);
?>
