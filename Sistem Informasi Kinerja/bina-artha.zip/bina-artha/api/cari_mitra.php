<?php
require_once('connection.php');
	if($con){
		$cari = $_POST['cari'];
		//$cari = "Krisna";
		$response = array();
		$read = "SELECT id_mitra,nama_lengkap FROM `mitra` WHERE nama_lengkap LIKE '%$cari%' or id_mitra LIKE '%$cari%'";
		$result = mysqli_query($con,$read);
		$row = mysqli_num_rows($result);
		if($row > 0){
			while($col = mysqli_fetch_array($result)){
				array_push($response,array(
					'id_mitra' => $col[0],
					'nama' => $col[1]
			));
			}
		}else{
			array_push($response,array(
				'status' => 'GAGAL'
			));
		}
	}else {
		array_push($response,array(
			'statis' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);

?>
