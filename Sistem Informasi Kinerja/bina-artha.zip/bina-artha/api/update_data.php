<?php
require_once('connection.php');

	if($con){
		$username = $_POST['username'];
		$password = $_POST['password'];
		$nik = $_POST['nik'];
		$tipe = $_POST['tipe'];
	$insert = "UPDATE `user` SET `username`='$username',`password`='$password',`tipe`='$tipe' WHERE nik = '$nik';";
	$response = array();
	if($nik !="" && $username !="" && $password !="" && $tipe !="" ){
		$result = mysqli_query($con,$insert);
		$response = array();
		if($result){
			array_push($response, array(
			'status' => 'OK'
		));
		}else{
			array_push($response,array(
			'status' => 'FAILED'
		));		
		}
	}else{
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	}else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);
?>