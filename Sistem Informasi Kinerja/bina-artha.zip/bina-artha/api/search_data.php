<?php
require_once('connection.php');
	if($con){
		$nik = $_POST['nik'];
		//$nik = "201705024578";
		$getData = "SELECT * FROM `user` WHERE nik = '$nik'";
		if($nik !=""){
			$result = mysqli_query($con,$getData);
			$response = array();
			while($row = mysqli_fetch_array($result)){
				array_push($response,array(
					'nik' => $row[0],
					'username' => $row[1],
					'password' => $row[2],
					'tipe' => $row[3]
				));
			}
		}else{
			array_push($response,array(
				'status' => 'FAILED'
			));
		}
	}else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);
?>