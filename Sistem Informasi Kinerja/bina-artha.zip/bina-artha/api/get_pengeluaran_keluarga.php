<?php
require_once('connection.php');
	if($con){
		$id_mitra = $_POST['id_mitra'];
		//$id_mitra = "0213000001";
		$read = "SELECT * FROM `pengeluaran_keluarga` WHERE `id_mitra` = '$id_mitra'";
		$result = mysqli_query($con,$read);
		$response = array();
		while($row = mysqli_fetch_array($result)){
			array_push($response,array(
			'biaya_makan' => $row[1],
			'biaya_listrik' => $row[2],
			'biaya_anak' => $row[3],
			'biaya_kesehatan' => $row[4],
			'biaya_angsuran' => $row[5],
			'biaya_lain2' => $row[6],
			'total_pengeluran' => $row[7],
			'pengahsilan_bersih' => $row[8]
		));
		}
	}else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);

?>