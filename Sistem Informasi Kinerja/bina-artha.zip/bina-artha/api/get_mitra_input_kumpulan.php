<?php
require_once('connection.php');
	if($con){
		$read = "SELECT ukm.id_mitra,mitra.nama_lengkap FROM `ukm` INNER JOIN mitra ON ukm.id_mitra = mitra.id_mitra WHERE ukm.id_kumpulan = ''";
		$result = mysqli_query($con,$read);
		$response = array();
		$rows = mysqli_num_rows($result);
		if($rows > 0){
			while($col = mysqli_fetch_array($result)){
					array_push($response,array(
					'id_mitra' => $col[0],
					'nama' => $col[1]
				));
			}
		}else{
			array_push($response,array(
				'statis' => 'GAGAL'
			));
		}
		
	}else {
		array_push($response,array(
			'statis' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);

?>