<?php
require_once('connection.php');
	if($con){
		$id_mitra = $_POST['id_mitra'];
		//$id_mitra = "0213000001";
		$read = "SELECT mitra.nama_lengkap,mitra.desa,mitra.kecamatan,jenis_usaha.nama_usaha,cekling.hasil1,cekling.hasil2,cekling.hasil3, bi_checking.kolektabilistas,ukm.bsr_pinjaman_dbr FROM `cekling` INNER JOIN `bi_checking` ON cekling.id_mitra = bi_checking.id_mitra INNER JOIN `mitra` ON cekling.id_mitra = mitra.id_mitra INNER JOIN ukm ON cekling.id_mitra = ukm.id_mitra INNER JOIN jenis_usaha ON jenis_usaha.id_mitra = ukm.id_mitra WHERE cekling.id_mitra = '$id_mitra'";
		$result = mysqli_query($con,$read);
		$response = array();
		$row = mysqli_num_rows($result);
		if($row > 0){
			while($col = mysqli_fetch_array($result)){
				array_push($response,array(
					'nama' => $col[0],
					'desa' => $col[1],
					'kecamatan' => $col[2],
					'nama_usaha' => $col[3],
					'hasil1' => $col[4],
					'hasil2' => $col[5],
					'hasil3' => $col[6],
					'coll' => $col[7],
					'pinjaman_dbr' => $col[8]
		));
		}
		}else{
			array_push($response,array(
				'status' => 'GAGAL'
			));
		}
		
	}else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);

?>