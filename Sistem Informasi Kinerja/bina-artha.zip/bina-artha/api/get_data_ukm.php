<?php
require_once('connection.php');
	if($con){
		$id_mitra = $_POST['id_mitra'];
		//$id_mitra = "0213000001";
		$read = "SELECT * FROM `ukm` WHERE `id_mitra` = '$id_mitra'";
		$result = mysqli_query($con,$read);
		$response = array();
		while($row = mysqli_fetch_array($result)){
			array_push($response,array(
			'nik' => $row[0],
			'id_mitra' => $row[1],
			'id_kumpulan' => $row[2],
			'tgl_survei' => $row[3],
			'putaran_pinjaman' => $row[4],
			'bsr_pinjaman_dbr' => $row[5],
			'bsr_pinjaman_ahp' => $row[6],
			'bsr_pinjaman' => $row[7]

		));
		}
	}else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);

?>