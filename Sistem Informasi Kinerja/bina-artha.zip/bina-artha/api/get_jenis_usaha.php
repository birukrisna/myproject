<?php
require_once('connection.php');
	if($con){
		$id_mitra = $_POST['id_mitra'];
		//$id_mitra = "0213000001";
		$read = "SELECT * FROM `jenis_usaha` WHERE `id_mitra` = '$id_mitra'";
		$result = mysqli_query($con,$read);
		$response = array();
		while($row = mysqli_fetch_array($result)){
			if($row[2] == "N"){
					$hasilusahadihindari = "Tidak";
				}else{
					$hasilusahadihindari = "Ya";
				}
			if($row[3] == "Y"){
				$hasilpekerjaanak = "Ya";
			}else{
				$hasilpekerjaanak = "Tidak";
			}
			array_push($response,array(
			'nama_usaha' => $row[1],
			'usaha_dihindari' => $hasilusahadihindari,
			'pekerja_anak' => $hasilpekerjaanak
		));
		}
	}else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);

?>