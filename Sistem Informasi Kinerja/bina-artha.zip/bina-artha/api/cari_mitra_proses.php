<?php
require_once('connection.php');
	if($con){
		$cari = $_POST['cari'];
		//$cari = "Krisna";
		$response = array();
		$read = "SELECT ukm.id_mitra,mitra.nama_lengkap FROM `ukm` INNER JOIN mitra ON ukm.id_mitra = mitra.id_mitra WHERE mitra.nama_lengkap LIKE '%$cari%' or ukm.id_mitra LIKE '%$cari%' and ukm.bsr_pinjaman = ''";
		$result = mysqli_query($con,$read);
		$row = mysqli_num_rows($result);
		if($row > 0){
			while($col = mysqli_fetch_array($result)){
				array_push($response,array(
					'id_mitra' => $col[0],
					'nama' => $col[1]
			));
			}
		}else{
			array_push($response,array(
				'status' => 'GAGAL'
			));
		}
	}else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);

?>
