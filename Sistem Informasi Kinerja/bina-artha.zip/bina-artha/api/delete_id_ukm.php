<?php
require_once('connection.php');
include'get_id_mitra.php';
	if($con){
		$delete = "DELETE FROM `ukm` WHERE id_mitra = '$id_mitra'";
		if($id_mitra !=""){
			$result = mysqli_query($con,$delete);
			$response = array();
			if($result){
			array_push($response, array(
				'status' => 'OK'
			));
			}else{
				array_push($response,array(
					'status' => 'FAILED'
				));
			}
		}else{
			array_push($response,array(
				'status' => 'FAILED'
			));
		}
	}else{
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);
?>