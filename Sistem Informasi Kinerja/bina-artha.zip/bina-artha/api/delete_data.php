<?php
require_once('connection.php');
	if($con){
		$nik = $_POST['nik'];
		$delete = "DELETE FROM `user` WHERE nik = '$nik'";
		if($nik !=""){
			$result = mysqli_query($con,$delete);
			$response = array();
			if($result){
			array_push($response, array(
				'status' => 'OK'
			));
			}else{
				array_push($response,array(
					'status' => 'FAILED'
				));
			}
		}else{
			array_push($response,array(
				'status' => 'FAILED'
			));
		}
	}else{
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);
?>