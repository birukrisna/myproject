<?php
require_once('connection.php');
include'get_id_mitra.php';
	if($con){
		$response = array();
		$nama_penangung_jawab = $_POST['nama_penangung_jawab'];
		$alamat = $_POST['alamat'];
		$desa= $_POST['desa'];
		$kecamatan= $_POST['kecamatan'];
		$rt= $_POST['rt'];
		$rw= $_POST['rw'];
		$kodepos= $_POST['kodepos'];
		$jenis_mitra = $_POST['jenis_mitra'];
		$Id_mitra = $_POST['Id_mitra'];
		if($jenis_mitra =="baru"){
			if($nama_penangung_jawab !="" && $alamat !="" && $desa !="" && $kecamatan !="" && $rt !="" && $rw !="" && $kodepos !=""){
				$insert = "INSERT INTO `penanggung_jawab`(`id_mitra`, `nama_penanggung_jawab`, `alamat`, `desa`, `kecamatan`, `rt`, `rw`, `kodepos`) VALUES ('$id_mitra','$nama_penangung_jawab','$alamat','$desa','$kecamatan','$rt','$rw','$kodepos')";
				$result2 = mysqli_query($con,$insert);
				if($result2){
					array_push($response, array(
						'status' => 'OK'
					));
				}else{
					array_push($response,array(
						'status' => 'GAGAL'
				));		
				}
			}else{
				array_push($response,array(
					'status' => 'FAILED'
				));		
			}
		}else{
			$update = "UPDATE `penanggung_jawab` SET `nama_penanggung_jawab`='$nama_penangung_jawab',`alamat`='$alamat',`desa`='$desa',`kecamatan`='$kecamatan',`rt`='$rt',`rw`='$rw',`kodepos`='$kodepos'WHERE id_mitra = '$Id_mitra'";
			$result2 = mysqli_query($con,$update);
			if($result2){
				array_push($response, array(
					'status' => 'OK'
				));
			}else{
				array_push($response,array(
					'status' => 'GAGAL'
				));		
			}
		}
	}else{
		array_push($response,array(
		'status' => 'FAILED'
		));		
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);
?>