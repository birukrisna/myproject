<?php
require_once('connection.php');
include'get_id_mitra.php';
	if($con){
		$response = array();
		$ramai = $_POST['ramai'];
		$sepi_sedang =$_POST['sepi_sedang'];
		$total = $_POST['total'];
		$rata_rata = $_POST['rata_rata'];
		$tgl = $_POST['tgl'];
		$jam = $_POST['jam'];
		$hari_ini = $_POST['hari_ini'];
		$total_pendapatan = $_POST['total_pendapatan'];
		$jenis_mitra = $_POST['jenis_mitra'];
		$Id_mitra = $_POST['Id_mitra'];	
		if($jenis_mitra == "baru"){
			if($ramai !="" && $sepi_sedang !="" && $total !="" && $rata_rata !="" && $tgl !="" && $hari_ini !="" && $total_pendapatan !=""){
				$insert = "INSERT INTO `pendapatan_usaha`(`id_mitra`, `ramai`, `sepi_sedang`, `total`, `rata_rata`, `tgl`,`jam`,`hari_ini`, `total_pendapatan`) VALUES ('$id_mitra','$ramai','$sepi_sedang','$total','$rata_rata','$tgl','$jam','$hari_ini','$total_pendapatan')";
				$result2 = mysqli_query($con,$insert);
				if($result2){
					array_push($response, array(
						'status' => 'OK'
					));
				}else{
					array_push($response,array(
						'status' => 'GAGAL'
					));		
				}
			}else{
				array_push($response,array(
					'status' => 'FAILED'
				));		
			}
		}else{
			$update= "UPDATE `pendapatan_usaha` SET `ramai`='$ramai',`sepi_sedang`='$sepi_sedang',`total`='$total',`rata_rata`='$rata_rata',`tgl`='$tgl',`jam`='$jam',`hari_ini`='$hari_ini',`total_pendapatan`='$total_pendapatan' WHERE id_mitra = '$Id_mitra'";
			$result2 = mysqli_query($con,$update);
				if($result2){
					array_push($response, array(
						'status' => 'OK'
					));
				}else{
					array_push($response,array(
						'status' => 'GAGAL'
					));		
				}
			}
	}else{
		array_push($response,array(
			'status' => 'FAILED'
		));		
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);
?>

