<?php
require_once('connection.php');
	if($con){
		$id_kumpulan = $_POST['id_kumpulan'];
		//$id_kumpulan = "0001";
		$read = "SELECT ukm.id_mitra,mitra.nama_lengkap,mitra.rumah_lat,mitra.rumah_long FROM `ukm` INNER JOIN mitra ON ukm.id_mitra = mitra.id_mitra WHERE ukm.id_kumpulan  ='$id_kumpulan'";
		$result = mysqli_query($con,$read);
		$response = array();
		$rows = mysqli_num_rows($result);
		if($rows > 0){
			while($row = mysqli_fetch_array($result)){
				array_push($response,array(
				'id_mitra' => $row[0],
				'nama' => $row[1],
				'rumah_lat' => $row[2],
				'rumah_long' => $row[3],
				'jarak' => "jarak"
				));
			}
		}else{
			array_push($response,array(
			'statis' => 'GAGAL'
		));
		}
		
	}else {
		array_push($response,array(
			'statis' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);

?>