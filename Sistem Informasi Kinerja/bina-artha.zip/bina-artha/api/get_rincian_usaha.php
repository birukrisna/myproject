<?php
require_once('connection.php');
	if($con){
		$id_mitra = $_POST['id_mitra'];
		//$id_mitra = "0213000004";
		$read = "SELECT * FROM `rincian_usaha` WHERE `id_mitra` = '$id_mitra'";
		$result = mysqli_query($con,$read);
		$response = array();
		while($row = mysqli_fetch_array($result)){
			if($row[5] =="H"){
				$cputaran_usaha ="28";
			}else if($row[5] =="M"){
				$cputaran_usaha ="4";
			}else if($row[5] =="2M"){
				$cputaran_usaha ="2";
			}else {
				$cputaran_usaha ="1";
			}
			array_push($response,array(
			'lokasi_usaha' => $row[1],
			'lama_usaha' => $row[2],
			'waktu_mulai' => $row[3],
			'waktu_selesai' => $row[4],
			'putaran_usaha' => $cputaran_usaha
		));
		}
	}else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);

?>