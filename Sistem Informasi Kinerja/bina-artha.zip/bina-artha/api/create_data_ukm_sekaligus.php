<?php
require_once('connection.php');
	if($con){
		$id_cabang = '0213';
		$getjlm_baris = "SELECT COUNT(*) FROM ukm";
		$result = mysqli_query($con,$getjlm_baris);
		while($row = mysqli_fetch_array($result)){
			(int)$jml_baris = $row[0] +1 ;
			$jml_huruf = strlen($jml_baris);
			if($jml_huruf ==1){
				$angka0 = "00000";
				$id_urutan = $angka0.$jml_baris;
			}else if($jml_huruf==2){
				$angka0 = "0000";
				$id_urutan = $angka0.$jml_baris;
			}else if($jml_huruf==3){
				$angka0 = "000";
				$id_urutan = $angka0.$jml_baris;
			}else if($jml_huruf==4){
				$angka0 = "00";
				$id_urutan = $angka0.$jml_baris;
			}else if($jml_huruf==5){
				$angka0 = "0";
				$id_urutan = $angka0.$jml_baris;
			}else if($jml_huruf==6){
				$id_urutan = $jml_baris;
			}
		}
		$response = array();
		$id_mitra = $id_cabang.$id_urutan;
		$nik = $_POST['nik'];
		$tgl_survei = $_POST['tgl_survei'];
		$putaran_pinjaman = $_POST['putaran_pinjaman'];
		$bsr_pinjaman_dbr = $_POST['bsr_pinjaman_dbr'];
		//data mitra
		$nama_lengkap = $_POST['nama_lengkap'];
		$nama_panggilan= $_POST['nama_panggilan'];
		$ibu_kandung= $_POST['ibu_kandung'];
		$alamat= $_POST['alamat'];
		$desa= $_POST['desa'];
		$kecamatan= $_POST['kecamatan'];
		$rt= $_POST['rt'];
		$rw= $_POST['rw'];
		$kodepos= $_POST['kodepos'];
		$pendidikan_terakhir= $_POST['pendidikan_terakhir'];
		$nomer_telepon = $_POST['nomer_telepon'];
		$lama_tinggal= $_POST['lama_tinggal'];
		//data ahli penanggung jawab
		$nama_penangung_jawab = $_POST['nama_penangung_jawab'];
		$alamat = $_POST['alamat'];
		$desa= $_POST['desa'];
		$kecamatan= $_POST['kecamatan'];
		$rt= $_POST['rt'];
		$rw= $_POST['rw'];
		$kodepos= $_POST['kodepos'];
		//ahli waris
		$nama_tertanggung = $_POST['nama_tertanggung'];
		$sts_tertanggung = $_POST['sts_tertanggung'];
		$jml_tanggungan = $_POST['jml_tanggungan'];
		$jml_anak = $_POST['jml_anak'];
		$alamat = $_POST['alamat'];
		$desa= $_POST['desa'];
		$kecamatan= $_POST['kecamatan'];
		$rt= $_POST['rt'];
		$rw= $_POST['rw'];
		$kodepos= $_POST['kodepos'];
		//jenis usaha
		$nama_usaha = $_POST['nama_usaha'];
		$usaha_dihindari = $_POST['usaha_dihindari'];
		$pekerja_anak = $_POST['pekerja_anak'];
		if($usaha_dihindari == "Ya"){
			$cusaha_dihindari = "Y";
		}else{
			$cusaha_dihindari = "N";
		}
		if($pekerja_anak == "Ya"){
			$cpekerja_anak = "Y";
		}else{
			$cpekerja_anak = "N";
		}
		//rincian usaha
		$lokasi_usaha = $_POST['lokasi_usaha'];
		$lama_usaha = $_POST['lama_usaha'];
		$waktu_mulai = $_POST['waktu_mulai'];
		$waktu_selesai = $_POST['waktu_selesai'];
		$putaran_usaha = $_POST['putaran_usaha'];
		if($putaran_usaha =="28"){
			$cputaran_usaha ="H";
		}else if($putaran_usaha =="4"){
			$cputaran_usaha ="M";
		}else if($putaran_usaha =="2"){
			$cputaran_usaha ="2M";
		}else {
			$cputaran_usaha ="B";
		}
		//pen_usaha
		$ramai = $_POST['ramai'];
		$sepi_sedang =$_POST['sepi_sedang'];
		$total = $_POST['total'];
		$rata_rata = $_POST['rata_rata'];
		$tgl = $_POST['tgl'];
		$jam = $_POST['jam'];
		$hari_ini = $_POST['hari_ini'];
		$total_pendapatan = $_POST['total_pendapatan'];
		//
		$bahan_baku = $_POST['bahan_baku'];
		$listrik = $_POST['listrik'];
		$tenaga_kerja = $_POST['tenaga_kerja'];
		$transportasi = $_POST['transportasi'];
		$angsuran = $_POST['angsuran'];
		$ketbahan_baku = $_POST['ketbahan_baku'];
		$ketlistrik = $_POST['ketlistrik'];
		$kettenaga_kerja = $_POST['kettenaga_kerja'];
		$kettransportasi = $_POST['kettransportasi'];
		$ketangsuran = $_POST['ketangsuran'];
		$total_pengeluaran = $_POST['total_pengeluaran'];
		$penghasilan_bersih_usaha = $_POST['penghasilan_bersih_usaha'];
		//peng_keluarga
		$biaya_makan = $_POST['biaya_makan'];
		$biaya_listrik = $_POST['biaya_listrik'];
		$biaya_anak = $_POST['biaya_anak'];
		$biaya_kesehatan = $_POST['biaya_kesehatan'];
		$biaya_angsuran = $_POST['biaya_angsuran'];
		$biaya_lain2 = $_POST['biaya_lain2'];
		$total_pengeluran = $_POST['total_pengeluran'];
		$pengahsilan_bersih = $_POST['pengahsilan_bersih'];
		if($nama_lengkap !="" &&$nama_lengkap !="" && $ibu_kandung !="" && $alamat !="" && $desa !="" &&
			$kecamatan !="" && $rt !="" && $rw !="" && $kodepos !="" && $pendidikan_terakhir !="" &&
			$nomer_telepon !="" && $lama_tinggal !="" && $nama_penangung_jawab !="" && $alamat !="" && $desa !="" && $kecamatan !="" && $rt !="" && $rw !="" && $kodepos !="" && $nama_usaha != "" && $pekerja_anak != "" && $usaha_dihindari !="" && $lokasi_usaha !="" && $lama_usaha != "" && $waktu_mulai != "" && $waktu_selesai != "" && $putaran_usaha != "" && $ramai !="" && $sepi_sedang !="" && $total !="" && $rata_rata !="" && $tgl !="" && $hari_ini !="" && $total_pendapatan !=""){
				$insert = "INSERT INTO `ukm`(`nik`, `id_mitra`, `tgl_survei`, `putaran_pinjaman`, `bsr_pinjaman_dbr`) VALUES ('$nik','$id_mitra','$tgl_survei','$putaran_pinjaman','$bsr_pinjaman_dbr')";
				$result2 = mysqli_query($con,$insert);
				//
				$insertukm = "INSERT INTO `mitra`(`id_mitra`, `nama_lengkap`, `nama_panggilan`, `ibu_kandung`, `alamat`, `desa`, `kecamatan`, `rt`, `rw`, `kodepos`, `pendidikan_terakhir`, `nomer_telepon`, `lama_tinggal`) VALUES ('$id_mitra','$nama_lengkap','$nama_panggilan','$ibu_kandung','$alamat','$desa','$kecamatan','$rt','$rw','$kodepos','$pendidikan_terakhir','$nomer_telepon','$lama_tinggal')";
				$resultukm = mysqli_query($con,$insertukm);
				//
				$insertpj = "INSERT INTO `penanggung_jawab`(`id_mitra`, `nama_penanggung_jawab`, `alamat`, `desa`, `kecamatan`, `rt`, `rw`, `kodepos`) VALUES ('$id_mitra','$nama_penangung_jawab','$alamat','$desa','$kecamatan','$rt','$rw','$kodepos')";
				$resultpj = mysqli_query($con,$insertpj);
				//
				$insertaw = "INSERT INTO `ahli_waris`(`id_mitra`, `nama_tertanggung`, `sts_tertanggung`, `jml_tanggungan`, `jml_anak`, `alamat`, `desa`, `kecamatan`, `rt`, `rw`, `kodepos`) VALUES ('$id_mitra','$nama_tertanggung','$sts_tertanggung','$jml_tanggungan ','$jml_anak','$alamat','$desa','$kecamatan','$rt','$rw','$kodepos')";
				$resultaw = mysqli_query($con,$insertaw);
				//
				$insertju = "INSERT INTO `jenis_usaha`(`id_mitra`, `nama_usaha`, `usaha_dihindari`, `pekerja_anak`) VALUES ('$id_mitra','$nama_usaha','$cusaha_dihindari','$cpekerja_anak')";
				$resultju = mysqli_query($con,$insertju);
				//
				$insertru = "INSERT INTO `rincian_usaha`(`id_mitra`, `lokasi_usaha`, `lama_usaha`, `waktu_mulai`, `waktu_selesai`, `putaran_usaha`) VALUES ('$id_mitra','$lokasi_usaha','$lama_usaha','$waktu_mulai','$waktu_selesai','$cputaran_usaha')";
				$result2 = mysqli_query($con,$insertru);
				//
				$insertpen_usaha = "INSERT INTO `pendapatan_usaha`(`id_mitra`, `ramai`, `sepi_sedang`, `total`, `rata_rata`, `tgl`,`jam`,`hari_ini`, `total_pendapatan`) VALUES ('$id_mitra','$ramai','$sepi_sedang','$total','$rata_rata','$tgl','$jam','$hari_ini','$total_pendapatan')";
				$resultpen_usaha = mysqli_query($con,$insertpen_usaha);
				//
				$insertpeng_usaha = "INSERT INTO `pengeluaran_usaha`(`id_mitra`, `bahan_baku`, `listrik`, `tenaga_kerja`, `transportasi`, `angsuran`,`ket_bahanbaku`, `ket_listrik`, `ket_tenaga_kerja`, `ket_transportasi`, `ket_angsuran`, `total_pengeluaran`, `penghasilan_bersih_usaha`) VALUES ('$id_mitra','$bahan_baku','$listrik','$tenaga_kerja','$transportasi','$angsuran','$ketbahan_baku','$ketlistrik','$kettenaga_kerja','$kettransportasi','$ketangsuran','$total_pengeluaran','$penghasilan_bersih_usaha')";
				$resultpeng_usaha = mysqli_query($con,$insertpeng_usaha);
				//
				$insertpeng_keluarga = "INSERT INTO `pengeluaran_keluarga`(`id_mitra`, `biaya_makan`,`biaya_listrik`, `biaya_anak`, `biaya_kesehatan`, `biaya_angsuran`, `biaya_lain2`, `total_pengeluran`, `pengahsilan_bersih`) VALUES ('$id_mitra','$biaya_makan','$biaya_listrik','$biaya_anak','$biaya_kesehatan','$biaya_angsuran','$biaya_lain2','$total_pengeluran','$pengahsilan_bersih')";
				$resultpeng_keluarga = mysqli_query($con,$insertpeng_keluarga);
				if($result2){
					array_push($response, array(
						'status' => 'OK'
				));
				}else{
					array_push($response,array(
						'status' => 'GAGAL'
				));		
				}
				//riwayat pinjaman
				$banyak_lembaga = $_POST['banyak_lembaga'];
				$nama_lembaga1 = $_POST['nama_lembaga1'];
				$jangka_waktu1 = $_POST['jangka_waktu1'];
				$tahun_kredit1 = $_POST['tahun_kredit1'];
				$besar_pinjaman1 = $_POST['besar_pinjaman1'];
				$angsuran1 = $_POST['angsuran1'];
				$sisa_pinjaman1 = $_POST['sisa_pinjaman1'];
				$frekuensi_angsuran1 = $_POST['frekuensi_angsuran1'];
				$nama_lembaga2 = $_POST['nama_lembaga2'];
				$jangka_waktu2 = $_POST['jangka_waktu2'];
				$tahun_kredit2 = $_POST['tahun_kredit2'];
				$besar_pinjaman2 = $_POST['besar_pinjaman2'];
				$angsuran2 = $_POST['angsuran2'];
				$sisa_pinjaman2 = $_POST['sisa_pinjaman2'];
				$frekuensi_angsuran2 = $_POST['frekuensi_angsuran2'];
				$nama_lembaga3 = $_POST['nama_lembaga3'];
				$jangka_waktu3 = $_POST['jangka_waktu3'];
				$tahun_kredit3 = $_POST['tahun_kredit3'];
				$besar_pinjaman3 = $_POST['besar_pinjaman3'];
				$angsuran3 = $_POST['angsuran3'];
				$sisa_pinjaman3 = $_POST['sisa_pinjaman3'];
				$frekuensi_angsuran3 = $_POST['frekuensi_angsuran3'];
				if($banyak_lembaga =="1") {
					if($nama_lembaga1 !="" && $jangka_waktu1 !="" && $tahun_kredit1 !="" && $besar_pinjaman1 !="" && $angsuran1 !="" && $sisa_pinjaman1 !="" && $frekuensi_angsuran1 !=""){
						$insert1 ="INSERT INTO `riwayat_pinjaman`(`id_mitra`, `nama_lembaga`, `jangka_waktu`, `tahun_kredit`, `besar_pinjaman`, `angsuran`, `sisa_pinjaman`, `frekuensi_angsuran`) VALUES ('$id_mitra','$nama_lembaga1','$jangka_waktu1','$tahun_kredit1','$besar_pinjaman1','$angsuran1','$sisa_pinjaman1','$frekuensi_angsuran1')";
						$result2 = mysqli_query($con,$insert1);
						if($result2){
							array_push($response, array(
								'status' => 'OK'
							));
						}else{
							array_push($response,array(
								'status' => 'GAGAL'
							));		
						}
					}else{
						array_push($response,array(
							'status' => 'FAILED'
						));	
					}
				}else if($banyak_lembaga =="2"){
					if($nama_lembaga1 !="" && $jangka_waktu1 !="" && $tahun_kredit1 !="" && $besar_pinjaman1 !="" && $angsuran1 !="" && $sisa_pinjaman1 !="" && $frekuensi_angsuran1 !="" && $nama_lembaga2 !="" && $jangka_waktu2 !="" && $tahun_kredit2 !="" && $besar_pinjaman2 !="" && $angsuran2 !="" && $sisa_pinjaman2 !="" && $frekuensi_angsuran2 !=""){
						$insert1 ="INSERT INTO `riwayat_pinjaman`(`id_mitra`, `nama_lembaga`, `jangka_waktu`, `tahun_kredit`, `besar_pinjaman`, `angsuran`, `sisa_pinjaman`, `frekuensi_angsuran`) VALUES ('$id_mitra','$nama_lembaga1','$jangka_waktu1','$tahun_kredit1','$besar_pinjaman1','$angsuran1','$sisa_pinjaman1','$frekuensi_angsuran1'),('$id_mitra','$nama_lembaga2','$jangka_waktu2','$tahun_kredit2','$besar_pinjaman2','$angsuran2','$sisa_pinjaman2','$frekuensi_angsuran2')";
						$result2 = mysqli_query($con,$insert1);
						if($result2){
							array_push($response, array(
								'status' => 'OK'
							));
						}else{
							array_push($response,array(
								'status' => 'GAGAL'
							));		
						}
					}else{
						array_push($response,array(
							'status' => 'FAILED'
						));	
					}
				}else if($nama_lembaga1 !="" && $jangka_waktu1 !="" && $tahun_kredit1 !="" && $besar_pinjaman1 !="" && $angsuran1 !="" && $sisa_pinjaman1 !="" && $frekuensi_angsuran1 !="" && $nama_lembaga2 !="" && $jangka_waktu2 !="" && $tahun_kredit2 !="" && $besar_pinjaman2 !="" && $angsuran2 !="" && $sisa_pinjaman2 !="" && $frekuensi_angsuran2 !="" && $nama_lembaga3 !="" && $jangka_waktu3 !="" && $tahun_kredit3 !="" && $besar_pinjaman3 !="" && $angsuran3 !="" && $sisa_pinjaman3 !="" && $frekuensi_angsuran3 !=""){
						$insert1 ="INSERT INTO `riwayat_pinjaman`(`id_mitra`, `nama_lembaga`, `jangka_waktu`, `tahun_kredit`, `besar_pinjaman`, `angsuran`, `sisa_pinjaman`, `frekuensi_angsuran`) VALUES ('$id_mitra','$nama_lembaga1','$jangka_waktu1','$tahun_kredit1','$besar_pinjaman1','$angsuran1','$sisa_pinjaman1','$frekuensi_angsuran1'),('$id_mitra','$nama_lembaga2','$jangka_waktu2','$tahun_kredit2','$besar_pinjaman2','$angsuran2','$sisa_pinjaman2','$frekuensi_angsuran2'), ('$id_mitra','$nama_lembaga3','$jangka_waktu3','$tahun_kredit3','$besar_pinjaman3','$angsuran3','$sisa_pinjaman3','$frekuensi_angsuran3')";
						$result2 = mysqli_query($con,$insert1);
						if($result2){
							array_push($response, array(
								'status' => 'OK'
							));
						}else{
							array_push($response,array(
								'status' => 'GAGAL'
							));		
						}
					}else{
						array_push($response,array(
							'status' => 'Tidak Punya'
						));	
					}
					//
					$banyak_keluarga = $_POST['banyak_keluarga'];
					$nama_pemberi1 = $_POST['nama_pemberi1'];
					$hbgan_dng_mitra1 = $_POST['hbgan_dng_mitra1'];
					$pekerjaan1 = $_POST['pekerjaan1'];
					$pendapatan1 = $_POST['pendapatan1'];
					$nama_pemberi2 = $_POST['nama_pemberi2'];
					$hbgan_dng_mitra2 = $_POST['hbgan_dng_mitra2'];
					$pekerjaan2 = $_POST['pekerjaan2'];
					$pendapatan2 = $_POST['pendapatan2'];
					$nama_pemberi3 = $_POST['nama_pemberi3'];
					$hbgan_dng_mitra3 = $_POST['hbgan_dng_mitra3'];
					$pekerjaan3 = $_POST['pekerjaan3'];
					$pendapatan3 = $_POST['pendapatan3'];
					$nama_pemberi4 = $_POST['nama_pemberi4'];
					$hbgan_dng_mitra4 = $_POST['hbgan_dng_mitra4'];
					$pekerjaan4 = $_POST['pekerjaan4'];
					$pendapatan4 = $_POST['pendapatan4'];
					$total_pendapatan = $_POST['total_pendapatan'];
					if($banyak_keluarga == "1"){
						if($nama_pemberi1 != "" && $hbgan_dng_mitra1 != "" && $pekerjaan1 != "" && $pendapatan1 != "" && $total_pendapatan != ""){
							$insert1 = "INSERT INTO `pendapatan_keluarga`(`id_mitra`, `nama_pemberi`, `hbgan_dng_mitra`, `pekerjaan`, `pendapatan`, `total_pendapatan`) VALUES ('$id_mitra','$nama_pemberi1','$hbgan_dng_mitra1','$pekerjaan1',$pendapatan1,$total_pendapatan)";
							$result2 = mysqli_query($con,$insert1);
							if($result2){
								array_push($response, array(
									'status' => 'OK'
								));
							}else{
								array_push($response,array(
									'status' => 'GAGAL'
								));		
							}
						}else{
							array_push($response,array(
								'status' => 'FAILED'
							));	
						}
					}else if ($banyak_keluarga == "2"){
						if($nama_pemberi1 != "" && $hbgan_dng_mitra1 != "" && $pekerjaan1 != "" && $pendapatan1 != "" && $nama_pemberi2 != "" && $hbgan_dng_mitra2 != "" && $pekerjaan2 != "" && $pendapatan2 != "" && $total_pendapatan != ""){
							$insert1 = "INSERT INTO `pendapatan_keluarga`(`id_mitra`, `nama_pemberi`, `hbgan_dng_mitra`, `pekerjaan`, `pendapatan`, `total_pendapatan`) VALUES ('$id_mitra','$nama_pemberi1','$hbgan_dng_mitra1','$pekerjaan1',$pendapatan1,$total_pendapatan),('$id_mitra','$nama_pemberi2','$hbgan_dng_mitra2','$pekerjaan2',$pendapatan2,$total_pendapatan)";
							$result2 = mysqli_query($con,$insert1);
							if($result2){
								array_push($response, array(
									'status' => 'OK'
								));
							}else{
								array_push($response,array(
									'status' => 'GAGAL'
								));		
							}
						}else{
							array_push($response,array(
								'status' => 'FAILED'
							));	
						}
					}else if($banyak_keluarga == "3"){
						if($nama_pemberi1 != "" && $hbgan_dng_mitra1 != "" && $pekerjaan1 != "" && $pendapatan1 != "" && $nama_pemberi2 != "" && $hbgan_dng_mitra2 != "" && $pekerjaan2 != "" && $pendapatan2 != "" && $nama_pemberi3 != "" && $hbgan_dng_mitra3 != "" && $pekerjaan3 != "" && $pendapatan3 != "" && $total_pendapatan != ""){
							$insert1 = "INSERT INTO `pendapatan_keluarga`(`id_mitra`, `nama_pemberi`, `hbgan_dng_mitra`, `pekerjaan`, `pendapatan`, `total_pendapatan`) VALUES ('$id_mitra','$nama_pemberi1','$hbgan_dng_mitra1','$pekerjaan1',$pendapatan1,$total_pendapatan),('$id_mitra','$nama_pemberi2','$hbgan_dng_mitra2','$pekerjaan2',$pendapatan2,$total_pendapatan),'$id_mitra','$nama_pemberi3','$hbgan_dng_mitra3','$pekerjaan3',$pendapatan3,$total_pendapatan)";
							$result2 = mysqli_query($con,$insert1);
							if($result2){
								array_push($response, array(
									'status' => 'OK'
								));
							}else{
								array_push($response,array(
									'status' => 'GAGAL'
								));		
							}
						}else{
							array_push($response,array(
								'status' => 'FAILED'
							));	
						}
					}else {
						if($nama_pemberi1 != "" && $hbgan_dng_mitra1 != "" && $pekerjaan1 != "" && $pendapatan1 != "" && $nama_pemberi2 != "" && $hbgan_dng_mitra2 != "" && $pekerjaan2 != "" && $pendapatan2 != "" && $nama_pemberi3 != "" && $hbgan_dng_mitra3 != "" && $pekerjaan4 != "" && $pendapatan3 != "" && $nama_pemberi4 != "" && $hbgan_dng_mitra4 != "" && $pekerjaan4 != "" && $pendapatan4 != "" && $total_pendapatan != ""){
							$insert1 = "INSERT INTO `pendapatan_keluarga`(`id_mitra`, `nama_pemberi`, `hbgan_dng_mitra`, `pekerjaan`, `pendapatan`, `total_pendapatan`) VALUES ('$id_mitra','$nama_pemberi1','$hbgan_dng_mitra1','$pekerjaan1',$pendapatan1,$total_pendapatan),('$id_mitra','$nama_pemberi2','$hbgan_dng_mitra2','$pekerjaan2',$pendapatan2,$total_pendapatan),'$id_mitra','$nama_pemberi3','$hbgan_dng_mitra3','$pekerjaan3',$pendapatan3,$total_pendapatan),'$id_mitra','$nama_pemberi4','$hbgan_dng_mitra4','$pekerjaan4',$pendapatan4,$total_pendapatan)";
							$result2 = mysqli_query($con,$insert1);
							if($result2){
								array_push($response, array(
									'status' => 'OK'
								));
							}else{
								array_push($response,array(
									'status' => 'GAGAL'
								));		
							}
						}else{
							array_push($response,array(
								'status' => 'FAILED'
							));	
						}
					}
		}else{
			array_push($response,array(
				'status' => 'kosong'
		));
		}
	}else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);
?>