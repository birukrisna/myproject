<?php
require_once('connection.php');
	if($con){
		$id_mitra = $_POST['id_mitra'];
		//$id_mitra = "0213000001";
		$read = "SELECT * FROM `pendapatan_usaha` WHERE `id_mitra` = '$id_mitra'";
		$result = mysqli_query($con,$read);
		$response = array();
		while($row = mysqli_fetch_array($result)){
			array_push($response,array(
			'ramai' => $row[1],
			'sepi_sedang' => $row[2],
			'total' => $row[3],
			'rata_rata' => $row[4],
			'tgl' => $row[5],
			'jam' => $row[6],
			'hari_ini' => $row[7],
			'total_pendapatan' => $row[8]
		));
		}
	}else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);

?>