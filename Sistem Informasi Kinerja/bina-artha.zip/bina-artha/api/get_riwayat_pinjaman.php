<?php
require_once('connection.php');
	if($con){
		$id_mitra = $_POST['id_mitra'];
		//$id_mitra = "0213000001";
		$read = "SELECT * FROM `riwayat_pinjaman` WHERE `id_mitra` = '$id_mitra'";
		$result = mysqli_query($con,$read);
		$response = array();
		while($col = mysqli_fetch_array($result)){
			array_push($response,array(
			'nama_lembaga' => $col[1],
			'jangka_waktu' => $col[2],
			'tahun_kredit' => $col[3],
			'besar_pinjaman' => $col[4],
			'angsuran' => $col[5],
			'sisa_angsuran' => $col[6],	
			'sisa_pinjaman' => $col[7],
			'frekuensi_angsuran' => $col[8]
		));
		}
	}else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);

?>