<?php
require_once('connection.php');
	if($con){
		$response = array();
		$id_mitra = $_POST['id_mitra'];
		$bsr_pinjaman_ahp = $_POST['bsr_pinjaman_ahp'];
		/*$id_mitra = "0213000001";
		$bsr_pinjaman_ahp = "";*/
		$update ="UPDATE `ukm` SET `bsr_pinjaman_ahp` = '$bsr_pinjaman_ahp' WHERE `ukm`.`id_mitra` = '$id_mitra'";
		$result2 = mysqli_query($con,$update);
		if($result2){
			array_push($response, array(
				'status' => 'OK'
			));
		}else{
			array_push($response,array(
				'status' => 'GAGAL'
			));		
		}	
	}else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);
?>	