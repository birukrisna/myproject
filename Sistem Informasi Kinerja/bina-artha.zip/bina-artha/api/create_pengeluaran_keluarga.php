<?php
require_once('connection.php');
include'get_id_mitra.php';
	if($con){
		$response = array();
		$biaya_makan = $_POST['biaya_makan'];
		$biaya_listrik = $_POST['biaya_listrik'];
		$biaya_anak = $_POST['biaya_anak'];
		$biaya_kesehatan = $_POST['biaya_kesehatan'];
		$biaya_angsuran = $_POST['biaya_angsuran'];
		$biaya_lain2 = $_POST['biaya_lain2'];
		$total_pengeluran = $_POST['total_pengeluran'];
		$pengahsilan_bersih = $_POST['pengahsilan_bersih'];
		$jenis_mitra = $_POST['jenis_mitra'];
		$Id_mitra = $_POST['Id_mitra'];	
		if($jenis_mitra =="baru"){
			$insert = "INSERT INTO `pengeluaran_keluarga`(`id_mitra`, `biaya_makan`,`biaya_listrik`, `biaya_anak`, `biaya_kesehatan`, `biaya_angsuran`, `biaya_lain2`, `total_pengeluran`, `pengahsilan_bersih`) VALUES ('$id_mitra','$biaya_makan','$biaya_listrik','$biaya_anak','$biaya_kesehatan','$biaya_angsuran','$biaya_lain2','$total_pengeluran','$pengahsilan_bersih')";
			$result2 = mysqli_query($con,$insert);
			if($result2){
				array_push($response, array(
					'status' => 'OK'
				));
			}else{
				array_push($response,array(
					'status' => 'GAGAL'
				));		
			}
		}else if($jenis_mitra =="lama"){
			$update = "UPDATE `pengeluaran_keluarga` SET `biaya_makan`='$biaya_makan',`biaya_listrik`='$biaya_listrik',`biaya_anak`='$biaya_anak',`biaya_kesehatan`='$biaya_kesehatan',`biaya_angsuran`='$biaya_angsuran',`biaya_lain2`='$biaya_lain2',`total_pengeluran`='$total_pengeluran',`pengahsilan_bersih`='$pengahsilan_bersih' WHERE id_mitra ='Id_mitra'"; 
			$result2 = mysqli_query($con,$update);
			if($result2){
				array_push($response, array(
					'status' => 'OK'
				));
			}else{
				array_push($response,array(
					'status' => 'GAGAL'
				));		
			}
		}else{
			array_push($response,array(
				'status' => 'GAGAL'
			));
		}
		
	}else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);
?>