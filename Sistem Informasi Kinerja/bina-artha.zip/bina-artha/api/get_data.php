<?php
require_once('connection.php');
	if($con){
		$read = "SELECT * FROM `user`";
		//$read = "SELECT karyawan.nik,karyawan.nama,user.password,user.tipe FROM user INNER JOIN karyawan ON karyawan.nik = user.nik";
		$result = mysqli_query($con,$read);
		$response = array();

		while($row = mysqli_fetch_array($result)){
			array_push($response,array(
			'nik' => $row[0],
			'username' => $row[1],
			'password' => $row[2],
			'tipe' => $row[3]
		));
		}
	}else {
		array_push($response,array(
			'statis' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);

?>