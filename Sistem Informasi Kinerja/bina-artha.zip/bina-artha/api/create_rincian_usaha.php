<?php
require_once('connection.php');
include'get_id_mitra.php';
	if($con){
		$response = array();
		$lokasi_usaha = $_POST['lokasi_usaha'];
		$lama_usaha = $_POST['lama_usaha'];
		$waktu_mulai = $_POST['waktu_mulai'];
		$waktu_selesai = $_POST['waktu_selesai'];
		$putaran_usaha = $_POST['putaran_usaha'];
		if($putaran_usaha =="28"){
			$cputaran_usaha ="H";
		}else if($putaran_usaha =="4"){
			$cputaran_usaha ="M";
		}else if($putaran_usaha =="2"){
			$cputaran_usaha ="2M";
		}else {
			$cputaran_usaha ="B";
		}
		$jenis_mitra = $_POST['jenis_mitra'];
		$Id_mitra = $_POST['Id_mitra'];
		if($jenis_mitra == "baru"){
			if($lokasi_usaha !="" && $lama_usaha != "" && $waktu_mulai != "" && $waktu_selesai != "" && $putaran_usaha != ""){
			$insert = "INSERT INTO `rincian_usaha`(`id_mitra`, `lokasi_usaha`, `lama_usaha`, `waktu_mulai`, `waktu_selesai`, `putaran_usaha`) VALUES ('$id_mitra','$lokasi_usaha','$lama_usaha','$waktu_mulai','$waktu_selesai','$cputaran_usaha')";
			$result2 = mysqli_query($con,$insert);
			if($result2){
				array_push($response, array(
				'status' => 'OK'
				));
			}else{
				array_push($response,array(
				'status' => 'GAGAL'
				));		
			}
		}else{
			array_push($response,array(
				'status' => 'FAILED'
			));		
		}
		}else {
			$update ="UPDATE `rincian_usaha` SET `lokasi_usaha`='$lokasi_usaha',`lama_usaha`='$lama_usaha',`waktu_mulai`='$waktu_mulai',`waktu_selesai`='$waktu_selesai',`putaran_usaha`='$cputaran_usaha' WHERE id_mitra ='$Id_mitra'";
			$result2 = mysqli_query($con,$update);
			if($result2){
				array_push($response, array(
				'status' => 'OK'
				));
			}else{
				array_push($response,array(
				'status' => 'GAGAL'
				));		
			}
		}
	}else{
		array_push($response,array(
		'status' => 'FAILED'
		));		
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);
?>