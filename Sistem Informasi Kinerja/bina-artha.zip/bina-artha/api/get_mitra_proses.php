<?php
require_once('connection.php');
	if($con){
		$read = "SELECT ukm.id_mitra,mitra.nama_lengkap FROM `ukm` INNER JOIN mitra ON ukm.id_mitra = mitra.id_mitra WHERE ukm.bsr_pinjaman = ''";
		$result = mysqli_query($con,$read);
		$response = array();

		while($row = mysqli_fetch_array($result)){
			array_push($response,array(
			'id_mitra' => $row[0],
			'nama' => $row[1]
		));
		}
	}else {
		array_push($response,array(
			'statis' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);

?>