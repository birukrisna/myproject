<?php
require_once('connection.php');
include'get_id_mitra.php';
	if($con){
		$response = array();
		$nama_usaha = $_POST['nama_usaha'];
		$usaha_dihindari = $_POST['usaha_dihindari'];
		$pekerja_anak = $_POST['pekerja_anak'];
		if($usaha_dihindari == "Ya"){
			$cusaha_dihindari = "Y";
		}else{
			$cusaha_dihindari = "N";
		}
		if($pekerja_anak == "Ya"){
			$cpekerja_anak = "Y";
		}else{
			$cpekerja_anak = "N";
		}
		$jenis_mitra = $_POST['jenis_mitra'];
		$Id_mitra = $_POST['Id_mitra'];
		if($jenis_mitra =="baru"){
			if($nama_usaha != "" && $pekerja_anak != "" && $usaha_dihindari !=""){
				$insert = "INSERT INTO `jenis_usaha`(`id_mitra`, `nama_usaha`, `usaha_dihindari`, `pekerja_anak`) VALUES ('$id_mitra','$nama_usaha','$cusaha_dihindari','$cpekerja_anak')";
				$result2 = mysqli_query($con,$insert);
				if($result2){
					array_push($response, array(
						'status' => 'OK'
					));
				}else{
					array_push($response,array(
						'status' => 'GAGAL'
				));		
				}
			}else{
				array_push($response,array(
					'status' => 'FAILED'
				));		
			}
		}else{
			$update = "UPDATE `jenis_usaha` SET `nama_usaha`='$nama_usaha',`usaha_dihindari`='$cusaha_dihindari',`pekerja_anak`='$cpekerja_anak' WHERE id_mitra = '$Id_mitra'";
			$result2 = mysqli_query($con,$update);
			if($result2){
				array_push($response, array(
					'status' => 'OK'
				));
			}else{
				array_push($response,array(
					'status' => 'GAGAL'
			));		
			}
		}
	}else{
		array_push($response,array(
			'status' => 'FAILED'
		));		
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);
?>