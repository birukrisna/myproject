<?php
require_once('connection.php');
	if($con){
		$response = array();
		$id_mitra = $_POST['id_mitra'];
		$kondisi = $_POST['kondisi'];
		$nm_nrsmber1 = $_POST['nm_nrsmber1'];
		$nm_nrsmber2 = $_POST['nm_nrsmber2'];
		$nm_nrsmber3 = $_POST['nm_nrsmber3'];
		$hasil1 = $_POST['hasil1'];
		$hasil2 = $_POST['hasil2'];
		$hasil3 = $_POST['hasil3'];
		/*$id_mitra ="update";
		$kondisi ="update";
		$nm_nrsmber1 = "2";
		$nm_nrsmber2 = "2";
		$nm_nrsmber3 = "2";
		$hasil1 = "2";
		$hasil2 = "2";
		$hasil3 = "2";*/
		if($kondisi =="update"){
			$update ="UPDATE `cekling` SET `nm_nrsmber1`='$nm_nrsmber1',`hasil1`='$hasil1',`nm_nrsmber2`='$nm_nrsmber2',`hasil2`='$hasil2',`nm_nrsmber3`='$nm_nrsmber3',`hasil3`='$hasil3' WHERE id_mitra = '$id_mitra'";
			$result2 = mysqli_query($con,$update);
			if($result2){
				array_push($response, array(
					'status' => 'OK'
				));
			}else{
				array_push($response,array(
					'status' => 'GAGALLL'
				));		
			}	
		}else if($kondisi == "baru"){
			$insert = "INSERT INTO `cekling`(`id_mitra`, `nm_nrsmber1`, `hasil1`, `nm_nrsmber2`, `hasil2`, `nm_nrsmber3`, `hasil3`) VALUES ('$id_mitra','$nm_nrsmber1','$hasil1','$nm_nrsmber2','$hasil2','$nm_nrsmber3','$hasil3')";
			$result2 = mysqli_query($con,$insert);
			if($result2){
				array_push($response, array(
					'status' => 'OK'
				));
			}else{
				array_push($response,array(
					'status' => 'GAGA'
				));		
			}		
		}else{
			array_push($response,array(
				'status' => 'FAILED'
			));	
		}
	}else {
		array_push($response,array(
			'status' => 'FAILED'
		));
	}
	echo json_encode(array("server_response" => $response));
	mysqli_close($con);
?>