<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct()
	{
		parent::__construct();
		$this->load->model('m_login');
	}	
	public function index()
	{
		$this->load->view('login');
	}
	public function aksi_login()
	{
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$tipe = 'AO';
		$tipe_login = array(
			'username' => $username,
			'password' => $password,
			'tipe' => $tipe
		);
		$where = array(
			'username' =>$username,
			'password' =>$password,
		);
		$cek = $this->m_login->cek_login('user',$where)->num_rows();
		if($cek > 0)
		{	
			$cek_tipe = $this->m_login->cek_tipe_login('user',$tipe_login)->num_rows();
			if ($cek_tipe >0){
				$this->load->view('login_ao');
			}else{
				$data_sesion = array(
				'nama' => $username,
				'status' => 'login'
			);
			$this->session->set_userdata($data_sesion);
			redirect('c_admin');
			}
		}else{
			$this->load->view('login_false');
		}
	}
}
