<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_admin extends CI_Controller {
	
	function __construct(){
		parent::__construct();
		$this->load->model('m_admin');
		$this->load->library('form_validation');
		$this->load->helper('url');
		if($this->session->userdata('status') !="login"){
			redirect('Welcome');
		}
		
	}
	function index()
	{
		$username = $this->session->userdata("nama");
		$cek_user = array('user.username' => $username);
		$tahun = date('Y');
		$data = array(
			'nama_user' => $this->m_admin->cek_nama_user('user',$cek_user)->result(),
			'pencapaian' => $this->m_admin->pencapaian_tahun()->result(),
			'pencapaian_bulan' => $this->m_admin->cabang_pencapaian_bulan()->result(),
			'ukm' =>$this->m_admin->jml_mtra_ukm_tahun()->result(),
			'lkkm' =>$this->m_admin->jml_mtra_lkkm_tahun()->result(),
			'upkm' =>$this->m_admin->jml_mtra_upkm_tahun()->result(),
			'pencairan' =>$this->m_admin->jml_pencairan_tahun()->result()
		);
		$this->load->view('home',$data);
	}
	function list_kumpulan_proses()
	{
		$username = $this->session->userdata("nama");
		$cek_user = array('user.username' => $username);
		$data = array(
			'nama_user' => $this->m_admin->cek_nama_user('user',$cek_user)->result(),
			'kumpulan' => $this->m_admin->tampil_data_kumpulan_proses()->result()

		);
		$this->load->view('list_kumpulan_proses',$data);
	}
	function input_plafond($id_kumpulan)
	{
		$username = $this->session->userdata("nama");
		$where = array('ukm.id_kumpulan' => $id_kumpulan);
		$cek_user = array('user.username' => $username);
		$data = array(
			'nama_user' => $this->m_admin->cek_nama_user('user',$cek_user)->result(),
			'kumpulan' => $this->m_admin->input_plafon($where,'kumpulan')->result(),
			'id_kumpulan' => $id_kumpulan
		);
		$this->load->view('plafon',$data);
	}
	function edit_tracking()
	{
		$username = $this->session->userdata("nama");
		$cek_user = array('user.username' => $username);
		$id_kumpulan = $this->input->post('id_kumpulanedit');
		$tgl_kirim = $this->input->post('tgl_kirimedit');
		$where = array('tracking.id_kumpulan' => $id_kumpulan,
						'tracking.tgl_kirim'=>$tgl_kirim);
		$data = array(
			'nama_user' => $this->m_admin->cek_nama_user('user',$cek_user)->result(),
			'tracking' => $this->m_admin->edit_tracking($where,'tracking')->result(),
			'id_kumpulan' => $id_kumpulan
		);
		$this->load->view('edit_tracking',$data);
	}
	function update_pinjaman()
	{
		$id_regional = $this->input->post('id_regional');
		$id_area = $this->input->post('id_area');
		$cabang = $this->input->post('cabang');
		$nik = $this->input->post('nik');
		$id_kumpulan = $this->input->post('id_kumpulan');
		$tipe_pengajuan = $this->input->post('tipe_pengajuan');
		$tipe_pinjaman = $this->input->post('tipe_pinjaman');
		$bulan = date('m');
        $tahun = date('Y');
        $kode = $bulan.$tahun;
        $tgl_kirim = date('Y-m-d');
		$where1 = array('id_kumpulan' => $id_kumpulan);
		$banyak = $this->m_admin->jumlah_data($where1,'ukm');
		$id="id_mitra";
		$id2="bsr_pinjaman";
		$total_plafond=0;
		for($x=1;$x<=$banyak;$x++){
			$id_mitra =$id.$x; 
			$$id_mitra = $this->input->post('id_mitra'.$x);
			$bsr_pinjaman = $id2.$x;
			$$bsr_pinjaman = $this->input->post('bsr_pinjaman'.$x);
			$where = array(
				'id_mitra' => $$id_mitra,
			 );
			$data = array('bsr_pinjaman' => $$bsr_pinjaman,
						'tgl_kirim' => $tgl_kirim);
			$this->m_admin->input_pinjaman($where,$data,'ukm');
			$total_plafond = $total_plafond + $$bsr_pinjaman;
		}
		$data = array(
			'id_tracking' => $kode,
			'nik_petugas' => $nik,
			'id_kumpulan' => $id_kumpulan,
			'tipe_pengajuan' => $tipe_pengajuan,
			'tipe_pinjaman' => $tipe_pinjaman,
			'tgl_kirim' => $tgl_kirim,
			'jml_mitra' => $banyak,
			'jml_pencairan' => $total_plafond
			);
		$this->m_admin->input_tracking($data,'tracking');
		redirect('c_admin/tracking');

	}
	function update_tracking(){
		$id_tracking = $this->input->post('id_tracking');
		$where = array('id_tracking'=>$id_tracking);
		$banyak = $this->m_admin->banyak_data_bulan($where,'tracking');
		$id="tgl_revisi";
		$id2="tgl_ok";
		$id3="tgl_lkkm1";
		$id4="tgl_lkkm2";
		$id5="tgl_pengesahan";
		$id6="tgl_pencairan";
		$id7="jml_mitra";
		$id8="jml_pencairan";
		$id9="id_kumpulan";
		$id10="tgl_kirim";
		for($x=1;$x<=$banyak;$x++){
			$tgl_revisi =$id.$x; 
			$$tgl_revisi = $this->input->post('tgl_revisi'.$x);
			$tgl_ok =$id2.$x; 
			$$tgl_ok = $this->input->post('tgl_ok'.$x);
			$tgl_lkkm1 =$id3.$x; 
			$$tgl_lkkm1 = $this->input->post('tgl_lkkm1'.$x);
			$tgl_lkkm2 =$id4.$x; 
			$$tgl_lkkm2 = $this->input->post('tgl_lkkm2'.$x);
			$tgl_pengesahan =$id5.$x; 
			$$tgl_pengesahan = $this->input->post('tgl_pengesahan'.$x);
			$tgl_pencairan =$id6.$x; 
			$$tgl_pencairan = $this->input->post('tgl_pencairan'.$x);
			$jml_mitra =$id7.$x; 
			$$jml_mitra = $this->input->post('jml_mitra'.$x);
			$jml_pencairan =$id8.$x; 
			$$jml_pencairan = $this->input->post('jml_pencairan'.$x);
			$id_kumpulan =$id9.$x; 
			$$id_kumpulan = $this->input->post('id_kumpulan'.$x);
			$tgl_kirim =$id10.$x; 
			$$tgl_kirim = $this->input->post('tgl_kirim'.$x);
			$where = array(
				'id_kumpulan' => $$id_kumpulan,
				'tgl_kirim' => $$tgl_kirim
			 );
			$data = array(
				'tgl_revisi' =>$$tgl_revisi,
				'tgl_ok' =>$$tgl_ok,
				'tgl_lkkm1' =>$$tgl_lkkm1,
				'tgl_lkkm2' =>$$tgl_lkkm2,
				'tgl_pengesahan' =>$$tgl_pengesahan,
				'tgl_pencairan' =>$$tgl_pencairan,
				'jml_mitra' =>$$jml_mitra,
				'jml_pencairan' => $$jml_pencairan
			);
			$data2 = array ('bsr_pinjaman'=>'0');
			if($$jml_mitra==0){
				$this->m_admin->hapus_data($where,'tracking');
				$this->m_admin->hapus_pinjaman($where,$data2,'ukm');
			}else{
				$this->m_admin->input_pinjaman($where,$data,'tracking');
			}
		}
		$username = $this->session->userdata("nama");
		$cek_user = array('user.username' => $username);
		$cek_id_tracking = array('tracking.id_tracking' =>$id_tracking);
		$data = array(
			'nama_user' => $this->m_admin->cek_nama_user('user',$cek_user)->result(),
			'tracking' =>$this->m_admin->cek_tracking($cek_id_tracking,'karyawan')->result(),
			'list' =>$this->m_admin->list_id_tracking()->result(),
			'ukm' =>$this->m_admin->jml_mtra_ukm($cek_id_tracking,'tracking')->result(),
			'lkkm' =>$this->m_admin->jml_mtra_lkkm($cek_id_tracking,'tracking')->result(),
			'upkm' =>$this->m_admin->jml_mtra_upkm($cek_id_tracking,'tracking')->result(),
			'pencairan' =>$this->m_admin->jml_pencairan($cek_id_tracking,'tracking')->result()
		);
		$this->load->view('tracking',$data);
	}
	function tracking()
	{
		
		$bulan = date('m');
        $tahun = date('Y');
        $kode = $bulan.$tahun;
		$where = array('tgl_pencairan' => '0000-00-00');
		$update = array('id_tracking'=>$kode);
		$this->m_admin->update_id_tracking($where,$update,'tracking');
		$username = $this->session->userdata("nama");
		$cek_user = array('user.username' => $username);
		$cek_id_tracking = array('tracking.id_tracking' =>$kode);
		$data = array(
			'nama_user' => $this->m_admin->cek_nama_user('user',$cek_user)->result(),
			'tracking' =>$this->m_admin->cek_tracking($cek_id_tracking,'karyawan')->result(),
			'list' =>$this->m_admin->list_id_tracking()->result(),
			'ukm' =>$this->m_admin->jml_mtra_ukm($cek_id_tracking,'tracking')->result(),
			'lkkm' =>$this->m_admin->jml_mtra_lkkm($cek_id_tracking,'tracking')->result(),
			'upkm' =>$this->m_admin->jml_mtra_upkm($cek_id_tracking,'tracking')->result(),
			'pencairan' =>$this->m_admin->jml_pencairan($cek_id_tracking,'tracking')->result()
		);
		$this->load->view('tracking',$data);
	}
	function bulan_tracking(){
		$username = $this->session->userdata("nama");
		$cek_user = array('user.username' => $username);
		$tracking = $this->input->post('id_Tracking');
		$cek_id_tracking = array('tracking.id_tracking' =>$tracking);
		$data = array(
			'nama_user' => $this->m_admin->cek_nama_user('user',$cek_user)->result(),
			'tracking' =>$this->m_admin->cek_tracking($cek_id_tracking,'karyawan')->result(),
			'list' =>$this->m_admin->list_id_tracking()->result(),
			'ukm' =>$this->m_admin->jml_mtra_ukm($cek_id_tracking,'tracking')->result(),
			'lkkm' =>$this->m_admin->jml_mtra_lkkm($cek_id_tracking,'tracking')->result(),
			'upkm' =>$this->m_admin->jml_mtra_upkm($cek_id_tracking,'tracking')->result(),
			'pencairan' =>$this->m_admin->jml_pencairan($cek_id_tracking,'tracking')->result()
		);
		$this->load->view('tracking',$data);
	}
	function report(){
		$username = $this->session->userdata("nama");
		$cek_user = array('user.username' => $username);
		$nama = $this->input->post('Nama_Karyawan');
		$jenis = $this->input->post('Jenis_Report');
		$pawal = $this->input->post('Priode_Awal');
		$pakhir = $this->input->post('Priode_Akhir');
		$where = array('karyawan.nik' => $nama);
		$data = array(
			'nama_user' => $this->m_admin->cek_nama_user('user',$cek_user)->result(),
			'list_karyawan' => $this->m_admin->list_karyawan()->result(),
			'nama' => $this->m_admin->cek_nama_karyawan($where,'karyawan')->result(),
			'report' => $this->m_admin->report($where,$pawal,$pakhir,'tracking')->result(),
			'list' =>$this->m_admin->list_id_tracking()->result()
		);
		$this->load->view('report',$data);
	}
	
	function logout(){
	$this->session->sess_destroy();
	redirect('Welcome');
	}
}
