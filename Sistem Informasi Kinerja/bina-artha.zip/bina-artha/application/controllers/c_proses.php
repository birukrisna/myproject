<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * 
 */
class C_proses extends CI_Controller
{
	
	function __construct()
	{
		parent ::__construct();
		$this->load->model('m_proses');
		$this->load->helper('url');
	}
	function index()
	{
		$id_mitra= $this->input->post('id_mitra');
		$id_kumpulan = $this->input->post('id_kumpulan');
		$where = array('ukm.id_mitra'=> $id_mitra);
		$where2 = array('id_kumpulan'=> $id_kumpulan);
		$data= array(
				'mitra' => $this->m_proses->cari_mitra('ukm',$where)->result(),
				'proses' => $this->m_proses->cari_tracking('tracking',$where2)->result()
				);
		$this->load->view('proses',$data);
	}
	function cari(){
		$id_mitra= $this->input->post('id_mitra');
		$id_kumpulan = $this->input->post('id_kumpulan');
		$tgl_kirim = $this->input->post('tgl_kirim');
		$where2 = array('id_kumpulan'=> $id_kumpulan,'tgl_kirim'=> $tgl_kirim);
		$where = array('ukm.id_mitra'=> $id_mitra);
		$cek = $this->m_proses->cari_mitra('ukm',$where)->num_rows();
		$data= array(
				'mitra' => $this->m_proses->cari_mitra('ukm',$where)->result(),
				'proses' => $this->m_proses->cari_tracking('tracking',$where2)->result()
				);
		if($cek>0){
			$this->load->view('proses_cari',$data);	
		}else{
			$this->load->view('proses_cari_eror',$data);
		}
		

	}

}