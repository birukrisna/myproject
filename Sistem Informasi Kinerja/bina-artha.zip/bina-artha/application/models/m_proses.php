<?php

/**
 * 
 */
class M_proses extends CI_Model
{
	function cari_mitra($table,$where){
	$this->db->select('mitra.id_mitra,mitra.nama_lengkap,kumpulan.nama_kumpulan,ukm.tgl_kirim,ukm.id_kumpulan,ukm.bsr_pinjaman');
	$this->db->join('mitra','mitra.id_mitra = ukm.id_mitra');
	$this->db->join('kumpulan','kumpulan.id_kumpulan = ukm.id_kumpulan');
	return $this->db->get_where($table,$where);
	}
	function cari_id($table,$where){
	$this->db->select('id_kumpulan');
	return $this->db->get_where($table,$where)->result();
	}
	function cari_tracking($table,$where){
	return $this->db->get_where($table,$where);
	}
}