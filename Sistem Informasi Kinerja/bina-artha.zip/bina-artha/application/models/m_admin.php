<?php

/**
 * 
 */
class M_admin extends CI_Model
{
	
	function cek_nama_user($table,$where)
	{
		$this->db->select('karyawan.nama');
		$this->db->join('karyawan','karyawan.nik=user.nik','inner');
		return $this->db->get_where($table,$where);
	}
	function tampil_data_kumpulan_proses()
	{
		$this->db->SELECT('kumpulan.id_kumpulan,kumpulan.nama_kumpulan');
		$this->db->distinct();
		$this->db->from('kumpulan');
		$this->db->join('ukm','ukm.id_kumpulan = kumpulan.id_kumpulan');
		$this->db->where('ukm.bsr_pinjaman = ""');
		$query  = $this->db->get();
		return $query;
	}
	function input_plafon($where,$table)
	{	$this->db->SELECT('
		karyawan.nik,karyawan.nama,kumpulan.id_kumpulan,kumpulan.nama_kumpulan,mitra.id_mitra,mitra.nama_lengkap,jenis_usaha.nama_usaha,ukm.putaran_pinjaman,ukm.bsr_pinjaman_dbr,ukm.bsr_pinjaman_ahp');
		$this->db->join('ukm','ukm.id_kumpulan = kumpulan.id_kumpulan');
		$this->db->join('karyawan','karyawan.nik = ukm.nik');
		$this->db->join('mitra','ukm.id_mitra = mitra.id_mitra');
		$this->db->join('jenis_usaha','jenis_usaha.id_mitra = ukm.id_mitra');
		$this->db->where('ukm.bsr_pinjaman = ""');
		$query = $this->db->get_where($table,$where); 
		return $query;
	}

	function input_pinjaman($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}
	function update_id_tracking($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}
	function jumlah_data($where,$table){
		$this->db->where('bsr_pinjaman=""');
		$query = $this->db->get_where($table,$where)->num_rows();
		return $query;
	}
	function banyak_data($where,$table){
		$this->db->SELECT('id_kumpulan');
		//$this->db->count('id_kumpulan');
		$this->db->where('bsr_pinjaman=""');
		$query = $this->db->get_where($table,$where);
		$total = $query->num_rows();
		return $total;
	}
	function banyak_data_bulan($where,$table){
		$this->db->SELECT('id_tracking');
		$query = $this->db->get_where($table,$where);
		$total = $query->num_rows();
		return $total;
	}
	function cek_tracking($where,$table){
		$this->db->SELECT('tracking.id_tracking,karyawan.id_regional,karyawan.id_area,karyawan.cabang,kumpulan.id_kumpulan,kumpulan.nama_kumpulan,karyawan.nik,karyawan.nama,tracking.tipe_pengajuan,tracking.tipe_pinjaman,tracking.tgl_kirim,tracking.tgl_ok,tracking.tgl_revisi,tracking.tgl_lkkm1,tracking.tgl_lkkm2,tracking.tgl_pengesahan, tracking.tgl_pencairan,tracking.jml_mitra,tracking.jml_pencairan');
		$this->db->join('tracking','tracking.nik_petugas = karyawan.nik');
		$this->db->join('kumpulan','kumpulan.id_kumpulan = tracking.id_kumpulan');
		return $this->db->get_where($table,$where);
	}
	function input_tracking($data,$table){
		$this->db->insert($table,$data);

	}
	function update_tracking($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}
	function hapus_pinjaman($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}
	function hapus_data($where,$table){
	$this->db->where($where);
	$this->db->delete($table);
	}
	function edit_tracking($where,$table){
		$this->db->SELECT('tracking.id_tracking,karyawan.id_regional,karyawan.id_area,karyawan.cabang,kumpulan.id_kumpulan,kumpulan.nama_kumpulan,karyawan.nik,karyawan.nama,tracking.tipe_pengajuan,tracking.tipe_pinjaman,tracking.tgl_kirim,tracking.tgl_ok,tracking.tgl_revisi,tracking.tgl_lkkm1,tracking.tgl_lkkm2,tracking.tgl_pengesahan, tracking.tgl_pencairan,tracking.jml_mitra,tracking.jml_pencairan');
		$this->db->join('karyawan','tracking.nik_petugas = karyawan.nik');
		$this->db->join('kumpulan','kumpulan.id_kumpulan = tracking.id_kumpulan');	
		return $this->db->get_where($table,$where); 
	}
	function list_id_tracking()
	{
		$this->db->SELECT('id_tracking');
		$this->db->distinct();
		$this->db->from('tracking');
		return $this->db->get();
	}
	function list_karyawan()
	{
		$this->db->SELECT('nik,nama');
		$this->db->from('karyawan');
		$this->db->where('jabatan = "AO"');
		$this->db->where('aktif = "Y"');
		return $this->db->get();
	}
	function jml_mtra_ukm($where,$table){
		$this->db->SELECT('SUM(jml_mitra) AS jml_mitra_ukm');
		$this->db->where('tgl_kirim != "0000-00-00"');
		return $this->db->get_where($table,$where);

	}	
	function jml_mtra_lkkm($where,$table){
		$this->db->SELECT('SUM(jml_mitra) AS jml_mitra_lkkm');
		$this->db->where('tgl_lkkm1 != "0000-00-00"');
		return $this->db->get_where($table,$where);
	}
	function jml_mtra_upkm($where,$table){
		$this->db->SELECT('SUM(jml_mitra) AS jml_mitra_upkm');
		$this->db->where('tgl_pengesahan != "0000-00-00"');
		return $this->db->get_where($table,$where);
	}	
	function jml_pencairan($where,$table){
		$this->db->SELECT('SUM(jml_pencairan) AS jml_pencairan');
		$this->db->where('tgl_pencairan != "0000-00-00"');
		return $this->db->get_where($table,$where);

	}
	function jml_mtra_ukm_tahun(){
		$tahun = date('Y');
		$this->db->SELECT('SUM(jml_mitra) AS jml_mitra_ukm');
		$this->db->where('tgl_kirim != "0000-00-00"');
		$this->db->where('id_tracking like "%'.$tahun.'"');
		$this->db->from('tracking');
		return $this->db->get();
	}	
	function jml_mtra_lkkm_tahun(){
		$tahun = date('Y');
		$this->db->SELECT('SUM(jml_mitra) AS jml_mitra_lkkm');
		$this->db->where('tgl_lkkm1 != "0000-00-00"');
		$this->db->where('id_tracking like "%'.$tahun.'"');
		$this->db->from('tracking');
		return $this->db->get();
	}
	function jml_mtra_upkm_tahun(){
		$tahun = date('Y');
		$this->db->SELECT('SUM(jml_mitra) AS jml_mitra_upkm');
		$this->db->where('tgl_pengesahan != "0000-00-00"');
		$this->db->where('id_tracking like "%'.$tahun.'"');
		$this->db->from('tracking');
		return $this->db->get();
	}	
	function jml_pencairan_tahun(){
		$tahun = date('Y');
		$this->db->SELECT('SUM(jml_pencairan) AS jml_pencairan');
		$this->db->where('tgl_pencairan != "0000-00-00"');
		$this->db->where('id_tracking like "%'.$tahun.'"');
		$this->db->from('tracking');
		return $this->db->get();
	}
	function pencapaian_tahun(){
		$tahun = date('Y');
		$this->db->SELECT('karyawan.nama,SUM(jml_pencairan) as jml_pencairan,SUM(jml_mitra) AS jml_mitra');
		$this->db->where('tracking.id_tracking like "%'.$tahun.'"');
		$this->db->where('tgl_pencairan != "0000-00-00"');
		$this->db->from('tracking');
		$this->db->join('karyawan','karyawan.nik=tracking.nik_petugas');
		$this->db->group_by('tracking.nik_petugas');
		return $this->db->get();
	}	
	function cabang_pencapaian_bulan(){
		$tahun = date('Y');
		$this->db->SELECT('month(tgl_pencairan)as bulan,SUM(jml_mitra) as jml_mitra, sum(jml_pencairan) AS jml_pencairan');
		$this->db->where('tracking.id_tracking like "%'.$tahun.'"');
		$this->db->where('tgl_pencairan != "0000-00-00"');
		$this->db->from('tracking');
		$this->db->group_by('Month(tgl_pencairan)');
		return $this->db->get();
	}
	function report($where,$pawal,$pakhir,$table){
		$this->db->SELECT('karyawan.nama,month(tracking.tgl_pencairan) as bulan,sum(tracking.jml_mitra) as jml_mitra,sum(tracking.jml_pencairan) as jml_pencairan ');
		$this->db->where('tracking.tgl_pencairan !="0000-00-00"');
		$this->db->where('tracking.id_tracking between "'.$pawal.'" and "'.$pakhir.'"');
		$this->db->join('karyawan','karyawan.nik = tracking.nik_petugas');
		$this->db->group_by('Month(tgl_pencairan)');
		return $this->db->get_where($table,$where);
	}
	function cek_nama_karyawan($where,$table){
		$this->db->SELECT('karyawan.nama');
		return $this->db->get_where($table,$where);	
	}		

}