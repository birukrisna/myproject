<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>TRACKING BINA ARTHA</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo base_url().'/assets/vendors/mdi/css/materialdesignicons.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'/assets/vendors/css/vendor.bundle.base.css'?>">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="<?php echo base_url().'/assets/vendors/flag-icon-css/css/flag-icon.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'/assets/vendors/jvectormap/jquery-jvectormap.css'?>">
  <!-- End plugin css for this page -->
  <!-- Layout styles -->
  <link rel="stylesheet" href="<?php echo base_url().'/assets/css/demo/style.css'?>">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="<?php echo base_url().'/assets/images/favicon.png'?>" />
<?php $nama_bulan = array('bulan','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember');
            ?>
</head>
<body>
<script src="<?php echo base_url().'/assets/js/preloader.js'?>"></script>
  <div class="body-wrapper">
    <!-- partial:partials/_sidebar.html -->
    <aside class="mdc-drawer mdc-drawer--dismissible mdc-drawer--open">
      <div class="mdc-drawer__header">
        <a href="<?php echo base_url().'c_admin/'?>" class="brand-logo">
          <img src="<?php echo base_url().'/assets/images/Logo_bav_putih.png'?>" height="100px" alt="logo">
        </a>
      </div>
       <div class="mdc-drawer__content">
        <div class="user-info">
          <p class="name"><?php echo $this->session->userdata("nama");?></p>
          <p class="email"><?php foreach ($nama_user as $n) {echo $n->nama;}?></p>
        </div>
        <div class="mdc-list-group">
          <nav class="mdc-list mdc-drawer-menu">
            <div class="mdc-list-item mdc-drawer-item">
              <a class="mdc-drawer-link" href="<?php echo base_url().'c_admin/index'?>">
                <i class="material-icons mdc-list-item__start-detail mdc-drawer-item-icon" aria-hidden="true">home</i>
                Dashboard
              </a>
            </div>
            <div class="mdc-list-item mdc-drawer-item">
              <a class="mdc-drawer-link" href="<?php echo base_url().'c_admin/tracking'?>">
                <i class="material-icons mdc-list-item__start-detail mdc-drawer-item-icon" aria-hidden="true">book</i>
                Tracking
              </a>
            </div>
            <div class="mdc-list-item mdc-drawer-item">
              <a class="mdc-drawer-link" href="<?php echo base_url().'c_admin/list_kumpulan_proses'?>">
                <i class="material-icons mdc-list-item__start-detail mdc-drawer-item-icon" aria-hidden="true">comment</i>
                Plafond
              </a>
            </div>
             <div class="mdc-list-item mdc-drawer-item">
              <a class="mdc-drawer-link" href="<?php echo base_url().'c_admin/report'?>">
                <i class="material-icons mdc-list-item__start-detail mdc-drawer-item-icon" aria-hidden="true">assignment</i>
                Report
              </a>
            </div>
          </nav>
        </div>
        <div class="profile-actions">
          <a href="<?php echo base_url().'c_admin/logout'?>">Logout</a>
        </div>
      </div>
    </aside>
    <!-- partial -->
    <div class="main-wrapper mdc-drawer-app-content">
      <!-- partial:partials/_navbar.html -->
      <header class="mdc-top-app-bar">
        <div class="mdc-top-app-bar__row">
          <div class="mdc-top-app-bar__section mdc-top-app-bar__section--align-start">
            <button class="material-icons mdc-top-app-bar__navigation-icon mdc-icon-button sidebar-toggler">menu</button>
           <span class="mdc-top-app-bar__title">Greetings <?php foreach ($nama_user as $n) {echo $n->nama;}?> !!</span>
          </div>
        </div>
      </header>
      <!-- partial -->
      <div class="page-wrapper mdc-toolbar-fixed-adjust">
        <main class="content-wrapper">
          <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
            <div class="mdc-card p-0">
              <div class="mdc-card p-0">
                  <h5 class="card-title card-padding pb-0 ">0213_CIWIDEY</h5><font style="text-align:right;"><?php echo date('d F Y')?></font>
                    <form action="" method="post">
                    <?php 
                    function ubahID($tanggal){
                     $pisah = explode(' ',$tanggal);
                     $bulan = array($pisah[1]);
                     $tahun = array($pisah[2]);
                     $pbulan = implode($bulan);
                     $ptahun = implode($tahun);
                     $satukan = $pbulan." ".$ptahun;
                     return $satukan;
                    }
                    function percobaan($test){
                     $a = $test[0].$test[1];
                     $b = $test[2].$test[3].$test[4].$test[5];
                     $pid = $b.'/'.$a;
                     return $pid;
                    }
                    ?><?php
                    function percobaan2($test2){
                     $a2 = $test2[0].$test2[1];
                     $b2 = $test2[2].$test2[3].$test2[4].$test2[5];
                     $pid2 = $b2.'-'.$a2;
                     return $pid2;
                    }
                    function tgl_indo($tanggal){
                      $bulan = array (
                       1 =>   'Januari',
                              'Februari',
                              'Maret',
                              'April',
                              'Mei',
                              'Juni',
                              'Juli',
                              'Agustus',
                              'September',
                              'Oktober',
                              'November',
                              'Desember'
                     );
                      $pecahkan = explode('-', $tanggal);   
                       // variabel pecahkan 0 = tanggal
                       // variabel pecahkan 1 = bulan
                       // variabel pecahkan 2 = tahun      
                      return $pecahkan[2] . ' ' . $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
                      }?>
                    <?php
                      if (isset($_POST['Search'])) {
                      $bnama = $_POST['Nama_Karyawan'];
                      $bjenis = $_POST['Jenis_Report'];
                      $bawal = $_POST['Priode_Awal'];
                      $bakhir = $_POST['Priode_Akhir'];
                      if($bjenis == "jml_mitra"){
                        $jenis="Jumlah Mitra Cair";
                      }else{
                        $jenis="Jumlah Pencairan";
                      }
                      foreach ($nama as $nm){
                      ?> <h5><font style="margin-left:25px;" >Report <?php echo $jenis." Staff ".$nm->nama?> priode 
                      <?php echo ubahID(tgl_indo(percobaan2($bawal)."-15"));?> Sampai <?php echo ubahID(tgl_indo(percobaan2($bakhir)."-15"));}
                      }
                      ?> </font></h5>   
                    <table style="width:1px">
                      <tr>
                        <td>Nama Karyawan</td>
                        <td>Jenis Report</td>
                        <td>Priode Awal</td>
                        <td>Priode Akhir</td>
                      </tr>
                      <tr>
                        <td>
                          <select name="Nama_Karyawan">
                            <option>-- Pilih Karyawan --</option>
                            <?php foreach ($list_karyawan as $lk){?>
                            <option value="<?php echo $lk->nik?>"><?php echo $lk->nama?></option>
                            <?php } ?>
                          </select>
                        </td>
                        <td>
                          <select name="Jenis_Report">
                            <option>-- Jenis_Report --</option>
                            <option value="jml_mitra">Jumlah Mitra</option>
                            <option value="jml_pencairan">Jumlah Pencairan</option>      
                          </select>
                        </td>
                        <td>
                          <select name="Priode_Awal">
                          <option>-- Pilih Bulan --</option>
                           
                            <?php
                            foreach($list as $l){
                              $id= $l->id_tracking;
                              $date=date_create(percobaan($id)."/15");
                            ?>
                            <option value="<?php echo $l->id_tracking ?>"><?php echo ubahID(tgl_indo(percobaan2($id)."-15")); ?></option>
                            <?php } ?>  
                        </select>
                        </td>
                        <td>
                          <select name="Priode_Akhir">
                          <option>-- Pilih Bulan --</option>
                            <?php
                            foreach($list as $l){
                              $id= $l->id_tracking;
                              $date=date_create(percobaan($id)."/15");
                            ?>
                            <option value="<?php echo $l->id_tracking ?>"><?php echo ubahID(tgl_indo(percobaan2($id)."-15")); ?></option>
                            <?php } ?>  
                        </select>
                        </td>
                      </tr>
                    </table>
                    <input type="submit" name="Search" value="Search">
                    </form>
                    <br>
                    <!-- Chart -->
                    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
                    <script type="text/javascript">
                      google.charts.load("current", {packages:['corechart']});
                      google.charts.setOnLoadCallback(drawChart);
                      function drawChart() {
                        var data = google.visualization.arrayToDataTable([
                          <?php if($bjenis=='jml_mitra'){ ?>
                            ["Bulan", "Jumlah Mitra ", { role: "style" } ],
                            <?php foreach ($report as $r) { ?>
                            ["<?php echo $nama_bulan[$r->bulan]?>",<?php echo $r->jml_mitra?>,"blue"],
                            <?php }
                            }else { ?>
                            ["Bulan", "Pencairan Rp. ", { role: "style" } ],
                            <?php foreach ($report as $r) { ?>
                            ["<?php echo $nama_bulan[$r->bulan]?>",<?php echo $r->jml_pencairan ?>,"blue"],
                            <?php } 
                            }?>
                        ]);

                        var view = new google.visualization.DataView(data);
                        view.setColumns([0, 1,
                                         { calc: "stringify",
                                           sourceColumn: 1,
                                           type: "string",
                                           role: "annotation" },
                                         2]);

                        var options = {
                          title: "",
                          width: 900,
                          height: 290,
                          bar: {groupWidth: "95%"},
                          legend: { position: "none" },
                        };
                        var chart = new google.visualization.ColumnChart(document.getElementById("columnchart_values"));
                        chart.draw(view, options);
                    }
                    </script>
                    <div class="table-responsive"><div id="columnchart_values" style="width: 900px; height: 300px;"></div></div>
                    
            </div>
          </div>
        </main>
        <!-- partial:partials/_footer.html -->
        <footer>
          <div class="mdc-layout-grid">
            <div class="mdc-layout-grid__inner">
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-6-desktop">
                <span class="text-center text-sm-left d-block d-sm-inline-block tx-14">Copyright © <a href="https://www.bootstrapdash.com/" target="_blank">bootstrapdash.com </a>2020</span>
              </div>
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-6-desktop d-flex justify-content-end">
                <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center tx-14">PT Bina Artha Ventura</span>
              </div>
            </div>
          </div>
        </footer>
        <!-- partial -->
      </div>
    </div>
  </div>
  <!-- plugins:js -->
  <script src="<?php echo base_url().'/assets/vendors/js/vendor.bundle.base.js'?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="<?php echo base_url().'/assets/vendors/chartjs/Chart.min.js'?>"></script>
  <script src="<?php echo base_url().'/assets/vendors/jvectormap/jquery-jvectormap.min.js'?>"></script>
  <script src="<?php echo base_url().'/assets/vendors/jvectormap/jquery-jvectormap-world-mill-en.js'?>"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?php echo base_url().'/assets/js/material.js'?>"></script>
  <script src="<?php echo base_url().'/assets/js/misc.js'?>"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo base_url().'/assets/js/dashboard.js'?>"></script>
  <!-- End custom js for this page-->
</body>
</html> 