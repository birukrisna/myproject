<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=windows-1252">
    <style>
      .border th{
        border: 1px solid black;
      }
      .border td{
         border: 1px solid black;
        
      }
      th, td {
        padding: 5px;
      }
      th {
        text-align: center;
      }
      
      .test th{
        border: 1px solid black;
        border-collapse: collapse;
      }
</style>
<meta http-equiv="refresh" content="10">
  </head>
  <body> <br>
    <font align="center" face="Calibri-Bold">
      <h2>FORMULIR UJI KELAYAKAN MITRA (UKM)</h2>
    </font><br>
    <table style="width:100%;border-collapse: collapse;">
      <tr>
        <td colspan="6">
          <p>
            Tujuan Aplikasi 
              <input type="checkbox" name="mk"/> Produk Bav Modal Kerja <input type="checkbox" name="ml"> Produk Bav Lainya
          </p>
        </td>
        <td>Pembiaayaan ke </td>
        <td>01</td>
      </tr>
      <tr>
        <td style="width:10%">Tanggal UKM </p>
        </td>
        <td style="width:7%">02-02-2020</td>
        <td style="width:10%"><p style="text-align: right;">ID Regional</p> </td>
        <td style="width:8%">005</td>
        <td style="width:8%"><p style="text-align: right;">ID Cabang </p></td>
        <td>0213</td>
        <td>Nama Cabang </td>
        <td>Ciwidey</td>
      </tr>
      <tr>
        <td>ID Petugas </td>
        <td>4612</td>
        <td > Nama Petugas</td>
        <td colspan="3">Krisna</td>
        <td>ID Mitra</td>
        <td>New</td>
      </tr>
    </table>
    <p><b>1. INFORMASI MITRA</b></p>
    <table style="width:100%;border-collapse: collapse;">
      <tr>
        <td style="width:13%">Nama Mitra</td>
        <td colspan="4" style="width:42.5%" >Nama Mitra</td>
        <td style="width:13%">Nama Penangung Jawab</td>
        <td colspan="3">Nama Penanggung Jawab</td>
      </tr>
      <tr>
        <td>Nama Panggil</td>
        <td colspan="4">Nama Panggil</td>
        <td>nama Tertangung</td>
        <td colspan="3">Nama Tertangung</td>
      </tr>
      <tr>
        <td>Nama Ibu Kandung</td>
        <td colspan="4"> Nama Ibu</td>
        <td>Status Tertanggung</td>
        <td style="width:10%"><input type="checkbox" name="stsSuami"/ >Suami</td>
        <td colspan="2"><input type="checkbox" name="stsAnakKandung">Anak Kandung</td>
      </tr>
      <tr>
        <td>Alamat / Tempat Tinggal</td>
        <td colspan="4">Alamat</td>
        <td></td>
        <td colspan="3"><input type="checkbox" name="stsSaudaraKandung">Saudara Kandung</td>
      </tr>
      <tr>
        <td>Nama Desa</td>
        <td colspan="4">Desa</td>
        <td>Jumlah  Tanggungan </td>
        <td>04</td>
        <td style="width:8%">Jumlah Anak</td>
        <td>01</td>
      </`tr>
      <tr>
        <td>Kecamatan</td>
        <td colspan="4">Kecamatan</td>
        <td>Status Rumah Tinggal</td>
        <td><input type="checkbox" name="RumahSendiri">Milik Sendiri</td>
        <td colspan="2"><input type="checkbox" name="Kontrak">Sewa</td>
      </tr>
      <tr>
        <td>RT</td>
        <td style="width:5%;">001</td>
        <td></td>
        <td style="width:5%;">RW</td>
        <td>012</td>
        <td>Lama Tinggal</td>
        <td colspan="3"><p>20 &ensp;&ensp;Tahun (Lama Tinggal di Alamat Sekarang)</p></td>
      </tr>
      <tr>
        <td>KodePos</td>
        <td colspan="4">KodePos</td>
        <td>Nomer Telepon</td>
        <td colspan="3">Nomer Telepon</td>
      </tr>
    </table>
    <p><strong>2. JENIS USAHA MITRA</strong></p>
    <p style="margin-left:5px">Keterangan Usaha Mitra (Uraikan Nama dan Jenis Usaha dengan Jelas
    <table style="border-collapse: collapse;">
      <tr>
        <td>a. Apabila Jenis Usaha Mitra termasuk dalam daftar usaha yang dihindari dalam kebijakan Bina Artha ?</td>
        <td><input type="checkbox" name="dihindariya"/>Ya<input type="checkbox" name="dihindaritidak"/>Tidak</td>
      </tr>
      <tr>
        <td>b. Apakah Jenis Usaha Mitra mempekerjakan pekerja anak yang dilarang dalam kebijakan Bina Artha ?</td>
        <td> <input type="checkbox" name="pekerjaya"/>Ya<input type="checkbox" name="pekerjatidak"/>Tidak</td>
      </tr>
    </table>
    </p>
    <p><strong>2. RINCIAN USAHA MITRA</strong></p>
    <p style="margin-left:5px">A. Lokasi Usaha : .........................  Lama Usaha (Tahun) : ......... Waktu usaha :.... d/s ......</p>
    <p style="margin-left:5px;margin-bottom:0px">B. Putaran Usaha :</p>
    <table style="width:99%;margin-left:10px;">
      <tr>
        <td>B.1 Ibu membuka / menjalankan usaha*) :</td>
        <td>a. <input type="checkbox" name="usahaH">Tiap Hari (x28)</td>
        <td>b. <input type="checkbox" name="usahaM">Tiap Minggu (x4)</td>
        <td>c. <input type="checkbox" name="usaha2M">Tiap Dua Minggu (x2)</td>
        <td>d. <input type="checkbox" name="usahaB">Tiap Bulan (x1)</td>
      </tr>
      <tr>
        <td>*Centang dan tulis sesuai kondisi di lapangan</td>
        <td colspan="4">e. <input type="checkbox" name="usahaL">Lainnya................................................................(tuliskan)</td>
      </tr>
    </table>
    <p style="margin-left:5px;margin-bottom: 0px;margin-top: 0px;"> C. informasi Fluktuasi Putaran Usaha (Catatan : Petanyaan dibawah disesuaikan dengan putaran usaha yang dipilih pada nomor B.1)</p>
    <p style="margin-left:20px;margin-bottom: 0px;margin-top: 0px">C.1. Pendapatan (3 putaran terakhir</p>
    <table class="border" style="width:99%;margin-left: 10px;border-collapse: collapse;">
      <tr>
        <th style="width:40%">Kondisi</th>
        <th>Berapa uang yang diperoleh (Rp)</th>
        <th rowspan="2">Pendapatan Usaha (Rata - rata x B.1)</th>
      </tr>
      <tr>
        <td>i. Ramai</td>
        <td></td>
      </tr>
      <tr>
        <td>ii. Sepi - sedang</td>
        <td></td>
        <td rowspan="4"></td>
      </tr>
      <tr>
        <td>Total</td>
        <td></td>
      </tr>
      <tr>
        <td>Rata - rata </td>
        <td></td>
      </tr>
      <tr>
        <td>iii. Sekarang (Hari ______________/tgl__________/jam____)</td>
        <td></td>
      </tr>
    </table>
    <p style="margin-left:20px;margin-bottom: 0px;">C.2. Pengeluaran Usaha</p>
    <table class ="border" style="width:99%;margin-left:10px;border-collapse:collapse;">
      <tr>
        <th style="width:24%">Rincian</th>
        <th style="width:26%">Jumlah Pengeluaran (per bulan)</th>
        <th style="width:50%">Keterangan</th>
      </tr>
      <tr>
        <td>a. Bahan baku dan bahan pendukung</td>
        <td>Rp.</td>
        <td></td>
      </tr>
      <tr>
        <td>b. Listrik, telepon, air, keamanan, restribusi dll</td>
        <td>Rp.</td>
        <td></td>
      </tr>
      <tr>
        <td>c. Biaya tenaga kerja</td>
        <td>Rp.</td>
        <td></td>
      </tr>
      <tr>
        <td>d. Transportasi</td>
        <td>Rp.</td>
        <td></td>
      </tr>
      <tr>
        <td>e. Angsuran pinjaman/kredit usaha</td>
        <td>Rp.</td>
        <td></td>
      </tr>
      <tr>
        <td colspan="3"></td>
      </tr>
      <tr>
        <td colspan="2"><strong>C.3. Perolehan bersih usaha = (pendapatan - pengeluaran)</strong></td>
        <td><strong>Rp.</strong></td>
      </tr>
    </table>
   <p><strong>4. RINCIAN KONDISI EKONOMI KELUARGA MITRA</strong></p>
   <p style="margin-left:10px;margin-bottom:0px">A. Pendapatan Keluarga (usaha mitra tidak dimasukan dengan menuliskan sesuai dengan pendapatan bersih usaha)</p>
   <table class="border" style="width:99%;margin-left:10px;border-collapse:collapse;">
    <tr>
     <th style="width:2%">No</th>
     <th style="width:35%">Nama Lengkap</th>
     <th style="width:15%">Hubungan Dengan Mitra</th>
     <th style="width:25%">Pekerjaan/usaha</th>
     <th >Pendapatan Anggota Keluarga</th>
    </tr>
    <tr>
      <td>1</td>
      <td></td>
      <td></td>
      <td></td>
      <td>Rp. </td>
    </tr>
    <tr>
      <td>2</td>
      <td></td>
      <td></td>
      <td></td>
      <td>Rp. </td>
    </tr>
    <tr>
      <td>3</td>
      <td></td>
      <td></td>
      <td></td>
      <td>Rp. </td>
    </tr>
    <tr>
      <td>4</td>
      <td></td>
      <td></td>
      <td></td>
      <td>Rp. </td>
    </tr>
    <tr>
      <td colspan="4"><p align="center">TOTAL PENDAPATAN KELUARGA (per bulan)</p></td>
      <td>Rp.</td>
    </tr>
   </table>
   <br>
   <table style="margin-left:10px;border-collapse:collapse;">
    <tr>
      <td style="width:8%"><font size="2">Keterangan *)</font></td>
      <td><font size="2">a. Pendapatan usaha mitra yang dimasukkan adalah pendapatan bersih usaha.</font></td>
    </tr>
    <tr>
      <td></td>
      <td><font size="2">b. Pendapatan suami atau anggota keluarga lain : pendapatan yang diberikan/dikelola oleh mitra untuk keluarga (uang belanja yang diberikan (usaha mitra tidak dimasukan dengan menuliskan sesuai dengan pendapatan bersih usaha)</font></td>
    </tr>
   </table>
   <p style="margin-left:10px;margin-bottom:0px">B. Pengeluaran Keluarga</p>
   <table class="border" style="width:99%;margin-left: 10px;border-collapse: collapse;">
     <tr>
      <th style="width:2%">No</th>
      <th style="width:33%">Jenis Pengeluaran</th>
      <th>Bulan</th>
      <th style="width:2%">No</th>
      <th style="width:33%">Jenis Pengeluaran</th>
      <th>Bulan</th>
     </tr>
     <tr>
       <td><p align="center">a.</p></td>
       <td>Belanja Makan Keluarga</td>
       <td>Rp.</td>
       <td><p align="center">e.</p></td>
       <td>Angsuran pinjaman / kredit lainnya</td>
       <td>Rp.</td>
     </tr>
     <tr>
       <td><p align="center">b.</p></td>
       <td>Listrik, air, telepon, dll</td>
       <td>Rp.</td>
       <td><p align="center">f.</p></td>
       <td>Pengeluaran lain-lain</td>
       <td>Rp.</td>
     </tr>
      <tr>
       <td><p align="center">c.</p></td>
       <td>Biaya anak (pendidikan, transportasi, uang jajan)</td>
       <td>Rp.</td>
       <td><p align="center"></p></td>
       <td></td>
       <td></td>
     </tr>
      <tr>
       <td><p align="center">d.</p></td>
       <td>Kesehatan</td>
       <td>Rp.</td>
       <td><p align="center"></p></td>
       <td>Total Pengeluaran Keluarga</td>
       <td>Rp. </td>
     </tr>
     <tr>
       <td colspan="6"></td>
     </tr>
      <tr>
       <td colspan="2"><strong>C. Perolehan Bersih Keluarga (pendapatan -pengeluaran)</strong></td>
       <td></td>
       <td><strong>Rp.</strong></td>
       <td colspan="2"></td>
     </tr>
   </table>
   <p><strong>5. Cek Lingkungan</strong></p>
   <table class="border" style="width:99%;margin-left:10px;border-collapse:collapse">
     <tr>
       <th style="width:10">No</th>
       <th>Nama Narasumber</th>
       <th>Hasil Cek Lingkungan</th>
     </tr>
     <tr>
       <td><p align="center">1</p></td>
       <td></td>
       <td></td>
     </tr>
     <tr>
       <td><p align="center">2</p></td>
       <td></td>
       <td></td>
     </tr>
     <tr>
       <td><p align="center">3</p></td>
       <td></td>
       <td></td>
     </tr>
   </table>
   <p><strong>6. PENGALAMAN MITRA DENGAN KREDIT/PINJAMAN</strong></p>
   <table class="test" style="width:99%;margin-left: 10px; border-collapse: collapse;">
     <tr>
       <td style="width:25.05%">Frekuensi Pembiayaan</tdD>
       <th style="width:5%">H</th>
       <td style="width:6.4%">Harian</td>
       <th style="width:5.9%">M</th>
       <td style="width:12%">Mingguan</td>
       <th style="width:3%">2M</th>
       <td style="width:15%">dua Minggu Sekali</td>
       <th style="width:3%">B</th>
       <td>Bulanan</td>
     </tr>
   </table>
   <table class="border" style="width:99%;margin-left:10px;border-collapse: collapse;">
     <tr>
       <th rowspan="2" style="width:30%">Lembaga Pemberi Kredit</th>
       <th rowspan="2">Jangka Waktu</th>
       <th rowspan="2">Tahun Kredit</th>
       <th rowspan="2"style="width:15%">Jumlah Kredit</th>
       <th rowspan="2"style="width:15%">Angsuran</th>
       <th rowspan="2"style="width:15%">Sisa Kredit</th>
       <th colspan="4">Frekuensi Angsuran *)</th>
     </tr>
     <tr>
       <th style="width:20">H</th>
       <th style="width:20">M</th>
       <th style="width:20">2M</th>
       <th style="width:20">B</th>
     </tr>
      <tr>
       <td>Lembaga Pemberi Kredit</td>
       <td></td>
       <td></td>
       <td>Rp. </td>
       <td>Rp. </td>
       <td>Rp. </td>
       <th style="width:20"><input type="checkbox" name="fH"></th>
       <th style="width:20"><input type="checkbox" name="fM"></th>
       <th style="width:20"><input type="checkbox" name="f2M"></th>
       <th style="width:20"><input type="checkbox" name="fD"></th>
     </tr>
     <tr>
       <td>Lembaga Pemberi Kredit</td>
       <td></td>
       <td></td>
       <td>Rp. </td>
       <td>Rp. </td>
       <td>Rp. </td>
       <th style="width:20"><input type="checkbox" name="fH"></th>
       <th style="width:20"><input type="checkbox" name="fM"></th>
       <th style="width:20"><input type="checkbox" name="f2M"></th>
       <th style="width:20"><input type="checkbox" name="fD"></th>
     </tr>
     <tr>
       <td>Lembaga Pemberi Kredit</td>
       <td></td>
       <td></td>
       <td>Rp. </td>
       <td>Rp. </td>
       <td>Rp. </td>
       <th style="width:20"><input type="checkbox" name="fH"></th>
       <th style="width:20"><input type="checkbox" name="fM"></th>
       <th style="width:20"><input type="checkbox" name="f2M"></th>
       <th style="width:20"><input type="checkbox" name="fD"></th>
     </tr>
     <tr>
       <td>Lembaga Pemberi Kredit</td>
       <td></td>
       <td></td>
       <td>Rp. </td>
       <td>Rp. </td>
       <td>Rp. </td>
       <th style="width:20"><input type="checkbox" name="fH"></th>
       <th style="width:20"><input type="checkbox" name="fM"></th>
       <th style="width:20"><input type="checkbox" name="f2M"></th>
       <th style="width:20"><input type="checkbox" name="fD"></th>
     </tr>
     <tr>
      <td colspan="10"><p align="center">*) beritanda centang (√) jawaban yang dipilih</p></td>
    </tr>
   </table>
   <br> 
  <p><strong>7. PERNYATAAN MITRA dan BIAYA ADMINISTRASI</strong></p>
  <table class="border" style="width:99%;margin-left:10px;margin-bottom:15px">
    <td> 
      <font style="margin-left: 10px;">Saya yang bertandatangan di bawah ini, Nama ____________ Dengan ini menyatakan bahwa pada</font><br>
      <font style="margin-left: 10px;">Pengajuan pembiayaan kepada PT. Bina Artha Ventura tidak menyertakan pasangan (suami)/ pasangan penganti </font><br>
      <font style="margin-left: 10px;">Pernyataan ini saya buat dengan sadar, sungguh-sungguh dan tanpa paksaan dari siapapun.</font><br>
      <p style="margin-left: 20px;">Catatan:</p>
      <font style="margin-left:20px;"><strong>1. Manfaat Biaya Administrasi</strong></font><br>
      <font style="margin-left:30px;">a. mitra atau pasangan (suami)/ pasangan penganti meninggal dunia maka PT. Bina Artha Ventura akan mencatat secara otomatis bahwa pembiayaan fasilitas modal kerjanya telah <strong>LUNAS</strong></font><br>
      <font style="margin-left:30px">b. Manfaat yang diperoleh selama jangka waktu pembiayaan, jika pada saat jatuh tempo pembiayaan belum lunas , maka manfaat <strong>TIDAK BISA</strong> diperoleh/ diperpanjang</font><br><br>
      <font style="margin-left:20px;"><strong>2. Usia Manfaat</strong></font><br>
      <font style="margin-left:30px;">a. putaran pertama : ber-KTP dan maksimal usia 57 tahun saat pencairan</font>
      <font style="margin-left:30%;"><strong>Tanda Tangan Mitra</strong></font><br>
      <font style="margin-left:30px;">b. Putaran selanjutnya : ber-KTP dan Maksimal usia 63 tahun saat pencairan </font><br><br><br>
      <font style="margin-left:66%;">(________________________)</font>
    </td>
  </table>
  <table class="border" align="left" style="width:32%;margin-left:10px;border-collapse:collapse">
    <tr>
      <td style="height:40px">Besar pembiayaan yang diajukan Mitra :</td>
    </tr>
    <tr>
      <td style="height: 60px;"><strong>Rp.</strong></td>
    </tr>
  </table>
  <table  class="border" align="left" style="width:32%;margin-left:10px;border-collapse:collapse" >
    <tr>
      <td style="height:30px"><p align="center">Tanda tangan Mitra</p></td>
    </tr>
    <tr>
      <td style="height:70px; padding-top: 50px;padding-bottom: 0px;"><font">Nama:</font></td>
    </tr>
  </table>
  <table  class="border" align="left" style="width:32%;margin-left:10px;border-collapse:collapse;margin-bottom: 15px;" >
    <tr>
      <td style="height:30px"><p align="center">Tanda tangan Mitra</p></font></td>
    </tr>
    <tr>
      <td style="height:70px;padding-top: 50px;padding-bottom: 0px;" ><font>Nama:</font></td>
    </tr>
  </table>
  <table class="border" style="width:99%;margin-left:10px;border-collapse:collapse;">
    <tr>
      <td><strong>Pernyataan BM </strong></td>
      <td colspan="8">Bahwa saya sudah mencek dan menverifikasi informasi yang tertulis pada form ini dengan dokumen yang sah serta tanya jawab dengan petugas. Form ini saya nyatakan benar serta sah dan saya bertanggungjawab atas isi dan dokumen terlampir.</td>
    </tr>
    <tr>
      <td rowspan="2"><strong>Dokumen (tanda Centang √) </strong></td>
      <td colspan="2"><p align="center">Mitra</p></td>
      <td colspan="2"><p align="center">Tertangung</p></td>
      <td colspan="2"><p align="center">Penanggung Jawab</p></td>
      <td rowspan="2"><font style="text-align:center;"><input type="checkbox" name="fotomitra">Foto Mitra</font></td>
      <td rowspan="2"><font style="text-align:center;"><input type="checkbox" name="kolomterisi">Kolom Semua Terisi</font></td>
    </tr>
    <tr>
      <td><input type="checkbox">KTP</td>
      <td><input type="checkbox">KK</td>
      <td><input type="checkbox">KTP</td>
      <td><input type="checkbox">KK</td>
      <td><input type="checkbox">KTP</td>
      <td><input type="checkbox">KK</td>
    </tr>
    <tr>
      <td colspan="5" style="height: 80px;padding-bottom: 55px;"><strong>Nama BM:</strong></td>
      <td colspan="4" style="height: 80px;padding-bottom: 55px;"><strong>Tanda Tangan BM:</strong></td>
    </tr>
  </table>
  </body>
</html>