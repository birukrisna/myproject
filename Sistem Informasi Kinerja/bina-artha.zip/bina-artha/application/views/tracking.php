<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>TRACKING BINA ARTHA</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo base_url().'/assets/vendors/mdi/css/materialdesignicons.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'/assets/vendors/css/vendor.bundle.base.css'?>">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="<?php echo base_url().'/assets/vendors/flag-icon-css/css/flag-icon.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'/assets/vendors/jvectormap/jquery-jvectormap.css'?>">
  <!-- End plugin css for this page -->
  <!-- Layout styles -->
  <link rel="stylesheet" href="<?php echo base_url().'/assets/css/demo/style.css'?>">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="<?php echo base_url().'/assets/images/favicon.png'?>" />
</head>
<body>
<script src="<?php echo base_url().'/assets/js/preloader.js'?>"></script>
  <div class="body-wrapper">
    <!-- partial:partials/_sidebar.html -->
    <aside class="mdc-drawer mdc-drawer--dismissible mdc-drawer--open">
      <div class="mdc-drawer__header">
        <a href="<?php echo base_url().'c_admin/'?>" class="brand-logo">
          <img src="<?php echo base_url().'/assets/images/Logo_bav_putih.png'?>" height="100px" alt="logo">
        </a>
      </div>
       <div class="mdc-drawer__content">
        <div class="user-info">
          <p class="name"><?php echo $this->session->userdata("nama");?></p>
          <p class="email"><?php foreach ($nama_user as $n) {echo $n->nama;}?></p>
        </div>
        <div class="mdc-list-group">
          <nav class="mdc-list mdc-drawer-menu">
            <div class="mdc-list-item mdc-drawer-item">
              <a class="mdc-drawer-link" href="<?php echo base_url().'c_admin/index'?>">
                <i class="material-icons mdc-list-item__start-detail mdc-drawer-item-icon" aria-hidden="true">home</i>
                Dashboard
              </a>
            </div>
            <div class="mdc-list-item mdc-drawer-item">
              <a class="mdc-drawer-link" href="<?php echo base_url().'c_admin/tracking'?>">
                <i class="material-icons mdc-list-item__start-detail mdc-drawer-item-icon" aria-hidden="true">book</i>
                Tracking
              </a>
            </div>
            <div class="mdc-list-item mdc-drawer-item">
              <a class="mdc-drawer-link" href="<?php echo base_url().'c_admin/list_kumpulan_proses'?>">
                <i class="material-icons mdc-list-item__start-detail mdc-drawer-item-icon" aria-hidden="true">comment</i>
                Plafond
              </a>
            </div>
             <div class="mdc-list-item mdc-drawer-item">
              <a class="mdc-drawer-link" href="<?php echo base_url().'c_admin/report'?>">
                <i class="material-icons mdc-list-item__start-detail mdc-drawer-item-icon" aria-hidden="true">assignment</i>
                Report
              </a>
            </div>
          </nav>
        </div>
        <div class="profile-actions">
          <a href="<?php echo base_url().'c_admin/logout'?>">Logout</a>
        </div>
      </div>
    </aside>
    <!-- partial -->
    <div class="main-wrapper mdc-drawer-app-content">
      <!-- partial:partials/_navbar.html -->
      <header class="mdc-top-app-bar">
        <div class="mdc-top-app-bar__row">
          <div class="mdc-top-app-bar__section mdc-top-app-bar__section--align-start">
            <button class="material-icons mdc-top-app-bar__navigation-icon mdc-icon-button sidebar-toggler">menu</button>
            <span class="mdc-top-app-bar__title">Greetings <?php foreach ($nama_user as $n) {echo $n->nama;}?> !!</span>
          </div>
        </div>
      </header>
      <!-- partial -->
      <div class="page-wrapper mdc-toolbar-fixed-adjust">
        <main class="content-wrapper">
          <div class="mdc-layout-grid">
            <div class="mdc-layout-grid__inner">
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-3-desktop mdc-layout-grid__cell--span-4-tablet">
                <div class="mdc-card info-card info-card--success">
                  <div class="card-inner">
                    <h5 class="card-title">UKM</h5>
                    <h5 class="font-weight-light pb-2 mb-1 border-bottom"><?php 
                    foreach ($ukm as $u){echo number_format($u->jml_mitra_ukm)?> Mitra</h5>
                    <p class="tx-12 text-muted"><?php $target = 60;$realisasiukm = $u->jml_mitra_ukm;
                    $persentaseukm = $realisasiukm/$target *100; echo round($persentaseukm,2);?>% target of <?php echo $target;?></p>
                    <div class="card-icon-wrapper">
                      <i class="material-icons">person_add</i>
                      <?php ;} ?>
                    </div>
                  </div>
                </div>
              </div>
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-3-desktop mdc-layout-grid__cell--span-4-tablet">
                <div class="mdc-card info-card info-card--danger">
                  <div class="card-inner">
                    <h5 class="card-title">LKKM</h5>
                    <h5 class="font-weight-light pb-2 mb-1 border-bottom"><?php 
                    foreach ($lkkm as $l){echo number_format($l->jml_mitra_lkkm)?> Mitra</h5>
                    <p class="tx-12 text-muted"><?php $target = 60;$realisasilkkm = $l->jml_mitra_lkkm;
                    $persentaselkkm = $realisasilkkm/$target *100; echo round($persentaselkkm,2);?>% target  of <?php echo $target;?></p>
                     <?php ;} ?>
                    <div class="card-icon-wrapper">
                      <i class="material-icons">event_note</i>
                      
                    </div>
                  </div>
                </div>
              </div>
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-3-desktop mdc-layout-grid__cell--span-4-tablet">
                <div class="mdc-card info-card info-card--primary">
                  <div class="card-inner">
                    <h5 class="card-title">UPKM</h5>
                    <h5 class="font-weight-light pb-2 mb-1 border-bottom"><?php 
                    foreach ($upkm as $up){echo number_format($up->jml_mitra_upkm)?> Mitra</h5>
                    <p class="tx-12 text-muted"><?php $target = 60;$realisasiupkm = $up->jml_mitra_upkm;
                    $persentaseupkm = $realisasiupkm/$target *100; echo round($persentaseupkm,2);?>% target of <?php echo $target;?></p>
                    <?php ;} ?>
                    <div class="card-icon-wrapper">
                      <i class="material-icons">assignment_turned_in</i>
                    </div>
                  </div>
                </div>
              </div>
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-3-desktop mdc-layout-grid__cell--span-4-tablet">
                <div class="mdc-card info-card info-card--info">
                  <div class="card-inner">
                    <h5 class="card-title">Pencairan</h5>
                    <h5 class="font-weight-light pb-2 mb-1 border-bottom">Rp <?php 
                    foreach ($pencairan as $pe){echo number_format($pe->jml_pencairan)?></h5>
                    <p class="tx-12 text-muted"><?php $target = 200000000;$realisasipencairan = $pe->jml_pencairan;
                    $persentasepencairan = $realisasipencairan/$target *100; echo round($persentasepencairan,2);?>% target  of<br> Rp <?php echo number_format($target);?></p>
                    <?php ;} ?>
                    <div class="card-icon-wrapper">
                      <i class="material-icons">attach_money</i>
                    </div>
                  </div>
                </div>
              </div>
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
                <div class="mdc-card p-0">
                  <h5 class="card-title card-padding pb-0 ">0213_CIWIDEY</h5><font style="text-align:right;"><?php echo date('d F Y')?></font>
                    <form action="<?php echo base_url().'c_admin/bulan_tracking'; ?>" method="post">
                    <?php
                      if (isset($_POST['Pilih_id'])) {
                      $bpilih = $_POST['id_Tracking'];
                      ?> <h5><font style="margin-left:25px;" ><?php echo ubahID(tgl_indo(percobaan2(
                        $bpilih)."-15"));
                      }
                      ?> </font></h5>   
                    <select style="margin-left: 25px;" name="id_Tracking">
                      <option>-- Pilih Bulan --</option>
                       <?php 
                        function ubahID($tanggal){
                        $pisah = explode(' ',$tanggal);
                        $bulan = array($pisah[1]);
                        $tahun = array($pisah[2]);
                        $pbulan = implode($bulan);
                        $ptahun = implode($tahun);
                        $satukan = $pbulan." ".$ptahun;
                        return $satukan;
                        }
                        function percobaan($test){
                        $a = $test[0].$test[1];
                        $b = $test[2].$test[3].$test[4].$test[5];
                        $pid = $b.'/'.$a;
                        return $pid;
                        }
                         ?><br><?php
                         function percobaan2($test2){
                        $a2 = $test2[0].$test2[1];
                        $b2 = $test2[2].$test2[3].$test2[4].$test2[5];
                        $pid2 = $b2.'-'.$a2;
                        return $pid2;
                        }
                         function tgl_indo($tanggal){
                          $bulan = array (
                            1 =>   'Januari',
                            'Februari',
                            'Maret',
                            'April',
                            'Mei',
                            'Juni',
                            'Juli',
                            'Agustus',
                            'September',
                            'Oktober',
                            'November',
                            'Desember'
                          );
                          $pecahkan = explode('-', $tanggal);
                          
                          // variabel pecahkan 0 = tanggal
                          // variabel pecahkan 1 = bulan
                          // variabel pecahkan 2 = tahun
                         
                          return $pecahkan[2] . ' ' . $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
                        }?>
                        <?php
                        foreach($list as $l){
                          $id= $l->id_tracking;
                          $date=date_create(percobaan($id)."/15");
                        ?>
                        <option value="<?php echo $l->id_tracking ?>"><?php echo ubahID(tgl_indo(percobaan2($id)."-15")); ?></option>
                        <?php } ?>  
                    </select>
                    <input type="submit" name="Pilih_id" value="Search">
                    </form>
                  <br>
                  <div class="table-responsive">
                    <form action="<?php echo base_url().'c_admin/update_tracking'; ?>" method="post"> 
                    <table class="table table-hoverable" border="1">
                      <thead>
                        <tr>
                         <td class="text-center">No</td>
                         <td class="text-center">ID Regional</td>
                         <td class="text-center">ID Area</td>
                         <td class="text-center">Cabang</td>
                         <td class="text-center">ID Kumpulan</td>
                         <td class="text-center">Nama Kumpulan</td>
                         <td class="text-center">NIK Karyawan</td>
                         <td class="text-center">Nama Karyawan</td>
                         <td class="text-center">Tipe Pengajuan</td>
                         <td class="text-center">Tipe Pinjaman</td>
                         <td class="text-center">Tgl Kirim</td>
                         <td class="text-center">Tgl Revisi</td>
                         <td class="text-center">Tgl OK</td>
                         <td class="text-center">Tgl LKKM 1</td>
                         <td class="text-center">Tgl LKKM 2</td>
                         <td class="text-center">Tgl Pengesahan</td>
                         <td class="text-center">Tgl Pencairan</td>
                         <td class="text-center">Jml Mitra</td>
                         <td class="text-center">Jml Pencairan</td>
                        </tr>
                      </thead>
                      <tbody>
                       <tr>
                         <?php 
                           function ubahTanggal($tanggal){
                           $pisah = explode('-',$tanggal);
                           $array = array($pisah[2],$pisah[1],$pisah[0]);
                           $satukan = implode('/',$array);
                           return $satukan;
                         }
                          $no=1;?>
                          <?php foreach ($tracking as $t){?>  
                          <th class="text-center"><?php echo $no?></th>
                          <td class="text-center"><?php echo $t->id_regional ?></td>
                          <td class="text-center"><?php echo $t->id_area ?></td>
                          <td class="text-center"><?php echo $t->cabang ?></td>
                          <td class="text-center"><input type="hidden" name="id_kumpulan<?php echo $no?>" value="<?php echo $t->id_kumpulan ?>"><?php echo $t->id_kumpulan ?></td>
                          <td class="text-left"><?php echo $t->nama_kumpulan ?></td>
                          <td class="text-left"><?php echo $t->nik ?></td>
                          <td class="text-left"><?php echo $t->nama ?></td>
                          <td class="text-center"><?php echo $t->tipe_pengajuan ?></td>
                          <td class="text-center"><?php echo $t->tipe_pinjaman ?></td>
                          <td class="text-center">
                            <input type="hidden" name="tgl_kirim<?php echo $no?>" value="<?php echo $t->tgl_kirim?>">
                            <?php $tgl_terbit = ubahTanggal($t->tgl_kirim );
                          echo $tgl_terbit?></td>
                          <td class="text-center"><?php 
                          if($t->tgl_revisi=="0000-00-00" && $t->tgl_ok!="0000-00-00" ){

                          }else{
                            if($t->tgl_revisi =="0000-00-00"){
                            ?><input type="date" name="tgl_revisi<?php echo $no?>" id="tanggal" /></td>
                            <?php }else{
                            $tgl_terbit = ubahTanggal($t->tgl_revisi );  
                            echo $tgl_terbit;
                            ?><input type="hidden" name="tgl_revisi<?php echo $no?>" value="<?php echo $t->tgl_revisi?>">
                            <?php }
                          }
                          ?>
                        </td>
                          <td class="text-center"><?php 
                          if($t->tgl_ok =="0000-00-00"){
                          ?><input type="date" name="tgl_ok<?php echo $no?>" id="tanggal" /></td>
                          <?php }else{
                          $tgl_terbit = ubahTanggal($t->tgl_ok );  
                          echo $tgl_terbit;
                          ?><input type="hidden" name="tgl_ok<?php echo $no?>" value="<?php echo $t->tgl_ok?>">
                          <?php }
                          ?>
                        </td>
                          <td class="text-center"><?php 
                          if($t->tgl_lkkm1 =="0000-00-00"){
                          ?><input type="date" name="tgl_lkkm1<?php echo $no?>" id="tanggal" /></td>
                          <?php }else{
                          $tgl_terbit = ubahTanggal($t->tgl_lkkm1 );  
                          echo $tgl_terbit;
                          ?><input type="hidden" name="tgl_lkkm1<?php echo $no?>" value="<?php echo $t->tgl_lkkm1?>">
                          <?php }
                          ?></td>
                          <td class="text-center"><?php 
                          if($t->tgl_lkkm2=="0000-00-00" && $t->tgl_pengesahan!="0000-00-00" ){

                          }
                          else{
                            if($t->tgl_lkkm2 =="0000-00-00"){
                            ?><input type="date" name="tgl_lkkm2<?php echo $no?>" id="tanggal" /></td>
                            <?php }else{
                            $tgl_terbit = ubahTanggal($t->tgl_lkkm2 );  
                            echo $tgl_terbit;
                            ?> <input type="hidden" name="tgl_lkkm2<?php echo $no?>" value="<?php echo $t->tgl_lkkm2?>"> 
                          <?php }
                          }
                          ?>
                      </td>
                          <td class="text-center"><?php 
                          if($t->tgl_pengesahan =="0000-00-00"){
                          ?><input type="date" name="tgl_pengesahan<?php echo $no?>" id="tanggal" /></td>
                          <?php }else{
                          $tgl_terbit = ubahTanggal($t->tgl_pengesahan );  
                          echo $tgl_terbit;
                          ?><input type="hidden" name="tgl_pengesahan<?php echo $no?>" value="<?php echo $t->tgl_pengesahan?>">
                          <?php }
                          ?></td>
                          <td class="text-center"><?php 
                          if($t->tgl_pencairan =="0000-00-00"){
                          ?><input type="date" name="tgl_pencairan<?php echo $no?>" id="tanggal" /></td>
                          <?php }else{
                          $tgl_terbit = ubahTanggal($t->tgl_pencairan );  
                          echo $tgl_terbit;
                          ?><input type="hidden" name="tgl_pencairan<?php echo $no?>" value="<?php echo $t->tgl_pencairan?>">
                          <?php }
                          ?></td>
                          <?php if($t->tgl_pencairan =="0000-00-00"){?>
                            <td><input type="text-center" style="width:20px" maxlength="2" name="jml_mitra<?php echo $no?>" value="<?php echo $t->jml_mitra ;?>"></td>
                            <td><input type="text-center" style="width:100px" maxlength="9" name="jml_pencairan<?php echo $no?>" value="<?php echo $t->jml_pencairan ;?>"></td>
                         <?php }
                         else{?>
                          <td class="text-center"><input type="hidden"name="jml_mitra<?php echo $no?>" value="<?php echo $t->jml_mitra ;?>"><?php echo $t->jml_mitra ;?></td>
                          <td class="text-center"><input type="hidden" name="jml_pencairan<?php echo $no?>" value="<?php echo $t->jml_pencairan ;?>"><?php echo number_format($t->jml_pencairan) ;?></td>
                        <?php } ?>
                        </tr>
                         <?php 
                        $no++;
                       } ?>
                      </tbody>
                    </table>
                  </div>
                   <input type="hidden" name="id_tracking" value="<?php echo $t->id_tracking ?>">
                  <center><input class="mdc-button mdc-button--unelevated" style="width: 200px;height:50px;" type="submit" value="Save" name="save"></center>
                  </form>
                  <font>Pilih Baris Untuk Mengedit</font>
                  <table style="width:10px">
                  <thead>
                    <tr>
                      <td>Baris</td>
                    </tr>
                   </thead>
                   <tbody>
                    <form action="<?php echo base_url().'c_admin/edit_tracking';?>" method="post">
                      <?php $no1=1;
                      foreach ($tracking as $t){ ?>
                      <th>
                       <input type="hidden" name="id_kumpulanedit" value="<?php echo $t->id_kumpulan?>">
                       <input type="hidden" name="tgl_kirimedit" value="<?php echo $t->tgl_kirim?>">
                       <input type="submit" name="edit" value="<?php echo $no1?>"> 
                       <?php $no1++; } ?>
                    </form>
                      </th>
                   </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </main>
        <!-- partial:partials/_footer.html -->
        <footer>
          <div class="mdc-layout-grid">
            <div class="mdc-layout-grid__inner">
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-6-desktop">
                <span class="text-center text-sm-left d-block d-sm-inline-block tx-14">Copyright © <a href="https://www.bootstrapdash.com/" target="_blank">bootstrapdash.com </a>2020</span>
              </div>
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-6-desktop d-flex justify-content-end">
              <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center tx-14">PT Bina Artha Ventura</span>
              </div>
            </div>
          </div>
        </footer>
        <!-- partial -->
      </div>
    </div>
  </div>
  <!-- plugins:js -->
  <script src="<?php echo base_url().'/assets/vendors/js/vendor.bundle.base.js'?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="<?php echo base_url().'/assets/vendors/chartjs/Chart.min.js'?>"></script>
  <script src="<?php echo base_url().'/assets/vendors/jvectormap/jquery-jvectormap.min.js'?>"></script>
  <script src="<?php echo base_url().'/assets/vendors/jvectormap/jquery-jvectormap-world-mill-en.js'?>"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?php echo base_url().'/assets/js/material.js'?>"></script>
  <script src="<?php echo base_url().'/assets/js/misc.js'?>"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo base_url().'/assets/js/dashboard.js'?>"></script>
  <!-- End custom js for this page-->
</body>
</html> 