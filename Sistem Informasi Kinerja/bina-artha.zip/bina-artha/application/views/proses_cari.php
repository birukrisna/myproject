<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Bina Artha Ventura</title>
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="<?php echo base_url().'assets_proses/css/styles.css'?>" rel="stylesheet" />
        <link rel="stylesheet" href="<?php echo base_url().'/assets/vendors/mdi/css/materialdesignicons.min.css'?>">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
    </head>
    <body id="page-top">
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
            <div class="container px-4">
                <a class="navbar-brand" href="<?php echo base_url().'c_proses/index'?>"><img height="50" src="<?php echo base_url().'/assets/images/Logo_bav_putih.png'?>"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item"><a class="nav-link" href="#proses">Proses</a></li>
                        <li class="nav-item"><a class="nav-link" href="#contact">contact</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- About section-->
        <section id="proses">
            <div class="container px-4">
                <div class="row gx-4 justify-content-center">
                    <div class="col-lg-8">
                        <?php foreach ($mitra as $m){ ?>
                        <table>
                            <tr>
                                <td>Id Mitra</td>
                                <td><?php echo $m->id_mitra?></td>
                            </tr>
                            <tr>
                                <td>Nama Mitra</td>
                                <td><?php echo $m->nama_lengkap?></td>
                                
                            </tr>
                            <tr>
                                <td>Besar Pinjaman</td>
                                <td>Rp. <?php echo number_format($m->bsr_pinjaman)?></td>
                                
                            </tr>
                            <tr>
                                <td>Kumpulan</td>
                                <td><?php echo $m->nama_kumpulan?></td>       
                                <?php } ?>
                            </tr>
                        </table>
                        <p>Untuk Melihat Proses Klik Button Dibawah</p>
                        <form action="<?php echo base_url().'c_proses/cari'?>" method="post">
                            <?php foreach($mitra as $m) { ?>
                            <input type="hidden" name="id_kumpulan" value="<?php foreach ($mitra as $m){echo $m->id_kumpulan;}?>">
                            <input type="hidden" name="tgl_kirim" value="<?php foreach ($mitra as $m){echo $m->tgl_kirim;}?>">
                            <input type="hidden" name="id_mitra" value="<?php foreach ($mitra as $m){echo $m->id_mitra;}?>">
                        <?php } ?>
                            <input type="submit" name="cari" value="cek">
                        </form>
                        <?php foreach($mitra as $m){
                        $besar_pinjaman = $m->bsr_pinjaman; }
                        if ($besar_pinjaman == 0){
                            ?>
                            <table>
                                <td>Sedang Proses Survei</td>
                            </table>
                        <?php } 
                        ?>
                        <?php foreach($proses as $p) {?>
                            <?php if($p->tgl_pencairan == '0000-00-00' &&
                                    $p->tgl_pengesahan == '0000-00-00' && 
                                    $p->tgl_lkkm2 == '0000-00-00' && 
                                    $p->tgl_lkkm1 == '0000-00-00' &&
                                    $p->tgl_ok == '0000-00-00' &&
                                    $p->tgl_revisi == '0000-00-00' ) { ?>
                            <table>
                                <td>Proses</td>
                                <td> : </td>
                                <td>Pemeriksaan Kantor Pusat</td>
                            </table>
                            <?php } else if($p->tgl_ok== '0000-00-00') {?>
                            <table>
                                <td>Proses</td>
                                <td> : </td>
                                <td>Perbaikan Kantor Cabang</td>
                            </table>
                            <?php } else if($p->tgl_revisi == '0000-00-00' && $p->tgl_lkkm1== '0000-00-00') {?>
                            <table>
                                <td>Proses </td>
                                <td> : </td>
                                <td>Lanjut Latihan Kedisiplin Kelompot Mitra 1</td>
                            </table>
                            <?php } else if($p->tgl_lkkm1 == '0000-00-00') {?>
                            <table>
                                <td>Proses</td>
                                <td> : </td>
                                <td>Lanjut Latihan Kedisiplin Kelompot Mitra 1</td>
                            </table>
                             <?php } else if($p->tgl_lkkm2 == '0000-00-00' &&  $p->tgl_pengesahan == '0000-00-00' ) {?>
                            <table>
                                <td>Proses</td>
                                <td> : </td>
                                <td>Lanjut Latihan Kedisiplin Kelompot Mitra 2</td>
                            </table>
                           <?php } else if($p->tgl_pengesahan == '0000-00-00') {?>
                            <table>
                                <td>Proses</td>
                                <td> : </td>
                                <td>Uji Pengesahan Kelompok Mitra</td>
                            </table>
                            <?php } else if($p->tgl_pencairan == '0000-00-00') {?>
                            <table>
                                <td>Proses</td>
                                <td> : </td>
                                <td>Tunggu Pencairan</td>
                            </table>
                            <?php } else if($p->tgl_lkkm2 == '0000-00-00' && $p->tgl_pengesahan != '0000-00-00' && $p->tgl_pencairan == '0000-00-00') {?>
                            <table>
                                <td>Proses</td>
                                <td> :  </td>
                                <td>Tunggu Pencairan</td>
                            </table>
                            <?php } else if($p->tgl_pencairan != '0000-00-00') {?>
                            <table>
                                <td>Proses</td>
                                <td> : </td>
                                <td>Selesai</td>
                            </table>
                           <?php } else if($p->tgl_lkkm2 == '0000-00-00' && $p->tgl_pencairan != '0000-00-00') {?>
                            <table>
                                <td>Proses</td>
                                <td> : </td>
                                <td>Selesai</td>
                            </table>
                            <?php } ?>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </section>
        <!-- Services section-->
        <section class="bg-light" id="contact">
            <div class="container px-4">
                <div class="row gx-4 justify-content-center">
                    <div class="col-lg-8">
                        <h2>Contact us</h2>
                        <p class="lead"><i class="material-icons">home_work</i> Jalan Raya Sindangsari Desa Ciwidey Kecamatan Ciwidey</p>
                        <p class="lead"> <i class="material-icons">phone</i> (022) 12345678</p>
                    </div>
                </div>
            </div>
        </section>
        <!-- Footer-->
        <footer class="py-5 bg-dark">
            <div class="container px-4"><p class="m-0 text-center text-white">Copyright &copy; PT Bina Artha Ventura Cabang Ciwidey</p></div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="<?php echo base_url().'assets_proses/js/scripts.js'?>"></script>
    </body>
</html>
