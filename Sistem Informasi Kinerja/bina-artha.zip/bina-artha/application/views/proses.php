<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Bina Artha Ventura</title>
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="<?php echo base_url().'assets_proses/css/styles.css'?>" rel="stylesheet" />
        <link rel="stylesheet" href="<?php echo base_url().'/assets/vendors/mdi/css/materialdesignicons.min.css'?>">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
    </head>
    <body id="page-top">
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
            <div class="container px-4">
                <a class="navbar-brand"href="<?php echo base_url().'c_proses/index'?>"><img height="50" src="<?php echo base_url().'/assets/images/Logo_bav_putih.png'?>"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item"><a class="nav-link" href="#contact">contact</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Header-->
        <header class="bg-primary bg-gradient text-white">
            <div class="container px-4 text-center">
                <h1 class="fw-bolder">Welcome </h1>
                <p class="lead">Silahkan Masukan Id Mitra Untuk Melihat Proses</p>
                <p><form action="<?php echo base_url().'c_proses/cari'?>" method="post">
                    <input type="input" name="id_mitra" required="true">
                </p>
                <input type="submit" class="btn btn-lg btn-light" value="cari">
                </form>
            </div>
        </header>
        <!-- Contact section-->
        <section class="bg-light" id="contact">
            <div class="container px-4">
                <div class="row gx-4 justify-content-center">
                    <div class="col-lg-8">
                        <h2>Contact us</h2>
                        <p class="lead"><i class="material-icons">home_work</i> Jalan Raya Sindangsari Desa Ciwidey Kecamatan Ciwidey</p>
                        <p class="lead"> <i class="material-icons">phone</i> (022) 12345678</p>
                    </div>
                </div>
            </div>
        </section>
        <!-- Footer-->
        <footer class="py-5 bg-dark">
            <div class="container px-4"><p class="m-0 text-center text-white">Copyright &copy; PT Bina Artha Ventura Cabang Ciwidey</p></div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="<?php echo base_url().'assets_proses/js/scripts.js'?>"></script>
    </body>
</html>
