<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>TRACKING BINA ARTHA</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo base_url().'/assets/vendors/mdi/css/materialdesignicons.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'/assets/vendors/css/vendor.bundle.base.css'?>">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="<?php echo base_url().'/assets/vendors/flag-icon-css/css/flag-icon.min.css'?>">
  <link rel="stylesheet" href="<?php echo base_url().'/assets/vendors/jvectormap/jquery-jvectormap.css'?>">
  <!-- End plugin css for this page -->
  <!-- Layout styles -->
  <link rel="stylesheet" href="<?php echo base_url().'/assets/css/demo/style.css'?>">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="<?php echo base_url().'/assets/images/favicon.png'?>" />
<!-- chart -->
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <script type="text/javascript">
    google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
      var data = google.visualization.arrayToDataTable([
      ["Element", "pencairan", { role: "style" } ],
      <?php foreach ($pencapaian as $capai){?>
      ["<?php echo $capai->nama ?>",<?php echo (int)$capai->jml_pencairan ?>,"red"],
      <?php }?>
      ]);
      var view = new google.visualization.DataView(data);
      view.setColumns([0, 1,
        { calc: "stringify",
          sourceColumn: 1,
          type: "string",
          role: "annotation" },
      2]);
      var options = {
        title: "Pencapaian Cabang Ciwidey Tahun <?php echo date('Y')?>",
        width: 500,
        height: 300,
        bar: {groupWidth: "95%"},
        legend: { position: "none" },
      };
     var chart = new google.visualization.ColumnChart(document.getElementById("columnchart_values"));
     chart.draw(view, options);
     }
  </script>
  <!-- Pie -->
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <script type="text/javascript">
    google.charts.load('current', {'packages':['corechart']});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
      var data = google.visualization.arrayToDataTable([
       ['Nama', 'Mitra Cair'],
      <?php foreach ($pencapaian as $capai){?>
       ['<?php echo $capai->nama ?>',<?php echo number_format($capai->jml_mitra)?>],
      <?php }?>
       ]);
    var options = {
         title: 'Pencapaian Per AO'
        };
    var chart = new google.visualization.PieChart(document.getElementById('piechart'));
     chart.draw(data, options);
   }
  </script>
<!-- Line Chart -->
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Year', 'Penjualan', 'Pencairan'],
          <?php foreach($pencapaian_bulan as $capai_bulan){
            $nama_bulan = array('bulan','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember');
            ?>
          ['<?php echo $nama_bulan[$capai_bulan->bulan]?>',<?php echo $capai_bulan->jml_mitra?>,
          <?php $cair = $capai_bulan->jml_pencairan / 1000000; echo $cair ?>],
        <?php } ?>
        ]);

        var options = {
          title: 'Pencapaian Cabang 1 Tahun',
          curveType: 'function',
          width: 1020,
          height: 400,
          legend: { position: 'bottom' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

        chart.draw(data, options);
      }
    </script>
</head>
<body>
<script src="<?php echo base_url().'/assets/js/preloader.js'?>"></script>
  <div class="body-wrapper">
    <!-- partial:partials/_sidebar.html -->
    <aside class="mdc-drawer mdc-drawer--dismissible mdc-drawer--open">
      <div class="mdc-drawer__header">
        <a href="<?php echo base_url().'c_admin/'?>" class="brand-logo">
          <img src="<?php echo base_url().'/assets/images/Logo_bav_putih.png'?>" height="100px" alt="logo">
        </a>
      </div>
      <div class="mdc-drawer__content">
        <div class="user-info">
          <p class="name"><?php echo $this->session->userdata("nama");?></p>
          <p class="email"><?php foreach ($nama_user as $n) {echo $n->nama;}?></p>
        </div>
        <div class="mdc-list-group">
          <nav class="mdc-list mdc-drawer-menu">
            <div class="mdc-list-item mdc-drawer-item">
              <a class="mdc-drawer-link" href="<?php echo base_url().'c_admin/index'?>">
                <i class="material-icons mdc-list-item__start-detail mdc-drawer-item-icon" aria-hidden="true">home</i>
                Dashboard
              </a>
            </div>
            <div class="mdc-list-item mdc-drawer-item">
              <a class="mdc-drawer-link" href="<?php echo base_url().'c_admin/tracking'?>">
                <i class="material-icons mdc-list-item__start-detail mdc-drawer-item-icon" aria-hidden="true">book</i>
                Tracking
              </a>
            </div>
            <div class="mdc-list-item mdc-drawer-item">
              <a class="mdc-drawer-link" href="<?php echo base_url().'c_admin/list_kumpulan_proses'?>">
                <i class="material-icons mdc-list-item__start-detail mdc-drawer-item-icon" aria-hidden="true">comment</i>
                Plafond
              </a>
            </div>
             <div class="mdc-list-item mdc-drawer-item">
              <a class="mdc-drawer-link" href="<?php echo base_url().'c_admin/report'?>">
                <i class="material-icons mdc-list-item__start-detail mdc-drawer-item-icon" aria-hidden="true">assignment</i>
                Report
              </a>
            </div>
          </nav>
        </div>
        <div class="profile-actions">
          <a href="<?php echo base_url().'c_admin/logout'?>">Logout</a>
        </div>
      </div>
    </aside>
    <!-- partial -->
    <div class="main-wrapper mdc-drawer-app-content">
      <!-- partial:partials/_navbar.html -->
      <header class="mdc-top-app-bar">
        <div class="mdc-top-app-bar__row">
          <div class="mdc-top-app-bar__section mdc-top-app-bar__section--align-start">
            <button class="material-icons mdc-top-app-bar__navigation-icon mdc-icon-button sidebar-toggler">menu</button>
            <span class="mdc-top-app-bar__title">Greetings <?php foreach ($nama_user as $n) {echo $n->nama;}?> !!</span>
          </div>
        </div>
      </header>
      <!-- partial -->
      <div class="page-wrapper mdc-toolbar-fixed-adjust">
        <main class="content-wrapper">
          <div class="mdc-layout-grid">
            <div class="d-flex justify-content-between">
              <h4 class="card-title mb-0">Pencapaian Cabang Ciwidey Tahun <?php echo date('Y')?></h4>
            </div>
            <br>
            <div class="mdc-layout-grid__inner">
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-3-desktop mdc-layout-grid__cell--span-4-tablet">
                <div class="mdc-card info-card info-card--success">
                  <div class="card-inner">
                    <h5 class="card-title">UKM</h5>
                    <h5 class="font-weight-light pb-2 mb-1 border-bottom"><?php 
                    foreach ($ukm as $u){echo number_format($u->jml_mitra_ukm)?> Mitra</h5>
                    <p class="tx-12 text-muted"><?php $target = 60 *12;$realisasiukm = $u->jml_mitra_ukm;
                    $persentaseukm = $realisasiukm/$target *100; echo round($persentaseukm,2);?>% target of <?php echo $target;?></p>
                    <div class="card-icon-wrapper">
                      <i class="material-icons">person_add</i>
                      <?php ;} ?>
                    </div>
                  </div>
                </div>
              </div>
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-3-desktop mdc-layout-grid__cell--span-4-tablet">
                <div class="mdc-card info-card info-card--danger">
                  <div class="card-inner">
                    <h5 class="card-title">LKKM</h5>
                    <h5 class="font-weight-light pb-2 mb-1 border-bottom"><?php 
                    foreach ($lkkm as $l){echo number_format($l->jml_mitra_lkkm)?> Mitra</h5>
                    <p class="tx-12 text-muted"><?php $target = 60 *12;$realisasilkkm = $l->jml_mitra_lkkm;
                    $persentaselkkm = $realisasilkkm/$target *100; echo round($persentaselkkm,2);?>% target  of <?php echo $target;?></p>
                     <?php ;} ?>
                    <div class="card-icon-wrapper">
                      <i class="material-icons">event_note</i>
                      
                    </div>
                  </div>
                </div>
              </div>
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-3-desktop mdc-layout-grid__cell--span-4-tablet">
                <div class="mdc-card info-card info-card--primary">
                  <div class="card-inner">
                    <h5 class="card-title">UPKM</h5>
                    <h5 class="font-weight-light pb-2 mb-1 border-bottom"><?php 
                    foreach ($upkm as $up){echo number_format($up->jml_mitra_upkm)?> Mitra</h5>
                    <p class="tx-12 text-muted"><?php $target = 60 *12;$realisasiupkm = $up->jml_mitra_upkm;
                    $persentaseupkm = $realisasiupkm/$target *100; echo round($persentaseupkm,2);?>% target of <?php echo $target;?></p>
                    <?php ;} ?>
                    <div class="card-icon-wrapper">
                      <i class="material-icons">assignment_turned_in</i>
                    </div>
                  </div>
                </div>
              </div>
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-3-desktop mdc-layout-grid__cell--span-4-tablet">
                <div class="mdc-card info-card info-card--info">
                  <div class="card-inner">
                    <h5 class="card-title">Pencairan</h5>
                    <h5 class="font-weight-light pb-2 mb-1 border-bottom">Rp <?php 
                    foreach ($pencairan as $pe){echo number_format($pe->jml_pencairan)?></h5>
                    <p class="tx-12 text-muted"><?php $target = 200000000 *12;$realisasipencairan = $pe->jml_pencairan;
                    $persentasepencairan = $realisasipencairan/$target *100 ; echo round($persentasepencairan,2);?>% target  of<br> Rp <?php echo number_format($target);?></p>
                    <?php ;} ?>
                    <div class="card-icon-wrapper">
                      <i class="material-icons">attach_money</i>
                      
                    </div>
                  </div>
                </div>
              </div>
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-12">
                <div class="mdc-card">
                  <div class="d-flex justify-content-between">
                    <h4 class="card-title mb-0">Revenue by location</h4>
                    <div>
                        <i class="material-icons refresh-icon">refresh</i>
                        <i class="material-icons options-icon ml-2">more_vert</i>
                    </div>
                  </div>
                  <div class="d-block d-sm-flex justify-content-between align-items-center">
                      <h5 class="card-sub-title mb-2 mb-sm-0">Performa Pencapaian Per Sales</h5>
                      <div class="menu-button-container">
                        <button class="mdc-button mdc-menu-button mdc-button--raised button-box-shadow tx-12 text-dark bg-white font-weight-light">
                            Last 7 days
                          <i class="material-icons">arrow_drop_down</i>
                        </button>
                        <div class="mdc-menu mdc-menu-surface" tabindex="-1">
                          <ul class="mdc-list" role="menu" aria-hidden="true" aria-orientation="vertical">
                            <li class="mdc-list-item" role="menuitem">
                              <h6 class="item-subject font-weight-normal">Back</h6>
                            </li>
                            <li class="mdc-list-item" role="menuitem">
                              <h6 class="item-subject font-weight-normal">Forward</h6>
                            </li>
                            <li class="mdc-list-item" role="menuitem">
                              <h6 class="item-subject font-weight-normal">Reload</h6>
                            </li>
                            <li class="mdc-list-divider"></li>
                            <li class="mdc-list-item" role="menuitem">
                              <h6 class="item-subject font-weight-normal">Save As..</h6>
                            </li>
                          </ul>
                        </div>
                      </div>
                  </div>
                  <div class="mdc-layout-grid__inner mt-2">
                    <div class="mdc-layout-grid__cell mdc-layout-grid__cell--span-6 mdc-layout-grid__cell--span-8-tablet">
                     <div id="columnchart_values" style="width: 600px; height: 300px;"></div>
                    </div>
                    <div class="mdc-layout-grid__cell mdc-layout-grid__cell--span-6 mdc-layout-grid__cell--span-8-tablet"> 
                      <div id="piechart" style="width: 480px; height: 300px;"></div>   
                    </div>
                  </div>
                </div> 
              </div>
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-4">
                <div id="curve_chart" style="width: 900px; height: 500px"></div>
              </div>
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-4 mdc-layout-grid__cell--span-8-tablet">
            </div>
          </div>
        </main>
        <!-- partial:partials/_footer.html -->
        <footer>
          <div class="mdc-layout-grid">
            <div class="mdc-layout-grid__inner">
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-6-desktop">
                <span class="text-center text-sm-left d-block d-sm-inline-block tx-14">Copyright © <a href="https://www.bootstrapdash.com/" target="_blank">bootstrapdash.com </a>2020</span>
              </div>
              <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-6-desktop d-flex justify-content-end">
                <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center tx-14">PT Bina Artha Ventura</span>
              </div>
            </div>
          </div>
        </footer>
        <!-- partial -->
      </div>
    </div>
  </div>
  <!-- plugins:js -->
  <script src="<?php echo base_url().'/assets/vendors/js/vendor.bundle.base.js'?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="<?php echo base_url().'/assets/vendors/chartjs/Chart.min.js'?>"></script>
  <script src="<?php echo base_url().'/assets/vendors/jvectormap/jquery-jvectormap.min.js'?>"></script>
  <script src="<?php echo base_url().'/assets/vendors/jvectormap/jquery-jvectormap-world-mill-en.js'?>"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?php echo base_url().'/assets/js/material.js'?>"></script>
  <script src="<?php echo base_url().'/assets/js/misc.js'?>"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo base_url().'/assets/js/dashboard.js'?>"></script>
  <!-- End custom js for this page-->
</body>
</html> 