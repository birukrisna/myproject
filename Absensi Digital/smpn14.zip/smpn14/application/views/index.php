<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Presensi Digital SMPN14</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="<?php echo base_url().'assets/asset/img/favicon.png'?>" rel="icon">
  <link href="<?php echo base_url().'assets/asset/img/apple-touch-icon.png'?>" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,700|Open+Sans:300,300i,400,400i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo base_url().'assets/asset/vendor/bootstrap/css/bootstrap.min.css'?>" rel="stylesheet">
  <link href="<?php echo base_url().'assets/asset/vendor/ionicons/css/ionicons.min.css'?>" rel="stylesheet">
  <link href="<?php echo base_url().'assets/asset/vendor/animate.css/animate.min.css'?>" rel="stylesheet">
  <link href="<?php echo base_url().'assets/asset/vendor/font-awesome/css/font-awesome.min.css'?>" rel="stylesheet">
  <link href="<?php echo base_url().'assets/asset/vendor/venobox/venobox.css'?>" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?php echo base_url().'assets/asset/css/style.css'?>" rel="stylesheet">
  <link href="<?php echo base_url().'assets/asset/css/table.css'?>" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Avilon - v2.2.0
  * Template URL: https://bootstrapmade.com/avilon-bootstrap-landing-page-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header-transparent">
    <div class="container">

      <div id="logo" class="pull-left">
        <h1><a href="<?php echo base_url().'c_absen/absen'?>" class="scrollto">Digisen</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="<?php echo base_url().'assets/asset/img/logo.png'?>" alt=""></a> -->
      </div>
      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a href="#intro">
            <?php foreach ($nama as $n) {echo $n->nama_user;}?>  
            </a>
            <ul>
              <li><a href="<?php echo base_url().'c_absen/logout'?>">Log Out</a></li>
            </ul>
          </li>
          <li><a href="#rekapabsen">Rekap Presensi</a></li>
          <li><a href="#hariini">Rekap Hari ini</a></li>
          <li><a href="<?php echo base_url().'c_absen/absen'?>">Presensi</a></li>
        </ul>
      </nav><!-- #nav-menu-container -->
    </div>
  </header><!-- End Header -->

  <!-- ======= Intro Section ======= -->
  <section id="intro">

    <div class="intro-text">
      <h2>Selamat Datang di Digital Presensi</h2>
      <p>Silahkan Klik Absen Untuk Memulai Presensi Siswa</p>
      <a href="<?php echo base_url().'c_absen/absen'?>" class="btn-get-started scrollto">Absen</a>
    </div>
    <div class="product-screens">
    </div>
  </section><!-- End Intro Section -->
  <main id="main">
    <!-- ======= About Section ======= -->
    <section id="rekapabsen" class="section-bg">
      <div class="container-fluid">
        <div class="section-header">
          <h3 class="section-title">Rekap Presensi Per Semester</h3>
          <span class="section-divider"></span>
          
            <center>
            <table border="1">
              <tr>
                <th>No</th>
                <th>Keterangan Tidak Masuk</th>
                <th>Jumlah Siswa</th>
              </tr>
              <tr>
                <td>1</td>
                <td>Sakit</td>
                <td style="text-align: center;"><?php foreach ($rsakit as $rs) {echo $rs->sakit;}?></td>
              </tr>
              <tr>
                <td>2</td>
                <td>Izin</td>
                <td style="text-align: center;"><?php foreach ($rizin as $ri) {echo $ri->izin;}?></td>
              </tr>
              <tr>
                <td>3</td>
                <td>Tampa Keterangan</td>
                <td style="text-align: center;"><?php foreach ($ralfa as $ra) {echo $ra->alfa;}?></td>
              </tr>
              <tr>
                <td style="text-align: center;font-weight: bold;" colspan="2">jumlah</td>
                <td style="text-align: center;"><?php foreach ($rrekap as $rr) {echo $rr->rekap;}?></td>
              </tr>
            </table>
            </center>
            <p class="section-description"> </p>

        </div>
      </div>
    </section><!-- End rekapabsen Section -->

    <!-- ======= Rekap Hari ini Section ======= -->
    <section id="hariini">
      <div class="container">
        <div class="row">
          <div class="container-fluid">
            <div class="section-header wow fadeIn" data-wow-duration="1s">
              <h3 class="section-title">Rekap Presensi Hari ini</h3>
              <span class="section-divider"></span>
              <center>
            <table border="1">
              <tr>
                <th>No</th>
                <th>Keterangan Tidak Masuk</th>
                <th>Jumlah Siswa</th>
              </tr>
              <tr>
                <td>1</td>
                <td>Sakit</td>
                <td style="text-align: center;"><?php foreach ($sakit as $s){ echo $s->sakit;} ?> </td>
              </tr>
              <tr>
                <td>2</td>
                <td>Izin</td>
                <td style="text-align: center;"><?php foreach ($izin as $i){ echo $i->izin;} ?></td>
              </tr>
              <tr>
                <td>3</td>
                <td>Tampa Keterangan</td>
                <td style="text-align: center;"> <?php foreach ($alfa as $a){ echo $a->alfa;} ?> </td>
              </tr>
              <tr>
                <td style="text-align: center;font-weight: bold;" colspan="2">jumlah</td>
                <td style="text-align: center;"><?php foreach ($rekap as $r){ echo $r->rekap;} ?></td>
              </tr>
            </table>
            </center>
            <p class="section-description"> </p>
            </div>
          </div>
        </div>
      </div>
    </section><!-- rekep Hari ini Section -->  
  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 text-lg-left text-center">
          <div class="copyright">
            &copy; Copyright <strong>Avilon</strong>. All Rights Reserved
          </div>
          <div class="credits">
            <!--
            All the links in the footer should remain intact.
            You can delete the links only if you purchased the pro version.
            Licensing information: https://bootstrapmade.com/license/
            Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Avilon
          -->
            Designed by bocah_biru@46
          </div>
        </div>
      </div>
    </div>
  </footer><!-- End  Footer -->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo base_url().'assets/asset/vendor/jquery/jquery.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/asset/vendor/bootstrap/js/bootstrap.bundle.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/asset/vendor/jquery.easing/jquery.easing.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/asset/vendor/php-email-form/validate.js'?>"></script>
  <script src="<?php echo base_url().'assets/asset/vendor/wow/wow.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/asset/vendor/venobox/venobox.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/asset/vendor/superfish/superfish.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/asset/vendor/hoverIntent/hoverIntent.js'?>"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo base_url().'assets/asset/js/main.js'?>"></script>

</body>

</html>