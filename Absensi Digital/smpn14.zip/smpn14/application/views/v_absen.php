<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Presensi Digital SMPN14</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="<?php echo base_url().'assets/asset/img/favicon.png'?>" rel="icon">
  <link href="<?php echo base_url().'assets/asset/img/apple-touch-icon.png'?>" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,700|Open+Sans:300,300i,400,400i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo base_url().'assets/asset/vendor/bootstrap/css/bootstrap.min.css'?>" rel="stylesheet">
  <link href="<?php echo base_url().'assets/asset/vendor/ionicons/css/ionicons.min.css'?>" rel="stylesheet">
  <link href="<?php echo base_url().'assets/asset/vendor/animate.css/animate.min.css'?>" rel="stylesheet">
  <link href="<?php echo base_url().'assets/asset/vendor/font-awesome/css/font-awesome.min.css'?>" rel="stylesheet">
  <link href="<?php echo base_url().'assets/asset/vendor/venobox/venobox.css'?>" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?php echo base_url().'assets/asset/css/style.css'?>" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Avilon - v2.2.0
  * Template URL: https://bootstrapmade.com/avilon-bootstrap-landing-page-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header-transparent">
    <div class="container">

      <div id="logo" class="pull-left">
        <h1><a href="<?php echo base_url().'c_absen/'?>" class="scrollto">Digisen</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="<?php echo base_url().'assets/asset/img/logo.png'?>" alt=""></a> -->
      </div>
      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a href="#intro2"><?php foreach ($nama as $n) {echo $n->nama_user;}?></a>
            <ul>
              <li><a href="<?php echo base_url().'c_absen/logout'?>">Log Out</a></li>
            </ul>
          </li>
          <li><a href="<?php echo base_url().'c_absen/absen'?>">Presensi</a></li>
        </ul>
      </nav><!-- #nav-menu-container -->
    </div>
  </header><!-- End Header -->

  <!-- ======= Intro Section ======= -->
  <section id="intro2">
  </section><!-- End Intro Section -->
  <main id="main">
    <!-- ======= About Section ======= -->
    <section id="about" class="section-bg">
      <div class="container-fluid">
        <div class="section-header">
          <h3 class="section-title">Presensi</h3>
          <span class="section-divider"></span>

          <p class="section-description">Presensi Digital SMPN 14 Bandung
            </p>
             <form action="<?php echo site_url('c_absen/aksi_form') ?>" method="post">
                    <div class="form-group">
                        <label>Kelas</label>
                        <select class="form-control" name="kelas" id="kelas">
                            <option value="">Please Select</option>
                            <?php
                            foreach ($kelas as $s) {
                                ?>
                                <option <?php echo $kelas_selected == $s->kelas ? 'selected="selected"' : '' ?>
                                    value="<?php echo $s->kelas ?>"><?php echo $s->kelas ?></option>
                                <?php
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Nama Siswa</label>
                        <select class="form-control" name="siswa" id="siswa">
                            <option value="">Please Select</option>
                            <?php
                            foreach ($siswa as $sw) {
                                ?>
                                <!--di sini kita tambahkan class berisi id provinsi-->
                                <option <?php echo $siswa_selected == $sw->kelas ? 'selected="selected"' : '' ?>
                                    class="<?php echo $sw->kelas ?>" value="<?php echo $sw->nis ?>"><?php echo $sw->nama_siswa ?></option>
                                <?php
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Keterangan</label>
                        <select class="form-control" name="keterangan" id="keterangan">
                            <option value="">Please Select</option>
                            <option value="1">Sakit</option>
                            <option value="2">Izin</option>
                            <option value="3">Tampa Keterangan</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="submit" class="btn btn-primary" value="Absen">
                    </div>
                </form>
      </div>
  </div>
    </section><!-- End About Section -->
    


  </main><!-- End #main -->
  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 text-lg-left text-center">
          <div class="copyright">
            &copy; Copyright <strong>Avilon</strong>. All Rights Reserved
          </div>
          <div class="credits">
            <!--
            All the links in the footer should remain intact.
            You can delete the links only if you purchased the pro version.
            Licensing information: https://bootstrapmade.com/license/
            Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Avilon
          -->
            Designed by bocah_biru@46</a>
          </div>
        </div>
      </div>
    </div>
  </footer><!-- End  Footer -->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo base_url().'assets/asset/vendor/jquery/jquery.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/asset/vendor/bootstrap/js/bootstrap.bundle.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/asset/vendor/jquery.easing/jquery.easing.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/asset/vendor/php-email-form/validate.js'?>"></script>
  <script src="<?php echo base_url().'assets/asset/vendor/wow/wow.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/asset/vendor/venobox/venobox.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/asset/vendor/superfish/superfish.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/asset/vendor/hoverIntent/hoverIntent.js'?>"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo base_url().'assets/asset/js/main.js'?>"></script>
  <script src="<?php echo base_url('assets/asset/js/jquery-1.10.2.min.js') ?>"></script>
  <script src="<?php echo base_url('assets/asset/js/jquery.chained.min.js') ?>"></script>
   <script>
            $("#siswa").chained("#kelas"); // disini kita hubungkan kota dengan provinsi
          //  $("#keterangan").chained("#siswa"); // disini kita hubungkan kecamatan dengan kota
  </script>

</body>

</html>