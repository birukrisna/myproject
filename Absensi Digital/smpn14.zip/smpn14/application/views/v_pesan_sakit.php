<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Presensi Digital SMPN14</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="<?php echo base_url().'assets/asset/img/favicon.png'?>" rel="icon">
  <link href="<?php echo base_url().'assets/asset/img/apple-touch-icon.png'?>" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,700|Open+Sans:300,300i,400,400i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo base_url().'assets/asset/vendor/bootstrap/css/bootstrap.min.css'?>" rel="stylesheet">
  <link href="<?php echo base_url().'assets/asset/vendor/ionicons/css/ionicons.min.css'?>" rel="stylesheet">
  <link href="<?php echo base_url().'assets/asset/vendor/animate.css/animate.min.css'?>" rel="stylesheet">
  <link href="<?php echo base_url().'assets/asset/vendor/font-awesome/css/font-awesome.min.css'?>" rel="stylesheet">
  <link href="<?php echo base_url().'assets/asset/vendor/venobox/venobox.css'?>" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?php echo base_url().'assets/asset/css/style.css'?>" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Avilon - v2.2.0
  * Template URL: https://bootstrapmade.com/avilon-bootstrap-landing-page-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header-transparent">
    <div class="container">

      <div id="logo" class="pull-left">
        <h1><a href="<?php echo base_url().'c_absen/'?>" class="scrollto">Digisen</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="<?php echo base_url().'assets/asset/img/logo.png'?>" alt=""></a> -->
      </div>
      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a href="#intro"><?php foreach ($nama as $n) {echo $n->nama_user;}?></a>
            <ul>
              <li><a href="<?php echo base_url().'c_absen/logout'?>">Log Out</a></li>
            </ul>
          </li>
          <li><a href="<?php echo base_url().'c_absen/absen'?>">Presensi</a></li>
        </ul>
      </nav><!-- #nav-menu-container -->
    </div>
  </header><!-- End Header -->

  <!-- ======= Intro Section ======= -->
  <section id="intro">
    <div class="product-screens">
    	<p align="left"><?php 
			foreach ($nmsiswa as $nm){ ?>
			<?php echo "Yth Bapak/Ibu ".$nm->nama_orang_tua." Kami dari SMPN 14 Bandung menginformasikan bahwa pada tanggal ".date('d-m-Y')." murid atas nama ".$nm->nama_siswa." Kelas ".$nm->kelas ;?> 
			<?php } ?>
 			<?php 
			foreach ($ketsiswa as $ks){ ?>
			<?php echo " tidak masuk karena ".$ks->keterangan." semoga cepat diberikan kesembuhan kembali agar dapat mengikuti pelajaran seperti biasa " ;?>
			<?php } ?></p>
			<br>		
			<br>
			<a href="<?php echo "https://wa.me/62".$nm->no_hp."/?text=Yth%20Bapak/Ibu%20".$nm->nama_orang_tua."%20Kami%20dari%20SMPN%2014%20Bandung%20menginformasikan%20bahwa pada%20tanggal%20".date('d-m-Y')."%20murid%20atas%20nama%20".$nm->nama_siswa."%20Kelas%20".$nm->kelas."%20tidak%20masuk%20karena%20".$ks->keterangan."%20semoga%20cepat%20diberikan%20kesembuhan%20kembali%20agar%20dapat%20mengikuti%20pelajaran%20seperti%20biasa" ;?>" target="_blank"><input type="button" class="btn btn-primary" name="kirim" value="Kirim"></a>
			<a href="<?php echo base_url().'c_absen/index';?>"><input type="button" class="btn btn-primary" name="kembali" value="Kembali"></a>
    </div>
  </section><!-- End Intro Section -->
  <main id="main">
   
  </main><!-- End #main -->
  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 text-lg-left text-center">
          <div class="copyright">
            &copy; Copyright <strong>Avilon</strong>. All Rights Reserved
          </div>
          <div class="credits">
            <!--
            All the links in the footer should remain intact.
            You can delete the links only if you purchased the pro version.
            Licensing information: https://bootstrapmade.com/license/
            Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Avilon
          -->
            Designed by bocah_biru@46</a>
          </div>
        </div>
      </div>
    </div>
  </footer><!-- End  Footer -->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo base_url().'assets/asset/vendor/jquery/jquery.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/asset/vendor/bootstrap/js/bootstrap.bundle.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/asset/vendor/jquery.easing/jquery.easing.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/asset/vendor/php-email-form/validate.js'?>"></script>
  <script src="<?php echo base_url().'assets/asset/vendor/wow/wow.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/asset/vendor/venobox/venobox.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/asset/vendor/superfish/superfish.min.js'?>"></script>
  <script src="<?php echo base_url().'assets/asset/vendor/hoverIntent/hoverIntent.js'?>"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo base_url().'assets/asset/js/main.js'?>"></script>
  <script src="<?php echo base_url('assets/asset/js/jquery-1.10.2.min.js') ?>"></script>
  <script src="<?php echo base_url('assets/asset/js/jquery.chained.min.js') ?>"></script>
   <script>
            $("#siswa").chained("#kelas"); // disini kita hubungkan kota dengan provinsi
          //  $("#keterangan").chained("#siswa"); // disini kita hubungkan kecamatan dengan kota
  </script>

</body>

</html>
