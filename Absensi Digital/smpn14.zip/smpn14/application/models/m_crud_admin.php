<?php

/**
 * 
 */
class M_crud_admin extends CI_Model
{
	
	function inputdata($data,$table)
	{
		$this->db->insert($table,$data);
	}
	function jumlahlaki(){
		$this->db->where('jenis_kelamin','Lelaki');
   		$this->db->select('count(jenis_kelamin) as laki');
    	$this->db->from('siswa');
    	$query = $this->db->get();
    	return $query;
	}
	function jumlahperempuan(){
		$this->db->where('jenis_kelamin','Perempuan');
   		$this->db->select('count(jenis_kelamin) as perempuan');
    	$this->db->from('siswa');
    	$query = $this->db->get();
    	return $query;
	}
	function jumlahsiswa(){
		$this->db->select('count(jenis_kelamin) as jk');
    	$this->db->from('siswa');
    	$query = $this->db->get();
    	return $query;
	}
	function tampildataot()
	{
		$this->db->order_by('siswa.kelas','ASC');
		$this->db->order_by('siswa.nama_siswa', 'ASC');
		$this->db->select('siswa.nis,siswa.nama_siswa,siswa.jenis_kelamin,siswa.kelas,orang_tua.nama_orang_tua,orang_tua.alamat,orang_tua.no_hp');
		$this->db->from('siswa');
		$this->db->join('orang_tua','orang_tua.nis=siswa.nis','inner');
		return $this->db->get();
	}
	function hapus_data($where,$table)
	{
		$this->db->where($where);
		$this->db->delete($table);
	}
	function tampileditsiswa($where,$table)
	{
		$this->db->select('siswa.nis,siswa.nama_siswa,siswa.jenis_kelamin,siswa.kelas,orang_tua.nama_orang_tua,orang_tua.alamat,orang_tua.no_hp');
		$this->db->join('orang_tua','orang_tua.nis=siswa.nis','inner');
    	return $this->db->get_where($table,$where);
	}
	function update_siswa($where,$siswa,$table)
	{
		$this->db->where($where);
		$this->db->update($table,$siswa);
	}
	function cek_nis($where,$table){		
	return $this->db->get_where($table,$where);
	}
}