<?php
/**
 * 
 */
class M_crud_absen extends CI_Model
{
	function input_data($data,$table)
  {
    $this->db->insert($table,$data);
  }
  function rekapabsen()
  {
    $this->db->select('count(keterangan) as rekap');
    $this->db->from('absensi');
    $query = $this->db->get();
    return $query;
  }
   function rekapsakit()
  {
    $this->db->where('keterangan','1');
    $this->db->select('count(keterangan) as sakit');
    $this->db->from('absensi');
    $query = $this->db->get();
    return $query;
  }
   function rekapizin()
  {
    $this->db->where('keterangan','2');
    $this->db->select('count(keterangan) as izin');
    $this->db->from('absensi');
    $query = $this->db->get();
    return $query;
  }
   function rekapalfa()
  {
    $this->db->where('keterangan','3');
    $this->db->select('count(keterangan) as alfa');
    $this->db->from('absensi');
    $query = $this->db->get();
    return $query;
  }
  function rekaphariabsen()
  {
    $hari_ini = date('Y-m-d');
    $this->db->where('tgl',$hari_ini);
    $this->db->select('count(keterangan) as rekap');
    $this->db->from('absensi');
    $query = $this->db->get();
    return $query;
  }
   function rekapharisakit()
  {
    $hari_ini = date('Y-m-d');
    $this->db->where('keterangan','1');
    $this->db->where('tgl',$hari_ini);
    $this->db->select('count(keterangan) as sakit');
    $this->db->from('absensi');
    $query = $this->db->get();
    return $query;
  }
   function rekaphariizin()
  {
    $hari_ini = date('Y-m-d');
    $this->db->where('keterangan','2');
    $this->db->where('tgl',$hari_ini);
    $this->db->select('count(keterangan) as izin');
    $this->db->from('absensi');
    $query = $this->db->get();
    return $query;
  }
   function rekapharialfa()
  {
    $hari_ini = date('Y-m-d');
    $this->db->where('keterangan','3');
    $this->db->where('tgl',$hari_ini);
    $this->db->select('count(keterangan) as alfa');
    $this->db->from('absensi');
    $query = $this->db->get();
    return $query;
  }
  function getkelas()
  {
    $this->db->select('DISTINCT(kelas)');
    $query = $this->db->get('siswa');
    //$this->db->distinct('kelas'); 
    return $query->result(); // Tampilkan semua data yang ada di tabel siswa
  }
    function getsiswa()
  {
    //$this->db->select('nis','nama_siswa');
    $this->db->order_by('nama_siswa','asc');
    return $this->db->get('siswa')->result(); // Tampilkan semua data yang ada di tabel siswa
  }
     function getketerangan()
  {
    //$this->db->select('nis','nama_siswa');
    return $this->db->get('ket_absen')->result(); // Tampilkan semua data yang ada di tabel siswa
  }
  function getnama($where)
  {
    $this->db->where($where);
    $this->db->join('orang_tua','orang_tua.nis = siswa.nis' );
    return $this->db->get('siswa')->result();
  }
  function getdata($where,$tabel)
  {
    $this->db->where($where);
    return $this->db->get($tabel)->result();
    //return $this->db->get_where($tabel,$where)->result();
  }
    function nama_user($where,$table){
    $this->db->select('nama_user');   
    return $this->db->get_where($table,$where);
  }
}
 