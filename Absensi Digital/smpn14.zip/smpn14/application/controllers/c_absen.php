<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */
class C_absen extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('m_crud_absen');
		$this->load->helper('url');
		
		if($this->session->userdata('status') !="loginabsen"){
			redirect('Welcome');
		}
	}
	function index()
	{
        $username = $this->session->userdata("nama");
        $where = array('username' => $username);
        $rekap = array(
            'rrekap' => $this->m_crud_absen->rekapabsen()->result(), 
            'rsakit' => $this->m_crud_absen->rekapsakit()->result(), 
            'rizin' => $this->m_crud_absen->rekapizin()->result(), 
            'ralfa' => $this->m_crud_absen->rekapalfa()->result(),
            'rekap' => $this->m_crud_absen->rekaphariabsen()->result(), 
            'sakit' => $this->m_crud_absen->rekapharisakit()->result(), 
            'izin' => $this->m_crud_absen->rekaphariizin()->result(), 
            'alfa' => $this->m_crud_absen->rekapharialfa()->result(),
            'nama' => $this->m_crud_absen->nama_user($where,'user')->result()
        );
		$this->load->view('index',$rekap);
	}
	function absen(){
        $username = $this->session->userdata("nama");
        $where = array('username' => $username);
		$data = array(
            'kelas' => $this->m_crud_absen->getkelas(),
            'siswa' => $this->m_crud_absen->getsiswa(),
            'keterangan' => $this->m_crud_absen->getketerangan(),
            'nama' => $this->m_crud_absen->nama_user($where,'user')->result(),
            'kelas_selected' => '',
            'siswa_selected' => '',
            'keterangan_selected' => ''
        );
       $this->load->view('v_absen', $data);
	}
    public function aksi_form()
    {
        // datanya bisa kita insert ke DB atau yang lain
        // di sini saya hanya menampilkan datanya saja
        $username = $this->session->userdata("nama");
        $where = array('username' => $username);
        $kelas =$this->input->post('kelas');
        $nis =$this->input->post('siswa');
        $keterangan =$this->input->post('keterangan');
        $nama = array('siswa.nis' => $nis );
        $date = date('Y-m-d');
        $ket =  array('id_keterangan' => $keterangan );
        $data = array(
            'nmsiswa' => $this->m_crud_absen->getnama($nama) ,
            'ketsiswa' => $this->m_crud_absen->getdata($ket,'ket_absen'),
            'nama' => $this->m_crud_absen->nama_user($where,'user')->result()
        );
        $isi = array(
            'nis' => $nis,
            'tgl' => $date,
            'keterangan' => $keterangan 
         );
        $this->m_crud_absen->input_data($isi,'absensi');
        //echo "Siswa bernama ".$dapatnama." dari kelas ".$kelas." sedang ".$keterangan;        
        if($keterangan == 1)
        {
            $this->load->view('v_pesan_sakit', $data);
        } else if($keterangan == 2)
        {
            $this->load->view('v_pesan_izin', $data);
        }else if($keterangan == 3){
            $this->load->view('v_pesan_alfa', $data);
        }
    }
    function logout(){
    $this->session->sess_destroy();
    redirect('Welcome');
	}
}