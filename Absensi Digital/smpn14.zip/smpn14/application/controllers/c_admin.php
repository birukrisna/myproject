<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_admin extends CI_Controller {
	
	function __construct(){
		parent::__construct();
		$this->load->model('m_crud_admin');
		$this->load->library('form_validation');
		$this->load->helper('url');
		if($this->session->userdata('status') !="loginadmin"){
			redirect('Welcome');
		}
		
	}
	function index()
	{
		$rekap = array
		(
			'laki' => $this->m_crud_admin->jumlahlaki()->result(),
			'perempuan' => $this->m_crud_admin->jumlahperempuan()->result(),
			'siswa' => $this->m_crud_admin->jumlahsiswa()->result() 
		);
		$this->load->view('admin',$rekap);
	}
	function insert()
	{
		$nis = "";
		$nama_siswa = "";
		$jk = "";
		$kelas = "";
		$namaot = "";
		$alamat = "";
		$no_telp = "";
		$data = array (
			'nis' => $nis,
			'nama_siswa' => $nama_siswa,
			'jenis_kelamin' => $jk,
			'kelas' => $kelas,
			'nama_orang_tua' => $namaot,
			'alamat' => $alamat,
			'no_hp' => $no_telp
		);
		$this->load->view('v_issiswa',$data);
	}
	function aksi_input()
	{	
		$this->form_validation->set_rules('nis','NIS','required');
		$this->form_validation->set_rules('namasw','Nama Siswa','required');
		$this->form_validation->set_rules('jk','jenis Kelamin','required');
		$this->form_validation->set_rules('kelas','Kelas','required');
		$this->form_validation->set_rules('nama_ortu','Nama Orang Tua','required');
		$this->form_validation->set_rules('alamat','Alamat','required');
		$this->form_validation->set_rules('telepon','Telepon','required');
		$nis = $this->input->post('nis');
		$nama_siswa = $this->input->post('namasw');
		$jk = $this->input->post('jk');
		$kelas = $this->input->post('kelas');
		$namaot = $this->input->post('nama_ortu');
		$alamat = $this->input->post('alamat');
		$no_telp = $this->input->post('telepon');
		$data = array (
			'nis' => $nis,
			'nama_siswa' => $nama_siswa,
			'jenis_kelamin' => $jk,
			'kelas' => $kelas,
			'nama_orang_tua' => $namaot,
			'alamat' => $alamat,
			'no_hp' => $no_telp
		);
		if($this->form_validation->run() != false){
		$siswa = array(
			'nis' => $nis,
			'nama_siswa' => $nama_siswa,
			'jenis_kelamin' => $jk,
			'kelas' => $kelas
		);
		$orang_tua = array(
			'nis' => $nis,
			'nama_orang_tua' => $namaot,
			'alamat' => $alamat,
			'no_hp' => $no_telp 
		);
		$where = array('nis' =>$nis);
		$cek = $this->m_crud_admin->cek_nis($where,'siswa')->num_rows();
		if ($cek > 0){
			$this->load->view('v_issiswaerror',$data);
		}else{
			$this->m_crud_admin->inputdata($siswa,'siswa');
			$this->m_crud_admin->inputdata($orang_tua,'orang_tua');
			$this->load->view('v_issiswasucces');
		}
		}else{
			$this->load->view('v_issiswa',$data);
		}
	}
	function showot(){
		$dot['gabungan'] = $this->m_crud_admin->tampildataot()->result();
		$this->load->view('v_shot',$dot);
	}
	
	function hapussiswa($nis)
	{
		$where = array('nis' => $nis);
		$this->m_crud_admin->hapus_data($where,'siswa');
		$this->m_crud_admin->hapus_data($where,'orang_tua');
		$dot['gabungan'] = $this->m_crud_admin->tampildataot()->result();
		$this->load->view('v_hpssiswasuccess',$dot);
	}

	function editsiswa($nis)
	{
		$where = array('siswa.nis'=>$nis);
		$data['siswa'] = $this->m_crud_admin->tampileditsiswa($where,'siswa')->result();
		$this->load->view('v_edsiswa',$data);
	}
	function showotedit(){
		$dot['gabungan'] = $this->m_crud_admin->tampildataot()->result();
		$this->load->view('v_edsiswasucces',$dot);
	}
	function edit_aksi()
	{
		$nis = $this->input->post('nis');
		$nama_siswa = $this->input->post('namasw');
		$jk = $this->input->post('jk');
		$kelas = $this->input->post('kelas');
		$namaot = $this->input->post('nama_ortu');
		$alamat = $this->input->post('alamat');
		$no_telp = $this->input->post('telepon');
		$siswa = array(
			'nis' => $nis,
			'nama_siswa' => $nama_siswa,
			'jenis_kelamin' => $jk,
			'kelas' => $kelas
		);
		$orang_tua = array(
			'nis' => $nis,
			'nama_orang_tua' => $namaot,
			'alamat' => $alamat,
			'no_hp' => $no_telp 
		);
		$where = array('nis' => $nis,);
		$this->m_crud_admin->update_siswa($where,$siswa,'siswa');
		$this->m_crud_admin->update_siswa($where,$orang_tua,'orang_tua');
		redirect('c_admin/showotedit');
		
	}


	function logout(){
	$this->session->sess_destroy();
	redirect('Welcome');
}
}
